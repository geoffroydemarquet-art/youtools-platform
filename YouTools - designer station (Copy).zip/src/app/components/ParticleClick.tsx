import { motion } from 'motion/react';
import { useState } from 'react';

interface ParticleClickProps {
  children: React.ReactNode;
  onClick?: () => void;
  className?: string;
}

export function ParticleClick({ children, onClick, className = '' }: ParticleClickProps) {
  const [particles, setParticles] = useState<{ id: number; x: number; y: number }[]>([]);

  const handleClick = (e: React.MouseEvent) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    const newParticles = Array.from({ length: 8 }, (_, i) => ({
      id: Date.now() + i,
      x,
      y
    }));

    setParticles(prev => [...prev, ...newParticles]);

    // Clean up particles after animation
    setTimeout(() => {
      setParticles(prev => prev.filter(p => !newParticles.includes(p)));
    }, 1000);

    onClick?.();
  };

  return (
    <div className={`relative ${className}`} onClick={handleClick}>
      {children}
      
      {/* Particles */}
      {particles.map((particle, index) => (
        <motion.div
          key={particle.id}
          className="absolute w-1 h-1 bg-teal-400 rounded-full pointer-events-none"
          style={{
            left: particle.x,
            top: particle.y,
          }}
          initial={{ 
            scale: 0,
            opacity: 1,
          }}
          animate={{
            x: (Math.random() - 0.5) * 100,
            y: (Math.random() - 0.5) * 100,
            scale: [0, 1, 0],
            opacity: [1, 1, 0],
          }}
          transition={{
            duration: 0.8,
            ease: "easeOut",
            delay: index * 0.05
          }}
        />
      ))}
    </div>
  );
}
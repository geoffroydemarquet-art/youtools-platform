import { useAuthGuard } from './useAuth';

interface HomePageProps {
  onNavigate: (page: 'photoshop' | 'illustrator' | 'midjourney' | 'ai-assistant') => void;
  onChangeVideoBackground: () => void;
}

export function HomePage({ onNavigate, onChangeVideoBackground }: HomePageProps) {
  // Protection d'authentification
  useAuthGuard();
  const tools = [
    {
      id: 'photoshop',
      name: 'Adobe Photoshop',
      description: 'Raccourcis professionnels',
      color: 'bg-blue-500',
      shortcuts: '50+ raccourcis'
    },
    {
      id: 'illustrator',
      name: 'Adobe Illustrator',
      description: 'Techniques avancées',
      color: 'bg-orange-500',
      shortcuts: '40+ raccourcis'
    },
    {
      id: 'midjourney',
      name: 'Prompt design',
      description: 'Guide complet IA générative',
      color: 'bg-purple-500',
      shortcuts: '230+ astuces'
    },
    {
      id: 'ai-assistant',
      name: 'Agent IA',
      description: 'Expert design graphique',
      color: 'bg-orange-500',
      shortcuts: 'Questions/réponses'
    }
  ];

  return (
    <div className="relative">
      {/* Hero Section */}
      <section className="min-h-[calc(100vh-4rem)] flex items-center justify-center px-6 pt-8 pb-20 relative">
        <div className="relative max-w-7xl mx-auto">
          <div className="flex items-center justify-center">
            {/* Content - Centered */}
            <div className="text-center space-y-8">
              {/* Orange Entry Button with Breathing Animation */}
              <div className="relative flex items-center justify-center">
                <button
                  onClick={onChangeVideoBackground}
                  className="blue-entry-button group relative w-32 h-32 bg-orange-400/10 backdrop-blur-sm rounded-full shadow-2xl transition-all duration-500 ease-out hover:scale-105 hover:bg-orange-300/20 focus:outline-none"
                >
                  {/* Plus Symbol in Center */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-8xl font-bold text-orange-600 transition-all duration-300 group-hover:text-orange-500 group-hover:scale-110 leading-none select-none" style={{ lineHeight: '1', textAlign: 'center', display: 'flex', alignItems: 'center', justifyContent: 'center', transform: 'translateY(-8px)' }}>
                      +
                    </span>
                  </div>
                  
                  {/* Circle Wave Effects on Hover */}
                  <div className="circle-wave-container opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                    <div className="circle-wave"></div>
                    <div className="circle-wave"></div>
                    <div className="circle-wave"></div>
                    <div className="circle-wave"></div>
                  </div>
                  
                  {/* Hover Glow Effect */}
                  <div className="absolute inset-0 rounded-full bg-gradient-to-br from-orange-300/15 to-orange-500/25 opacity-0 group-hover:opacity-100 transition-all duration-500 blur-lg"></div>
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Modules Section */}
      <section className="py-20 px-6 bg-white/80 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Modules de Formation
            </h2>
            <p className="text-xl text-gray-800 max-w-2xl mx-auto">
              Choisissez votre domaine d'expertise et progressez à votre rythme
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {tools.map((tool) => (
              <button
                key={tool.id}
                onClick={() => onNavigate(tool.id as any)}
                className="group bg-white/90 hover:bg-white backdrop-blur-sm border border-gray-200 hover:border-gray-300 rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 text-left"
              >
                <div className="flex items-start space-x-4">
                  <div className={`w-4 h-4 ${tool.color} rounded-full mt-1 group-hover:scale-110 transition-transform duration-200`}></div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900 mb-2 group-hover:text-orange-600 transition-colors duration-200">
                      {tool.name}
                    </h3>
                    <p className="text-sm text-gray-800 mb-3">
                      {tool.description}
                    </p>
                    <div className="text-xs text-gray-500 font-medium">
                      {tool.shortcuts}
                    </div>
                  </div>
                </div>
                
                {/* Arrow indicator */}
                <div className="flex justify-end mt-4">
                  <div className="w-6 h-6 bg-gray-100 group-hover:bg-orange-100 rounded-full flex items-center justify-center transition-colors duration-200">
                    <svg className="w-3 h-3 text-gray-800 group-hover:text-orange-600 transition-colors duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-6 bg-white/60 backdrop-blur-sm">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-12">
            Pourquoi choisir notre plateforme ?
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="space-y-4">
              <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center mx-auto">
                <svg className="w-6 h-6 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-900">Raccourcis Optimisés</h3>
              <p className="text-gray-800">
                Gagnez en productivité avec des raccourcis clavier testés et approuvés par des professionnels.
              </p>
            </div>
            
            <div className="space-y-4">
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mx-auto">
                <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-900">IA Générative</h3>
              <p className="text-gray-800">
                Découvrez plus de 230 astuces pour maîtriser le Prompt design et créer des visuels époustouflants.
              </p>
            </div>
            
            <div className="space-y-4">
              <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mx-auto">
                <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-900">Évaluation Certifiante</h3>
              <p className="text-gray-800">
                Validez vos compétences avec un quiz de 100 questions et obtenez votre score détaillé.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
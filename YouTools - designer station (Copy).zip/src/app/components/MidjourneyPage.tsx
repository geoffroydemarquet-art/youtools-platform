import { useState } from 'react';
import { Tabs, TabsContent } from './ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Search, Lightbulb, Star, Zap, Camera, Palette, Sun, Sparkles, ImageIcon, Play } from 'lucide-react';
import { useAuthGuard } from './useAuth';

interface MidjourneyPageProps {
  currentSubPage?: string;
}

// Types de plans et cadrages
const cameraShots = [
  { term: 'close-up', description: 'Plan très serré sur le visage ou un détail', example: 'close-up portrait of a woman' },
  { term: 'extreme close-up', description: 'Plan extrêmement serré sur un détail', example: 'extreme close-up of eyes' },
  { term: 'medium shot', description: 'Plan moyen cadrant à mi-corps', example: 'medium shot of a person sitting' },
  { term: 'full body shot', description: 'Plan en pied montrant le personnage entier', example: 'full body shot of a dancer' },
  { term: 'wide shot', description: 'Plan large montrant l\'environnement', example: 'wide shot of a landscape' },
  { term: 'extreme wide shot', description: 'Plan très large, vue d\'ensemble', example: 'extreme wide shot of a city' },
  { term: 'bird\'s eye view', description: 'Vue aérienne plongeante', example: 'bird\'s eye view of a forest' },
  { term: 'worm\'s eye view', description: 'Vue en contre-plongée extrême', example: 'worm\'s eye view of skyscrapers' },
  { term: 'low angle', description: 'Contre-plongée, caméra en bas', example: 'low angle shot of a hero' },
  { term: 'high angle', description: 'Plongée, caméra en haut', example: 'high angle view of a crowd' },
  { term: 'eye level', description: 'Caméra à hauteur des yeux', example: 'eye level portrait' },
  { term: 'over the shoulder', description: 'Par-dessus l\'épaule', example: 'over the shoulder conversation' },
  { term: 'point of view shot', description: 'Plan subjectif', example: 'point of view driving a car' },
  { term: 'establishing shot', description: 'Plan d\'établissement du lieu', example: 'establishing shot of a castle' },
  { term: 'tracking shot', description: 'Plan de suivi en mouvement', example: 'tracking shot through a market' },
  // Plans de caméra additionnels
  { term: 'dutch angle', description: 'Angle oblique créant une tension visuelle', example: 'dutch angle dramatic scene' },
  { term: 'rack focus', description: 'Changement de mise au point pendant la prise', example: 'rack focus foreground to background' },
  { term: 'tilt shift', description: 'Effet miniature par mise au point sélective', example: 'tilt shift city view' },
  { term: 'fisheye lens', description: 'Objectif ultra grand-angle déformant', example: 'fisheye lens street photography' },
  { term: 'macro shot', description: 'Très gros plan sur petit sujet', example: 'macro shot water droplet' },
  { term: 'aerial view', description: 'Vue aérienne d\'en haut', example: 'aerial view of coastline' },
  { term: 'ground level', description: 'Angle au niveau du sol', example: 'ground level flower field' },
  { term: 'panoramic shot', description: 'Vue panoramique très large', example: 'panoramic shot mountain range' },
  { term: 'crane shot', description: 'Mouvement vertical de caméra', example: 'crane shot revealing landscape' },
  { term: 'handheld camera', description: 'Caméra portée à la main', example: 'handheld camera documentary style' },
  { term: 'steady cam', description: 'Caméra stabilisée en mouvement', example: 'steady cam following character' },
  { term: 'dolly zoom', description: 'Zoom avant avec recul simultané', example: 'dolly zoom vertigo effect' }
];

// Nouveaux mouvements et plans de caméra (50 de chaque)
const cameraMovementsList = [
  { term: 'Pan (Panorama)', description: 'Rotation horizontale de la caméra sur son axe', example: 'slow pan across a futuristic skyline' },
  { term: 'Tilt', description: 'Rotation verticale de la caméra sur son axe', example: 'tilt up from shoes to face of a giant' },
  { term: 'Dolly In', description: 'Mouvement physique de la caméra vers le sujet', example: 'dolly in towards a mysterious box' },
  { term: 'Dolly Out', description: 'Mouvement physique de la caméra s\'éloignant du sujet', example: 'dolly out revealing the vast desert' },
  { term: 'Zoom In', description: 'Agrandissement optique du sujet sans bouger la caméra', example: 'sudden zoom in on a character\'s shocked expression' },
  { term: 'Zoom Out', description: 'Élargissement optique du champ sans bouger la caméra', example: 'slow zoom out from a single flower' },
  { term: 'Pedestal Up', description: 'Déplacement vertical de la caméra vers le haut', example: 'pedestal up revealing a tall skyscraper' },
  { term: 'Pedestal Down', description: 'Déplacement vertical de la caméra vers le bas', example: 'pedestal down to reveal a hidden trapdoor' },
  { term: 'Tracking Shot', description: 'La caméra suit parallèlement le sujet en mouvement', example: 'tracking shot of a car racing through neon streets' },
  { term: 'Crane Shot', description: 'Caméra montée sur une grue pour des mouvements amples', example: 'high crane shot over a medieval battle' },
  { term: 'Handheld', description: 'Caméra portée à l\'épaule pour un effet immersif et tremblant', example: 'handheld footage of a chaotic protest' },
  { term: 'Steadicam', description: 'Système de stabilisation pour des mouvements fluides', example: 'smooth steadicam follow through a dense forest' },
  { term: 'Gimbal Move', description: 'Mouvement stabilisé électroniquement, très fluide', example: 'gimbal follow shot through a modern art gallery' },
  { term: 'Drone Shot', description: 'Vue aérienne dynamique capturée par drone', example: 'drone flyover of a jagged mountain peak' },
  { term: 'Arc Shot', description: 'Mouvement circulaire de la caméra autour du sujet', example: 'arc shot around a couple dancing' },
  { term: 'Dolly Zoom', description: 'Effet Vertigo combinant dolly et zoom opposé', example: 'dramatic dolly zoom in a dark hallway' },
  { term: 'Rack Focus', description: 'Changement de netteté d\'un sujet à un autre', example: 'rack focus from foreground flower to background mountain' },
  { term: 'Whip Pan', description: 'Panoramique ultra rapide créant un flou de mouvement', example: 'fast whip pan between two arguing characters' },
  { term: 'Crash Zoom', description: 'Zoom extrêmement rapide et brutal', example: 'crash zoom on a sniper\'s scope' },
  { term: 'Follow Shot', description: 'La caméra suit le sujet de dos ou de face', example: 'follow shot behind a warrior entering a cave' },
  { term: 'Lead Shot', description: 'La caméra précède le sujet en reculant', example: 'lead shot of a child running through a field' },
  { term: 'POV Move', description: 'Mouvement simulant le regard d\'un personnage', example: 'POV shot looking around a haunted house' },
  { term: 'Static Shot', description: 'Caméra parfaitement immobile pour la stabilité', example: 'static shot of a symmetrical Wes Anderson building' },
  { term: 'Snap Zoom', description: 'Zoom rapide et court pour accentuer un détail', example: 'snap zoom on a ticking clock' },
  { term: 'Circular Tracking', description: 'Suivi continu sur une trajectoire circulaire', example: 'circular tracking shot in a high-tech lab' },
  { term: 'Lateral Tracking', description: 'Déplacement latéral pur le long d\'une scène', example: 'lateral tracking shot of a 2D-style platformer world' },
  { term: 'Orbit Shot', description: 'La caméra orbite lentement autour d\'un objet central', example: 'slow orbit shot around a magical artifact' },
  { term: 'Reverse Dolly', description: 'Dolly arrière pour révéler l\'environnement', example: 'reverse dolly revealing a massive dragon' },
  { term: 'Push In', description: 'Mouvement subtil vers l\'avant pour l\'intimité', example: 'subtle push in on a crying face' },
  { term: 'Pull Out', description: 'Mouvement subtil vers l\'arrière pour la solitude', example: 'pull out showing a lonely figure on a beach' },
  { term: 'Vertical Reveal', description: 'Découverte d\'un élément par un mouvement vertical', example: 'vertical reveal of a waterfall from bottom to top' },
  { term: 'Diagonal Tracking', description: 'Mouvement de caméra sur une ligne diagonale', example: 'diagonal tracking shot across a futuristic bridge' },
  { term: 'Shake Cam', description: 'Simulation de tremblements (explosion, séisme)', example: 'heavy shake cam during a volcanic eruption' },
  { term: 'Jib Shot', description: 'Mouvement de bras de grue pour changer de hauteur', example: 'jib shot rising over a garden wall' },
  { term: 'Slider Move', description: 'Petit déplacement latéral très contrôlé', example: 'smooth slider move across a set of luxury watches' },
  { term: '360 Spin', description: 'Rotation complète de la caméra sur elle-même', example: '360 spin in a psychedelic tunnel' },
  { term: 'Spiral Move', description: 'Mouvement hélicoïdal montant ou descendant', example: 'spiral camera move up a staircase' },
  { term: 'Floating Camera', description: 'Effet de caméra qui flotte sans gravité', example: 'floating camera shot inside a space station' },
  { term: 'Gliding Move', description: 'Glissement très lent et majestueux', example: 'gliding shot over a calm lake at dawn' },
  { term: 'Shaky Handheld', description: 'Tremblement nerveux pour le stress', example: 'shaky handheld POV of a chase' },
  { term: 'Rapid Tilt', description: 'Bascule verticale soudaine', example: 'rapid tilt down to a blood stain on the floor' },
  { term: 'Parallel Tracking', description: 'Suivi parfaitement parallèle à la vitesse du sujet', example: 'parallel tracking of a sprinting athlete' },
  { term: 'Low-Angle Follow', description: 'Suivi au ras du sol', example: 'low-angle follow shot of boots walking' },
  { term: 'High-Angle Follow', description: 'Suivi en surplomb', example: 'high-angle follow shot of a person in a maze' },
  { term: 'Shoulder Mount', description: 'Rendu stable mais organique d\'épaule', example: 'shoulder mount interview style' },
  { term: 'Abstract Path', description: 'Trajectoire complexe et non-linéaire', example: 'abstract camera path through a fractal dimension' },
  { term: 'Swooping Move', description: 'Mouvement plongeant comme un oiseau', example: 'swooping camera move towards a castle gate' },
  { term: 'Z-axis Move', description: 'Mouvement de profondeur pur', example: 'deep Z-axis movement through a starfield' },
  { term: 'Rotational Tilt', description: 'Inclinaison combinée à une rotation', example: 'rotational tilt in a dream sequence' },
  { term: 'Dynamic Push', description: 'Poussée agressive vers un point d\'intérêt', example: 'dynamic push towards a glowing button' }
];

const cameraPlanesList = [
  { term: 'Extreme Close-Up (ECU)', description: 'Détail minuscule remplissant l\'écran', example: 'extreme close-up of a human iris' },
  { term: 'Close-Up (CU)', description: 'Visage du sujet remplissant le cadre', example: 'close-up portrait of an old man' },
  { term: 'Medium Close-Up (MCU)', description: 'Cadrage poitrine et tête', example: 'medium close-up of a news anchor' },
  { term: 'Medium Shot (MS)', description: 'Cadrage de la taille à la tête', example: 'medium shot of a chef cooking' },
  { term: 'Medium Wide Shot (MWS)', description: 'Cadrage des genoux à la tête', example: 'medium wide shot of a gunslinger' },
  { term: 'Wide Shot (WS)', description: 'Le sujet entier est visible dans le décor', example: 'wide shot of a hiker on a cliff' },
  { term: 'Extreme Wide Shot (EWS)', description: 'Le décor domine, le sujet est minuscule', example: 'extreme wide shot of a lone traveler in the Sahara' },
  { term: 'Full Shot', description: 'Le sujet occupe toute la hauteur du cadre', example: 'full shot of a superhero landing' },
  { term: 'Cowboy Shot', description: 'Cadrage mi-cuisse (style Western)', example: 'cowboy shot of a sheriff in the street' },
  { term: 'Italian Shot', description: 'Très gros plan horizontal sur les yeux', example: 'italian shot of a poker player' },
  { term: 'Over the Shoulder (OTS)', description: 'Vue depuis derrière l\'épaule d\'un autre', example: 'OTS shot of a romantic dinner conversation' },
  { term: 'Point of View (POV)', description: 'Ce que voit précisément le personnage', example: 'POV shot looking through binoculars' },
  { term: 'Bird\'s Eye View', description: 'Vue de dessus, à la verticale', example: 'bird\'s eye view of a complex intersection' },
  { term: 'Worm\'s Eye View', description: 'Vue depuis le sol, vers le haut', example: 'worm\'s eye view of a giant robot' },
  { term: 'High Angle', description: 'Caméra au-dessus du sujet regardant vers le bas', example: 'high angle shot of a lost child' },
  { term: 'Low Angle', description: 'Caméra sous le sujet regardant vers le haut', example: 'low angle shot of a majestic queen' },
  { term: 'Eye Level', description: 'Caméra à hauteur d\'homme, neutre', example: 'eye level interview portrait' },
  { term: 'Dutch Angle', description: 'Caméra penchée sur le côté (tension)', example: 'dutch angle of a villain laughing' },
  { term: 'Two Shot', description: 'Deux sujets dans le même cadre', example: 'two shot of detectives in a car' },
  { term: 'Three Shot', description: 'Trois sujets harmonieusement cadrés', example: 'three shot of a music band' },
  { term: 'Group Shot', description: 'Un groupe entier de personnes', example: 'group shot of a family reunion' },
  { term: 'Establishing Shot', description: 'Définit le lieu de l\'action', example: 'establishing shot of New York at night' },
  { term: 'Master Shot', description: 'Plan large capturant toute la scène', example: 'master shot of a dinner party chaos' },
  { term: 'Reaction Shot', description: 'Focus sur la réaction d\'un personnage', example: 'reaction shot of a surprised witness' },
  { term: 'Insert Shot', description: 'Gros plan sur un objet crucial', example: 'insert shot of a ticking time bomb' },
  { term: 'Cutaway', description: 'Coupe vers un élément hors-champ', example: 'cutaway to a cat watching the action' },
  { term: 'Macro Shot', description: 'Détail extrême d\'insecte ou texture', example: 'macro shot of a circuit board' },
  { term: 'Micro Shot', description: 'Niveau microscopique', example: 'micro shot of a snowflake structure' },
  { term: 'Aerial Shot', description: 'Vue depuis un avion ou hélicoptère', example: 'aerial shot of the Amazon rainforest' },
  { term: 'Ground Level Shot', description: 'Caméra posée directement au sol', example: 'ground level shot of a ladybug on a leaf' },
  { term: 'Underwater Shot', description: 'Prise de vue sous l\'eau', example: 'underwater shot of a coral reef' },
  { term: 'Split Screen', description: 'Écran divisé en deux ou plus', example: 'split screen of two people on the phone' },
  { term: 'Deep Focus', description: 'Tout est net, du premier au dernier plan', example: 'deep focus shot of a long hallway' },
  { term: 'Shallow Focus', description: 'Flou d\'arrière-plan (bokeh)', example: 'shallow focus portrait with blurred lights' },
  { term: 'Silhouette Shot', description: 'Sujet totalement noir sur fond clair', example: 'silhouette shot of a person at sunset' },
  { term: 'Reflection Shot', description: 'Vue à travers un miroir ou de l\'eau', example: 'reflection shot of a city in a puddle' },
  { term: 'Framed Shot', description: 'Utilise un cadre naturel (fenêtre, porte)', example: 'framed shot of a mountain through a window' },
  { term: 'Silhouette Profile', description: 'Profil en ombre chinoise', example: 'silhouette profile of a singer' },
  { term: 'Back View', description: 'Sujet vu de dos', example: 'back view of a traveler looking at the sea' },
  { term: 'Side Profile', description: 'Sujet vu parfaitement de côté', example: 'side profile of a Greek statue' },
  { term: 'High-Key Shot', description: 'Éclairage très clair, peu d\'ombres', example: 'high-key fashion photography' },
  { term: 'Low-Key Shot', description: 'Éclairage sombre, beaucoup d\'ombres', example: 'low-key noir style portrait' },
  { term: 'Long Shot', description: 'Sujet visible de loin', example: 'long shot of a knight approaching a castle' },
  { term: 'Knee Shot', description: 'Cadrage au niveau des genoux', example: 'knee shot of a soccer player' },
  { term: 'Waist Shot', description: 'Cadrage à la taille', example: 'waist shot of a barista' },
  { term: 'Chest Shot', description: 'Cadrage à la poitrine', example: 'chest shot of a doctor' },
  { term: 'Shoulder Shot', description: 'Cadrage aux épaules', example: 'shoulder shot of a teacher' },
  { term: 'Head Shot', description: 'Focus uniquement sur la tête', example: 'head shot for a passport' },
  { term: 'Extreme High Angle', description: 'Plongée totale (zénithale)', example: 'extreme high angle of a dinner table' },
  { term: 'Extreme Low Angle', description: 'Contre-plongée totale (nadir)', example: 'extreme low angle of a giant tree' }
];

// Types d'éclairages
const lightingTypes = [
  { term: 'golden hour', description: 'Lumière dorée du lever/coucher de soleil', example: 'golden hour portrait' },
  { term: 'blue hour', description: 'Lumière bleue du crépuscule', example: 'blue hour cityscape' },
  { term: 'harsh lighting', description: 'Éclairage dur créant des ombres nettes', example: 'harsh lighting dramatic portrait' },
  { term: 'soft lighting', description: 'Éclairage doux et diffus', example: 'soft lighting beauty shot' },
  { term: 'backlighting', description: 'Éclairage par l\'arrière', example: 'backlighting silhouette' },
  { term: 'rim lighting', description: 'Éclairage de contour', example: 'rim lighting portrait' },
  { term: 'dramatic lighting', description: 'Éclairage théâtral contrasté', example: 'dramatic lighting scene' },
  { term: 'natural lighting', description: 'Éclairage naturel', example: 'natural lighting outdoor portrait' },
  { term: 'studio lighting', description: 'Éclairage de studio contrôlé', example: 'studio lighting professional headshot' },
  { term: 'neon lighting', description: 'Éclairage néon coloré', example: 'neon lighting cyberpunk scene' },
  { term: 'candlelight', description: 'Éclairage à la bougie', example: 'candlelight romantic dinner' },
  { term: 'moonlight', description: 'Éclairage lunaire', example: 'moonlight forest scene' },
  { term: 'volumetric lighting', description: 'Rayons de lumière visibles', example: 'volumetric lighting through window' },
  { term: 'cinematic lighting', description: 'Éclairage cinématographique', example: 'cinematic lighting film noir' },
  { term: 'ambient lighting', description: 'Éclairage d\'ambiance général', example: 'ambient lighting cozy room' },
  // Types d'éclairages additionnels
  { term: 'key light', description: 'Éclairage principal dominant', example: 'key light portrait setup' },
  { term: 'fill light', description: 'Éclairage de complément adoucissant', example: 'fill light studio portrait' },
  { term: 'hair light', description: 'Éclairage de cheveux/contour', example: 'hair light glamour photography' },
  { term: 'practical lighting', description: 'Sources lumineuses visibles dans la scène', example: 'practical lighting lamp on table' },
  { term: 'motivated lighting', description: 'Éclairage justifié par une source visible', example: 'motivated lighting window scene' },
  { term: 'artificial lighting', description: 'Éclairage artificiel créatif', example: 'artificial lighting neon colors' },
  { term: 'edge lighting', description: 'Éclairage de bord/contour', example: 'edge lighting silhouette effect' },
  { term: 'top lighting', description: 'Éclairage d\'en haut', example: 'top lighting dramatic shadows' },
  { term: 'under lighting', description: 'Éclairage par en dessous', example: 'under lighting spooky atmosphere' },
  { term: 'cross lighting', description: 'Éclairages croisés multiples', example: 'cross lighting complex shadows' },
  { term: 'bounce lighting', description: 'Lumière réfléchie indirecte', example: 'bounce lighting soft portrait' },
  { term: 'spotlighting', description: 'Éclairage ponctuel concentré', example: 'spotlighting stage performance' },
  { term: 'flood lighting', description: 'Éclairage large et uniforme', example: 'flood lighting even illumination' },
  { term: 'colored lighting', description: 'Éclairage coloré créatif', example: 'colored lighting blue and red' },
  { term: 'strobe lighting', description: 'Éclairage stroboscopique', example: 'strobe lighting dance club' },
  { term: 'fire lighting', description: 'Éclairage de feu/flammes', example: 'fire lighting campfire scene' }
];

// Styles artistiques
const artisticStyles = [
  { term: 'photorealistic', description: 'Style photoréaliste', example: 'photorealistic portrait' },
  { term: 'hyperrealistic', description: 'Style hyperréaliste', example: 'hyperrealistic digital art' },
  { term: 'impressionist', description: 'Style impressionniste', example: 'impressionist landscape painting' },
  { term: 'expressionist', description: 'Style expressionniste', example: 'expressionist emotional portrait' },
  { term: 'surreal', description: 'Style surréaliste', example: 'surreal dreamlike scene' },
  { term: 'abstract', description: 'Style abstrait', example: 'abstract geometric composition' },
  { term: 'minimalist', description: 'Style minimaliste', example: 'minimalist clean design' },
  { term: 'baroque', description: 'Style baroque ornementé', example: 'baroque ornate architecture' },
  { term: 'art nouveau', description: 'Style Art nouveau', example: 'art nouveau flowing lines' },
  { term: 'art deco', description: 'Style Art déco', example: 'art deco geometric patterns' },
  { term: 'pop art', description: 'Style Pop art', example: 'pop art bright colors' },
  { term: 'street art', description: 'Style street art/graffiti', example: 'street art urban mural' },
  { term: 'anime style', description: 'Style anime japonais', example: 'anime style character' },
  { term: 'manga style', description: 'Style manga', example: 'manga style illustration' },
  { term: 'watercolor', description: 'Style aquarelle', example: 'watercolor soft painting' },
  // Styles artistiques additionnels
  { term: 'oil painting', description: 'Style peinture à l\'huile', example: 'oil painting classical portrait' },
  { term: 'acrylic painting', description: 'Style peinture acrylique', example: 'acrylic painting vibrant colors' },
  { term: 'pastel drawing', description: 'Style dessin aux pastels', example: 'pastel drawing soft landscape' },
  { term: 'charcoal drawing', description: 'Style dessin au fusain', example: 'charcoal drawing dramatic portrait' },
  { term: 'pencil sketch', description: 'Style esquisse au crayon', example: 'pencil sketch detailed study' },
  { term: 'ink drawing', description: 'Style dessin à l\'encre', example: 'ink drawing fine lines' },
  { term: 'digital painting', description: 'Style peinture numérique', example: 'digital painting fantasy art' },
  { term: 'concept art', description: 'Style art conceptuel', example: 'concept art environment design' },
  { term: 'matte painting', description: 'Style peinture mate cinéma', example: 'matte painting epic landscape' },
  { term: 'pixel art', description: 'Style art pixelisé', example: 'pixel art retro game style' },
  { term: 'vector art', description: 'Style art vectoriel', example: 'vector art clean geometric' },
  { term: 'collage', description: 'Style collage mixte', example: 'collage mixed media art' },
  { term: 'graffiti style', description: 'Style graffiti urbain', example: 'graffiti style wall art' },
  { term: 'stained glass', description: 'Style vitrail', example: 'stained glass cathedral window' },
  { term: 'mosaic', description: 'Style mosaïque', example: 'mosaic colorful pattern' },
  { term: 'origami', description: 'Style papier plié', example: 'origami paper sculpture' },
  { term: 'woodcut', description: 'Style gravure sur bois', example: 'woodcut print illustration' },
  { term: 'lithograph', description: 'Style lithographie', example: 'lithograph vintage poster' },
  { term: 'screen print', description: 'Style sérigraphie', example: 'screen print pop art style' },
  { term: 'pointillism', description: 'Style pointilliste', example: 'pointillism dot technique' },
  { term: 'cubism', description: 'Style cubiste', example: 'cubism geometric forms' },
  { term: 'fauvism', description: 'Style fauve', example: 'fauvism bold colors' }
];

// Tips généraux
const generalTips = [
  { category: 'Composition', tip: 'Utilisez des ratios d\'aspect spécifiques', example: '--ar 16:9 pour format cinéma, --ar 1:1 pour carré, --ar 9:16 pour portrait' },
  { category: 'Qualité', tip: 'Ajoutez des mots-clés de qualité', example: 'high quality, 8k, ultra detailed, masterpiece' },
  { category: 'Style', tip: 'Spécifiez le médium artistique', example: 'oil painting, digital art, photography, pencil sketch' },
  { category: 'Éclairage', tip: 'Décrivez précisément l\'éclairage', example: 'soft natural light, dramatic shadows, golden hour' },
  { category: 'Couleurs', tip: 'Utilisez des palettes de couleurs', example: 'vibrant colors, monochromatic, pastel palette' },
  { category: 'Caméra', tip: 'Mentionnez l\'équipement photo', example: 'shot with Canon 5D, 85mm lens, shallow depth of field' },
  { category: 'Ambiance', tip: 'Créez une atmosphère', example: 'moody, ethereal, energetic, serene, mysterious' },
  { category: 'Détails', tip: 'Ajoutez des détails spécifiques', example: 'intricate details, texture, fabric, skin pores' },
  { category: 'Perspective', tip: 'Variez les points de vue', example: 'from above, low angle, fish-eye lens, macro shot' },
  { category: 'Post-traitement', tip: 'Simulez des effets photo', example: 'film grain, vintage filter, HDR effect, long exposure' },
  { category: 'Modèles', tip: 'Utilisez des versions spécifiques', example: '--v 6 pour la dernire version, --style raw pour plus de contrôle' },
  { category: 'Poids', tip: 'Contrôlez l\'importance des éléments', example: 'beautiful woman::2 forest::1 (2x plus important)' },
  { category: 'Exclusion', tip: 'Excluez des éléments indésirables', example: '--no hands, --no text, --no watermark' },
  { category: 'Chaos', tip: 'Contrôlez la variabilité', example: '--chaos 50 pour plus de variations créatives' },
  { category: 'Stylisation', tip: 'Ajustez le niveau artistique', example: '--stylize 250 pour plus de style artistique' },
  // Tips avancés supplémentaires
  { category: 'Prompts multiples', tip: 'Utilisez :: pour séparer les concepts', example: 'beautiful woman::1.5 forest background::0.5' },
  { category: 'Répétition', tip: 'Utilisez --repeat pour générer plusieurs versions', example: '--repeat 4 pour 4 variations simultanées' },
  { category: 'Graines', tip: 'Contrôlez la reproductibilité', example: '--seed 123456 pour reproduire exactement' },
  { category: 'Vitesse', tip: 'Ajustez la vitesse de génération', example: '--fast pour plus rapide, --relax pour économiser' },
  { category: 'Qualité', tip: 'Contrôlez la qualité de rendu', example: '--quality 2 pour double qualité' },
  { category: 'Stop', tip: 'Arrêtez la génération à un pourcentage', example: '--stop 80 pour style plus brut' },
  { category: 'Tile', tip: 'Créez des motifs répétables', example: '--tile pour patterns seamless' },
  { category: 'Video', tip: 'Créez des séquences animées', example: '--video pour voir le processus' },
  { category: 'Upscale', tip: 'Agrandissez sélectivement', example: 'U1, U2, U3, U4 pour upscaler' },
  { category: 'Variations', tip: 'Créez des variations ciblées', example: 'V1, V2, V3, V4 pour varier' },
  { category: 'Remix', tip: 'Modifiez le prompt en variation', example: '--remix pour changer le prompt' },
  { category: 'Permutations', tip: 'Testez plusieurs options', example: '{red, blue, green} flower pour 3 versions' },
  { category: 'Image Prompts', tip: 'Utilisez des images de référence', example: '[URL image] + description textuelle' },
  { category: 'Multi-Prompts', tip: 'Combinez plusieurs concepts', example: 'concept A, concept B, concept C --iw 0.5' },
  { category: 'Style Transfer', tip: 'Appliquez le style d\'une image', example: '[image style] + [description] --style' },
  { category: 'Negative Prompts', tip: 'Spécifiez ce à éviter précisément', example: '--no blur, noise, dark, hands' },
  { category: 'Lighting Keywords', tip: 'Mots-clés d\'éclairage spécialisés', example: 'chiaroscuro, rembrandt lighting, split lighting' },
  { category: 'Camera Settings', tip: 'Simulez paramètres d\'appareil', example: 'f/1.4, ISO 100, 1/200s, 85mm lens' },
  { category: 'Film Types', tip: 'Imitez différents films', example: 'Kodak Portra 400, Fuji Velvia, Ilford HP5' },
  { category: 'Artist References', tip: 'Références d\'artistes célèbres', example: 'in the style of Van Gogh, Monet, Picasso' },
  { category: 'Architecture', tip: 'Styles architecturaux spécifiques', example: 'brutalist, gothic, bauhaus, art deco' },
  { category: 'Materials', tip: 'Spécifiez textures et matériaux', example: 'marble, velvet, glass, wood grain, metal' },
  { category: 'Weather', tip: 'Conditions météorologiques', example: 'stormy sky, foggy morning, sunny day, rain' },
  { category: 'Time Periods', tip: 'Époques historiques', example: 'medieval, victorian, 1920s, futuristic' },
  { category: 'Emotions', tip: 'États émotionnels', example: 'melancholic, euphoric, mysterious, serene' }
];

// Exemples de prompts complets
const samplePrompts = [
  {
    category: 'Portrait',
    title: 'Portrait professionnel femme',
    prompt: 'professional headshot of a confident businesswoman, clean white background, soft studio lighting, 85mm lens, shallow depth of field, natural makeup, elegant blazer, direct eye contact, high quality --ar 4:5 --v 6',
    description: 'Portrait corporate professionnel avec éclairage studio'
  },
  {
    category: 'Portrait',
    title: 'Portrait artistique homme',
    prompt: 'dramatic portrait of a bearded man, chiaroscuro lighting, dark background, intense eyes, leather jacket, cinematic style, shot with Hasselblad, film grain --ar 3:4 --v 6',
    description: 'Portrait dramatique avec éclairage clair-obscur'
  },
  {
    category: 'Paysage',
    title: 'Paysage montagneux',
    prompt: 'breathtaking mountain landscape at golden hour, misty valleys, dramatic clouds, alpine lakes, vibrant colors, wide angle lens, landscape photography, National Geographic style --ar 16:9 --v 6',
    description: 'Paysage de montagne à l\'heure dorée'
  },
  {
    category: 'Paysage',
    title: 'Forêt mystique',
    prompt: 'enchanted forest with volumetric lighting, sunbeams through trees, moss-covered rocks, magical atmosphere, fantasy style, detailed vegetation, cinematic composition --ar 2:3 --v 6',
    description: 'Forêt enchantée avec rayons de lumière'
  },
  {
    category: 'Architecture',
    title: 'Architecture moderne',
    prompt: 'modern glass skyscraper, minimalist design, reflective surfaces, blue hour lighting, urban photography, geometric patterns, leading lines, architectural photography --ar 9:16 --v 6',
    description: 'Gratte-ciel moderne en verre'
  },
  {
    category: 'Architecture',
    title: 'Bâtiment historique',
    prompt: 'ancient cathedral with gothic architecture, stone carvings, dramatic lighting, low angle shot, historical photography, weathered textures, moody atmosphere --ar 4:5 --v 6',
    description: 'Cathédrale gothique avec architecture ancienne'
  },
  {
    category: 'Produit',
    title: 'Produit tech premium',
    prompt: 'luxury smartphone on marble surface, studio lighting, reflections, clean background, product photography, commercial style, high-end branding, sharp details --ar 1:1 --v 6',
    description: 'Smartphone haut de gamme en studio'
  },
  {
    category: 'Produit',
    title: 'Packaging créatif',
    prompt: 'elegant perfume bottle with gold accents, soft shadows, minimalist composition, beauty product photography, pastel colors, luxury branding --ar 4:5 --v 6',
    description: 'Flacon de parfum élégant'
  },
  {
    category: 'Lifestyle',
    title: 'Café cozy',
    prompt: 'cozy coffee shop interior, warm lighting, wooden tables, plants, steaming coffee cup, lifestyle photography, hygge atmosphere, morning light --ar 16:9 --v 6',
    description: 'Intérieur chaleureux de café'
  },
  {
    category: 'Lifestyle',
    title: 'Workout moderne',
    prompt: 'athletic woman doing yoga at sunrise, silhouette against sky, inspiring lifestyle, fitness photography, peaceful morning, zen atmosphere --ar 3:4 --v 6',
    description: 'Séance de yoga au lever du soleil'
  },
  {
    category: 'Fantastique',
    title: 'Dragon majestueux',
    prompt: 'majestic dragon soaring through cloudy sky, fantasy art, detailed scales, fire breathing, epic composition, digital painting style, dramatic lighting --ar 16:9 --stylize 750 --v 6',
    description: 'Dragon fantastique volant dans les nuages'
  },
  {
    category: 'Fantastique',
    title: 'Château volant',
    prompt: 'floating castle in the clouds, steampunk elements, magical energy, fantasy architecture, detailed textures, concept art style, surreal landscape --ar 2:3 --stylize 500 --v 6',
    description: 'Château flottant style steampunk'
  },
  {
    category: 'Illustration',
    title: 'Character design anime',
    prompt: 'anime character girl with blue hair, school uniform, cherry blossoms background, manga style, cel-shading, vibrant colors, detailed eyes --ar 9:16 --niji 6',
    description: 'Personnage anime avec cerisiers'
  },
  {
    category: 'Illustration',
    title: 'Art vectoriel géométrique',
    prompt: 'geometric abstract composition, vibrant gradient colors, vector art style, clean lines, modern design, minimalist poster, graphic design --ar 1:1 --v 6',
    description: 'Composition abstraite géométrique'
  },
  {
    category: 'Mode',
    title: 'Fashion editorial',
    prompt: 'fashion model in avant-garde dress, dramatic pose, high fashion photography, studio lighting, editorial style, bold makeup, artistic composition --ar 3:4 --v 6',
    description: 'Photo de mode éditoriale'
  },
  {
    category: 'Mode',
    title: 'Street style urbain',
    prompt: 'stylish person in urban street setting, casual fashion, natural lighting, street photography, authentic moment, city background --ar 4:5 --v 6',
    description: 'Style de rue urbain décontracté'
  },
  // Nouveaux exemples de prompts
  {
    category: 'Nourriture',
    title: 'Plat gastronomique',
    prompt: 'gourmet dish beautifully plated, fine dining, soft natural lighting, food photography, garnish details, elegant presentation, shallow depth of field --ar 1:1 --v 6',
    description: 'Photographie culinaire haut de gamme'
  },
  {
    category: 'Nourriture',
    title: 'Café latte art',
    prompt: 'coffee cup with latte art, steam rising, wooden table, cozy cafe atmosphere, morning light, lifestyle photography, warm colors --ar 4:5 --v 6',
    description: 'Art du café avec vapeur et ambiance'
  },
  {
    category: 'Nature',
    title: 'Cascade majestueuse',
    prompt: 'powerful waterfall in pristine forest, mist and rainbows, long exposure effect, landscape photography, dramatic rocks, lush vegetation --ar 2:3 --v 6',
    description: 'Cascade naturelle avec effet de pose longue'
  },
  {
    category: 'Nature',
    title: 'Macro insecte',
    prompt: 'extreme macro photography of butterfly wing, intricate patterns, dewdrops, shallow depth of field, natural colors, detailed texture --ar 1:1 --v 6',
    description: 'Photographie macro détaillée d\'insecte'
  },
  {
    category: 'Véhicules',
    title: 'Voiture de sport',
    prompt: 'luxury sports car in urban setting, dramatic lighting, reflections on paint, motion blur background, automotive photography, sleek design --ar 16:9 --v 6',
    description: 'Photographie automobile avec effets dynamiques'
  },
  {
    category: 'Véhicules',
    title: 'Moto vintage',
    prompt: 'classic motorcycle in garage setting, vintage style, dramatic shadows, leather details, chrome reflections, nostalgic atmosphere --ar 3:4 --v 6',
    description: 'Moto classique dans ambiance vintage'
  },
  {
    category: 'Animaux',
    title: 'Lion majestueux',
    prompt: 'majestic lion in african savanna, golden hour lighting, wildlife photography, intense gaze, natural habitat, telephoto lens --ar 4:5 --v 6',
    description: 'Photographie animalière en milieu naturel'
  },
  {
    category: 'Animaux',
    title: 'Oiseau en vol',
    prompt: 'eagle soaring through cloudy sky, wings spread, dramatic clouds, wildlife action shot, high contrast, freedom concept --ar 16:9 --v 6',
    description: 'Aigle en vol avec ciel dramatique'
  },
  {
    category: 'Sport',
    title: 'Surfeur dynamique',
    prompt: 'surfer riding massive wave, action sports photography, water spray, dynamic movement, ocean power, adrenaline moment --ar 2:3 --v 6',
    description: 'Photographie de surf avec vague puissante'
  },
  {
    category: 'Sport',
    title: 'Basketteur sautant',
    prompt: 'basketball player mid-jump shot, sports arena, dramatic lighting, frozen action, athletic power, competitive spirit --ar 3:4 --v 6',
    description: 'Action de basket avec éclairage dramatique'
  },
  {
    category: 'Technologie',
    title: 'Setup gaming RGB',
    prompt: 'high-end gaming setup with RGB lighting, multiple monitors, mechanical keyboard, futuristic atmosphere, neon colors --ar 16:9 --v 6',
    description: 'Configuration gaming avec éclairage RGB'
  },
  {
    category: 'Technologie',
    title: 'Drone futuriste',
    prompt: 'advanced drone in flight, sci-fi design, metallic surface, LED lights, technology concept, sleek engineering --ar 1:1 --v 6',
    description: 'Drone futuriste avec design avancé'
  },
  {
    category: 'Art conceptuel',
    title: 'Ville cyberpunk',
    prompt: 'cyberpunk cityscape at night, neon signs, flying cars, towering buildings, rain-soaked streets, blade runner aesthetic --ar 16:9 --stylize 750 --v 6',
    description: 'Ville futuriste dans style cyberpunk'
  },
  {
    category: 'Art conceptuel',
    title: 'Portail magique',
    prompt: 'magical portal in ancient forest, glowing energy, mystical atmosphere, fantasy art, swirling magic, ethereal light --ar 9:16 --stylize 500 --v 6',
    description: 'Portail fantastique dans forêt ancienne'
  },
  {
    category: 'Vintage',
    title: 'Pin-up rétro',
    prompt: 'vintage pin-up style portrait, 1950s aesthetic, classic pose, retro styling, warm color palette, nostalgic charm --ar 3:4 --v 6',
    description: 'Portrait style pin-up années 50'
  },
  {
    category: 'Vintage',
    title: 'Affiche propagande',
    prompt: 'vintage propaganda poster style, bold typography, limited color palette, strong composition, retro graphic design --ar 2:3 --v 6',
    description: 'Design d\'affiche rétro style propagande'
  }
];

// Composant vidéo réutilisable optimisé
const VideoPlayer = ({ src, title }: { src: string; title: string }) => {
  return (
    <div className="max-w-4xl mx-auto mb-8">
      <div className="relative rounded-2xl overflow-hidden shadow-2xl bg-white/95 backdrop-blur-sm border border-white/20">
        <video
          className="w-full h-auto"
          autoPlay
          muted
          loop
          playsInline
          preload="none"
          loading="lazy"
          style={{ maxHeight: '400px', objectFit: 'cover' }}
        >
          <source src={src} type="video/mp4" />
          Votre navigateur ne supporte pas la lecture vidéo.
        </video>
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent pointer-events-none"></div>
        <div className="absolute bottom-4 left-6 right-6">
          <div className="flex items-center space-x-2 text-white/90">
            <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
            <span className="text-sm font-medium">{title}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export function MidjourneyPage({ currentSubPage = 'tips' }: MidjourneyPageProps) {
  // Protection d'authentification
  useAuthGuard();

  const [searchTerm, setSearchTerm] = useState('');

  const filteredCameraShots = cameraShots.filter(item =>
    item.term.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.example.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredLighting = lightingTypes.filter(item =>
    item.term.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.example.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredStyles = artisticStyles.filter(item =>
    item.term.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.example.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredTips = generalTips.filter(item =>
    item.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.tip.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.example.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredSamples = samplePrompts.filter(item =>
    item.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.prompt.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredMovements = cameraMovementsList.filter(item =>
    item.term.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.example.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredPlanes = cameraPlanesList.filter(item =>
    item.term.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.example.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen pt-4 pb-20">
      <div className="max-w-7xl mx-auto px-6">
        {/* Content Container */}
        <div className="bg-white/60 backdrop-blur-sm rounded-2xl shadow-2xl border border-white/20 overflow-hidden">
          <Tabs value={currentSubPage} className="w-full">
            {/* Tips Généraux Tab */}
            <TabsContent value="tips" className="p-8">
              <VideoPlayer 
                src="https://cdn.midjourney.com/video/c25c18a4-345e-4fb4-b753-e8ae21981e48/3.mp4" 
                title="Tips Généraux - Midjourney" 
              />
              <div className="grid gap-6 md:grid-cols-2">
                {filteredTips.map((item, index) => (
                  <Card
                    key={index}
                    className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 animate-stagger-in"
                    style={{ animationDelay: `${index * 40}ms` }}
                  >
                    <CardHeader className="pb-4">
                      <div className="flex items-center space-x-3 mb-3">
                        <Badge variant="outline" className="border-orange-500/30 text-orange-600 bg-orange-50">
                          {item.category}
                        </Badge>
                      </div>
                      <CardTitle className="text-gray-900 text-xl">{item.tip}</CardTitle>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="bg-gray-50 rounded-lg p-4 border">
                        <code className="text-gray-900 text-sm font-mono">{item.example}</code>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
              {filteredTips.length === 0 && (
                <div className="text-center py-16">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Search className="w-8 h-8 text-gray-400" />
                  </div>
                  <p className="text-gray-500 text-lg">Aucun tip trouvé pour "{searchTerm}"</p>
                </div>
              )}
            </TabsContent>

            {/* Plans & Cadrages Tab */}
            <TabsContent value="camera" className="p-8">
              <VideoPlayer 
                src="https://cdn.midjourney.com/video/67caa1ad-029a-4a73-b67e-531fbf8e2d40/3.mp4" 
                title="Plans & Cadrages - Midjourney" 
              />
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {filteredCameraShots.map((item, index) => (
                  <Card
                    key={index}
                    className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 animate-stagger-in"
                    style={{ animationDelay: `${index * 30}ms` }}
                  >
                    <CardHeader className="pb-4">
                      <CardTitle className="text-orange-600 text-xl font-semibold">{item.term}</CardTitle>
                      <p className="text-gray-600">{item.description}</p>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="bg-gray-50 rounded-lg p-4 border">
                        <code className="text-gray-900 text-sm font-mono">{item.example}</code>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
              {filteredCameraShots.length === 0 && (
                <div className="text-center py-16">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Camera className="w-8 h-8 text-gray-400" />
                  </div>
                  <p className="text-gray-500 text-lg">Aucun plan trouvé pour "{searchTerm}"</p>
                </div>
              )}
            </TabsContent>

            {/* Éclairages Tab */}
            <TabsContent value="lighting" className="p-8">
              <VideoPlayer 
                src="https://cdn.midjourney.com/video/f31c8263-df8a-47cf-9274-9f3117211d93/0.mp4" 
                title="Éclairages - Midjourney" 
              />
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {filteredLighting.map((item, index) => (
                  <Card
                    key={index}
                    className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 animate-stagger-in"
                    style={{ animationDelay: `${index * 30}ms` }}
                    className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 animate-stagger-in"
                    style={{ animationDelay: `${index * 30}ms` }}>
                    <CardHeader className="pb-4">
                      <CardTitle className="text-orange-600 text-xl font-semibold">{item.term}</CardTitle>
                      <p className="text-gray-600">{item.description}</p>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="bg-gray-50 rounded-lg p-4 border">
                        <code className="text-gray-900 text-sm font-mono">{item.example}</code>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
              {filteredLighting.length === 0 && (
                <div className="text-center py-16">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Sun className="w-8 h-8 text-gray-400" />
                  </div>
                  <p className="text-gray-500 text-lg">Aucun éclairage trouvé pour "{searchTerm}"</p>
                </div>
              )}
            </TabsContent>

            {/* Styles Artistiques Tab */}
            <TabsContent value="styles" className="p-8">
              <VideoPlayer 
                src="https://cdn.midjourney.com/video/e548b140-1613-484e-b100-cf37d731d562/3.mp4" 
                title="Styles Artistiques - Midjourney" 
              />
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {filteredStyles.map((item, index) => (
                  <Card
                    key={index}
                    className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 animate-stagger-in"
                    style={{ animationDelay: `${index * 30}ms` }}
                  >
                    <CardHeader className="pb-4">
                      <CardTitle className="text-orange-600 text-xl font-semibold">{item.term}</CardTitle>
                      <p className="text-gray-600">{item.description}</p>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="bg-gray-50 rounded-lg p-4 border">
                        <code className="text-gray-900 text-sm font-mono">{item.example}</code>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
              {filteredStyles.length === 0 && (
                <div className="text-center py-16">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Palette className="w-8 h-8 text-gray-400" />
                  </div>
                  <p className="text-gray-500 text-lg">Aucun style trouvé pour "{searchTerm}"</p>
                </div>
              )}
            </TabsContent>

            {/* Plan Camera Tab */}
            <TabsContent value="plancamera" className="p-8">
              <VideoPlayer 
                src="https://cdn.midjourney.com/video/67caa1ad-029a-4a73-b67e-531fbf8e2d40/3.mp4" 
                title="Mouvements & Plans Caméra" 
              />
              
              <div className="mb-12">
                <div className="flex items-center space-x-3 mb-8 border-b border-orange-100 pb-4">
                  <Play className="w-6 h-6 text-orange-500" />
                  <h2 className="text-2xl font-bold text-gray-900">50 Mouvements de Caméra</h2>
                </div>
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {filteredMovements.map((item, index) => (
                    <Card
                      key={`mov-${index}`}
                      className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 animate-stagger-in"
                      style={{ animationDelay: `${index * 30}ms` }}
                    >
                      <CardHeader className="pb-4">
                        <CardTitle className="text-orange-600 text-xl font-semibold">{item.term}</CardTitle>
                        <p className="text-gray-600">{item.description}</p>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <div className="bg-gray-50 rounded-lg p-4 border">
                          <code className="text-gray-900 text-sm font-mono">{item.example}</code>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              <div>
                <div className="flex items-center space-x-3 mb-8 border-b border-orange-100 pb-4">
                  <Camera className="w-6 h-6 text-orange-500" />
                  <h2 className="text-2xl font-bold text-gray-900">50 Types de Plans</h2>
                </div>
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {filteredPlanes.map((item, index) => (
                    <Card
                      key={`plane-${index}`}
                      className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 animate-stagger-in"
                      style={{ animationDelay: `${index * 30}ms` }}
                    >
                      <CardHeader className="pb-4">
                        <CardTitle className="text-orange-600 text-xl font-semibold">{item.term}</CardTitle>
                        <p className="text-gray-600">{item.description}</p>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <div className="bg-gray-50 rounded-lg p-4 border">
                          <code className="text-gray-900 text-sm font-mono">{item.example}</code>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              {filteredMovements.length === 0 && filteredPlanes.length === 0 && (
                <div className="text-center py-16">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Camera className="w-8 h-8 text-gray-400" />
                  </div>
                  <p className="text-gray-500 text-lg">Aucun mouvement ou plan trouvé pour "{searchTerm}"</p>
                </div>
              )}
            </TabsContent>

            {/* Samples Tab */}
            <TabsContent value="prompts" className="p-8">
              <VideoPlayer 
                src="https://cdn.midjourney.com/video/8c157c1b-35cf-4b5b-b164-336e6f320e95/3.mp4" 
                title="Samples - Midjourney" 
              />
              <div className="grid gap-8 md:grid-cols-2">
                {filteredSamples.map((item, index) => (
                  <Card
                    key={index}
                    className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 animate-stagger-in"
                    style={{ animationDelay: `${index * 50}ms` }}
                  >
                    <CardHeader className="pb-4">
                      <div className="flex items-center justify-between mb-3">
                        <Badge variant="outline" className="border-orange-500/30 text-orange-600 bg-orange-50">
                          {item.category}
                        </Badge>
                        <div className="flex items-center space-x-1 text-gray-400">
                          <ImageIcon className="w-4 h-4" />
                        </div>
                      </div>
                      <CardTitle className="text-gray-900 text-xl font-semibold mb-2">{item.title}</CardTitle>
                      <p className="text-gray-600 text-sm">{item.description}</p>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="bg-gradient-to-br from-gray-50 to-gray-100/50 rounded-lg p-4 border">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs uppercase tracking-wider text-gray-500 font-medium">Prompt complet</span>
                          <button 
                            onClick={() => navigator.clipboard.writeText(item.prompt)}
                            className="text-xs text-orange-600 hover:text-orange-700 transition-colors font-medium"
                          >
                            Copier
                          </button>
                        </div>
                        <code className="text-gray-900 text-sm font-mono leading-relaxed block">{item.prompt}</code>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
              {filteredSamples.length === 0 && (
                <div className="text-center py-16">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <ImageIcon className="w-8 h-8 text-gray-400" />
                  </div>
                  <p className="text-gray-500 text-lg">Aucun exemple trouvé pour "{searchTerm}"</p>
                </div>
              )}
            </TabsContent>

            {/* Videos Tab */}
            <TabsContent value="videos" className="p-8">
              <div className="space-y-8">

                  <div className="space-y-8">
                    {/* DA cinématique Rush - Workflow */}
                    <Card className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 animate-stagger-in" style={{ animationDelay: '0ms' }}>
                      <CardContent className="p-6">
                        <div className="aspect-video rounded-lg mb-4 overflow-hidden shadow-lg">
                          <iframe
                            width="100%"
                            height="100%"
                            src="https://drive.google.com/file/d/1XZr66uhoFzHpsV9eLxH_F149SEVk7v7y/preview"
                            title="DA cinématique Rush - Workflow"
                            frameBorder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowFullScreen
                            className="rounded-lg"
                          ></iframe>
                        </div>
                        <div className="text-center max-w-4xl mx-auto">
                          <h3 className="font-semibold text-gray-900 mb-2 text-xl">DA cinématique Rush - Workflow</h3>
                          <p className="text-gray-900 text-sm mb-4">Découvrez les techniques cinématiques avancées pour créer des compositions visuelles impressionnantes.</p>
                          <div className="flex items-center justify-center space-x-4">
                            <Badge variant="secondary" className="bg-green-50 text-green-700 border border-green-200">
                              Disponible maintenant
                            </Badge>
                            <span className="text-gray-500 text-xs flex items-center space-x-1">
                              <Play className="w-3 h-3" />
                              <span>Vidéo complète</span>
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Vidéo Google Drive - DA Pub Guerlain */}
                    <Card className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 animate-stagger-in" style={{ animationDelay: '150ms' }}>
                      <CardContent className="p-6">
                        <div className="aspect-video rounded-lg mb-4 overflow-hidden shadow-lg">
                          <iframe
                            width="100%"
                            height="100%"
                            src="https://drive.google.com/file/d/1di0I45akc_CUrdiW6juZLh69-tbA17Jw/preview"
                            title="DA Pub Guerlain"
                            frameBorder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowFullScreen
                            className="rounded-lg"
                          ></iframe>
                        </div>
                        <div className="text-center max-w-4xl mx-auto">
                          <h3 className="font-semibold text-gray-900 mb-2 text-xl">DA Pub Guerlain</h3>
                          <p className="text-gray-900 text-sm mb-4">Continuation des techniques avancées de prompt design pour perfectionner votre maîtrise.</p>
                          <div className="flex items-center justify-center space-x-4">
                            <Badge variant="secondary" className="bg-green-50 text-green-700 border border-green-200">
                              Disponible maintenant
                            </Badge>
                            <span className="text-gray-500 text-xs flex items-center space-x-1">
                              <Play className="w-3 h-3" />
                              <span>Vidéo complète</span>
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Vidéo Google Drive - Etude de synchronisation de mouvement */}
                    <Card className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 animate-stagger-in" style={{ animationDelay: '300ms' }}>
                      <CardContent className="p-6">
                        <div className="aspect-video rounded-lg mb-4 overflow-hidden shadow-lg">
                          <iframe
                            width="100%"
                            height="100%"
                            src="https://drive.google.com/file/d/1gQfKUChnkQc-7KarSvT9rc24lQ_Gu0JJ/preview"
                            title="Etude de synchronisation de mouvement"
                            frameBorder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowFullScreen
                            className="rounded-lg"
                          ></iframe>
                        </div>
                        <div className="text-center max-w-4xl mx-auto">
                          <h3 className="font-semibold text-gray-900 mb-2 text-xl">Etude de synchronisation de mouvement</h3>
                          <p className="text-gray-900 text-sm mb-4">Tutoriel complet pour maîtriser les techniques avancées de prompt design et créer des visuels exceptionnels.</p>
                          <div className="flex items-center justify-center space-x-4">
                            <Badge variant="secondary" className="bg-green-50 text-green-700 border border-green-200">
                              Disponible maintenant
                            </Badge>
                            <span className="text-gray-500 text-xs flex items-center space-x-1">
                              <Play className="w-3 h-3" />
                              <span>Vidéo complète</span>
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Workflow automatisation : morphing logo/produit */}
                    <Card className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 animate-stagger-in" style={{ animationDelay: '450ms' }}>
                      <CardContent className="p-6">
                        <div className="aspect-video rounded-lg mb-4 overflow-hidden shadow-lg">
                          <iframe
                            width="100%"
                            height="100%"
                            src="https://drive.google.com/file/d/125ajUJqySj1PK6XqhBWWDyK9Pi2c5gpv/preview"
                            title="Workflow automatisation : morphing logo/produit"
                            frameBorder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowFullScreen
                            className="rounded-lg"
                          ></iframe>
                        </div>
                        <div className="text-center max-w-4xl mx-auto">
                          <h3 className="font-semibold text-gray-900 mb-2 text-xl">Workflow automatisation : morphing logo/produit</h3>
                          <p className="text-gray-900 text-sm mb-4">Découvrez comment automatiser votre workflow de morphing pour logos et produits.</p>
                          <div className="flex items-center justify-center space-x-4">
                            <Badge variant="secondary" className="bg-green-50 text-green-700 border border-green-200">
                              Disponible maintenant
                            </Badge>
                            <span className="text-gray-500 text-xs flex items-center space-x-1">
                              <Play className="w-3 h-3" />
                              <span>Vidéo complète</span>
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Morphing logo/produit Automatisé */}
                    <Card className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 animate-stagger-in" style={{ animationDelay: '600ms' }}>
                      <CardContent className="p-6">
                        <div className="aspect-video rounded-lg mb-4 overflow-hidden shadow-lg">
                          <iframe
                            width="100%"
                            height="100%"
                            src="https://drive.google.com/file/d/1jMdL0Y44i5P57X9wPY58CImnyovLUoCz/preview"
                            title="Morphing logo/produit Automatisé"
                            frameBorder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowFullScreen
                            className="rounded-lg"
                          ></iframe>
                        </div>
                        <div className="text-center max-w-4xl mx-auto">
                          <h3 className="font-semibold text-gray-900 mb-2 text-xl">Morphing logo/produit Automatisé</h3>
                          <p className="text-gray-900 text-sm mb-4">Découvrez comment créer des animations de morphing automatisées pour vos logos et produits.</p>
                          <div className="flex items-center justify-center space-x-4">
                            <Badge variant="secondary" className="bg-green-50 text-green-700 border border-green-200">
                              Disponible maintenant
                            </Badge>
                            <span className="text-gray-500 text-xs flex items-center space-x-1">
                              <Play className="w-3 h-3" />
                              <span>Vidéo complète</span>
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Rotation produit + morphing */}
                    <Card className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 animate-stagger-in" style={{ animationDelay: '750ms' }}>
                      <CardContent className="p-6">
                        <div className="aspect-video rounded-lg mb-4 overflow-hidden shadow-lg">
                          <iframe
                            width="100%"
                            height="100%"
                            src="https://drive.google.com/file/d/1pzq2yFjyyk-LmX8LtLYKYcuxaAYmFvJ9/preview"
                            title="Rotation produit + morphing"
                            frameBorder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowFullScreen
                            className="rounded-lg"
                          ></iframe>
                        </div>
                        <div className="text-center max-w-4xl mx-auto">
                          <h3 className="font-semibold text-gray-900 mb-2 text-xl">Rotation produit + morphing</h3>
                          <p className="text-gray-900 text-sm mb-4">Maîtrisez les techniques de rotation de produits combinées aux effets de morphing pour des visuels dynamiques.</p>
                          <div className="flex items-center justify-center space-x-4">
                            <Badge variant="secondary" className="bg-green-50 text-green-700 border border-green-200">
                              Disponible maintenant
                            </Badge>
                            <span className="text-gray-500 text-xs flex items-center space-x-1">
                              <Play className="w-3 h-3" />
                              <span>Vidéo complète</span>
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

<VideoPlayer src="https://res.cloudinary.com/dt2d5xq0e/video/upload/v1736783847/file3-compressed_t0zphc.mp4" title="Tutoriel Avancé Prompt design" />
                    
                    {/* Vidéo YouTube retirée pour contenu inapproprié */}
                    
                    <VideoPlayer src="https://res.cloudinary.com/dt2d5xq0e/video/upload/v1736783846/file2-compressed_l09ygn.mp4" title="Techniques Créatives" />
                    <VideoPlayer src="https://res.cloudinary.com/dt2d5xq0e/video/upload/v1736783846/file1-compressed_k8xknw.mp4" title="Astuces Pro" />
                  </div>
                </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
import { useState, useMemo } from 'react';
import { Tabs, TabsContent } from './ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogTrigger, DialogTitle, DialogDescription } from './ui/dialog';
import { BookOpen, ExternalLink, FolderOpen, ZoomIn, Palette, PenTool, Bot } from 'lucide-react';

interface ProgrammePageProps {
  currentSubPage?: string;
}
import affichesImage from 'figma:asset/1e82f71af6957d0d645e8123205b822b9520552a.png';
import objetsImage from 'figma:asset/9be344fe0ded1a55c1c5b5a2f54e17aad2ea7f2b.png';
import iconographieImage from 'figma:asset/a3a56efc7ef1c087631ed505571ce7aa0bc42ebd.png';
import vogueImage from 'figma:asset/e659ce02542ebf0381c3b771135651b83b75f11a.png';
import albumImage from 'figma:asset/bcd08c269b8179c59e953aba0f75c79af258ce78.png';
import motifImage from 'figma:asset/22be29f99e118bcb254122ca033b6b0fe9151775.png';
import gifAnimeImage from 'figma:asset/1ab8f6a05e961b82ed50cb18ec8c5902d3e85f97.png';
import surrealismeImage from 'figma:asset/500ae8750e44af746b0c2dbe1634f79c4908ebd6.png';
import cutheadImage from 'figma:asset/ab89dba2ee3d2ca4401ff7f752d5c6ad8dd4f5b8.png';
import doubleExposureImage from 'figma:asset/2a707d105b65d604205e0396621eca4f84cbfe42.png';
import designAppImage from 'figma:asset/4e915aeb4b1ea86274c2548bf2d4c2a9b8fa99a4.png';
import wordAsImageImage from 'figma:asset/1ba0cc355e0f0fa320c88799e6f326858e5b9619.png';
import logoConcepteurImage from 'figma:asset/396351d4d5224737977c0d4b4b1e74fea8225034.png';
import trameImage from 'figma:asset/18746a0ffbde6a23beebc7b7a2bda6ea5590bd61.png';
import motifCameleonIllustratorImage from 'figma:asset/75dc6ef802a4b5722b9a8a47d6f8686d68555d07.png';
import conceptNftImage from 'figma:asset/705c2b91664d06284b1b2de937fa5b36ffe52171.png';
import simpsonImage from 'figma:asset/c572f8850a41864e4f4110a86a6c8c5e505eace9.png';
import logoEspaceNegatifImage from 'figma:asset/ed98d3b8729fd4856e2c67e4c65ab8a5f5495ab9.png';
import grilleGraphiqueImage from 'figma:asset/fa6c2f30804e89b29d11f652dae0eb7c0f0924f8.png';
import transparenceImage from 'figma:asset/4ec5d00f3c877c0b12bcb22ac57856b61f974ce7.png';
import lightningImage from 'figma:asset/167f2ca9c0b99b00684716d10bc7c65c384a3197.png';
import miniaturisationImage from 'figma:asset/c5ad4ae6566b2dd3ab0ed71bbc030f13a79196af.png';
import { useAuthGuard } from './useAuth';

interface ModuleData {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  objectives: string;
  advice: string;
  techniques: string;
  format: string;
  notation: {
    criteria1: string;
    criteria2: string;
    score1: string;
    score2: string;
  };
  image: string;
}

const photoshopModules: ModuleData[] = [
  {
    id: 'affiches',
    title: 'INFOGRAPHIE - PHOTOSHOP',
    subtitle: 'AFFICHES SPORT/CULTURE',
    description: 'Créez une affiche entrelacée inspirée de style graphique de danse hip/hop et ou classique/contemporain dans photoshop en entrelaçant la typographie et le visuel.',
    objectives: 'Apprendre à détourage parfaitement, et apprendre à composer avec la typographie tout en respectant ses codes.',
    advice: 'Choisir une belle photo détourable, puis faire un choix typographique cohérent graphiquement avec l\'image.',
    techniques: 'Les techniques principales les plus utilisées pour ce type d\'image sont le détourage, masque',
    format: '300 DPI - CMJN',
    notation: {
      criteria1: 'MAITRISE DES OUTILS DE REALISATION',
      criteria2: 'PERFORMANCE VISUELLE/ORIGINALITÉ',
      score1: '10/20',
      score2: '10/20'
    },
    image: affichesImage
  },
  {
    id: 'objets',
    title: 'INFOGRAPHIE - PHOTOSHOP',
    subtitle: 'OBJETS SURRÉALISTES',
    description: 'Créez des objets surréalistes dans photoshop',
    objectives: 'Apprendre à bien choisir ses images (étapes 2), Utilisez les techniques nécessaires à l\'ajustement.',
    advice: 'Bien choisir ses images. Faire en sorte que couleur et formes puissent facilement fusionner. Certains objets peuvent nettement mieux fusionner entre eux (ex: pomme/ oeuf) que d\'autres.',
    techniques: 'Les techniques principales les plus utilisées pour ce type d\'image sont le détourage, les ajustements chromatiques, tampon de duplication, palette de fusion.',
    format: '300 DPI - CMJN',
    notation: {
      criteria1: 'MAITRISE DES OUTILS DE REALISATION',
      criteria2: 'PERFORMANCE VISUELLE/ORIGINALITÉ',
      score1: '10/20',
      score2: '10/20'
    },
    image: objetsImage
  },
  {
    id: 'iconographie',
    title: 'INFOGRAPHIE - PHOTOSHOP',
    subtitle: 'ICONOGRAPHIE',
    description: 'Créez un prolongement en utilisant deux images bien choisie',
    objectives: 'Apprendre à choisir ses visuels et savoir reconnaître à l\'avance deux visuels ayant la capacité de fonctionner ensemble.',
    advice: 'Bien choisir ses images. le travail est surtout selectif il faut également un peu ajuster les visuels en terme de taille, de fond, et de colorimétrie dans photoshop.',
    techniques: 'Les techniques principales les plus utilisées pour ce type d\'image sont le détourage, les ajustements chromatiques.',
    format: '300 DPI - CMJN',
    notation: {
      criteria1: 'MAITRISE DES OUTILS DE REALISATION',
      criteria2: 'PERFORMANCE VISUELLE/ORIGINALITÉ',
      score1: '10/20',
      score2: '10/20'
    },
    image: iconographieImage
  },
  {
    id: 'vogue',
    title: 'INFOGRAPHIE - PHOTOSHOP',
    subtitle: 'Couverture Magazine Vogue',
    description: 'Créez la couverture de vogue en ayant parfaitement retouché le visage.',
    objectives: 'Cherchez une thématique pour le visuel et titre et sous titres.',
    advice: 'ICONOGRAPHIE : Trouver à l\'aide de google, de site d\'image, ou d\'IA un visuel cohérent et au niveau pour une couverture de Vogue. RETOUCHE DU VISUEL : Il est indispensable, de retoucher le visage et corps si des côtés, colorimétrie, dose sud burn, carnae, visibilité de la pupille et/ou couleur des yeux, léger lissage, et détourage à la plume pour les cheveux et corps pour fon noir et ou taches, et détourage détection de couleur (masque) pour les cheveux.',
    techniques: 'Le masque, le détourage, les color dodges, les fusions, les outils de déformations et d\'ajustement, la fluidité',
    format: 'MISE EN PAGE PHOTOSHOP : mettre en page le visuel dans le format 21x30, faire figurer les débords de couverture dans votre fichier .PSD insérer les 2 titres et sous-titre d\'actualité Typographie Bodoni',
    notation: {
      criteria1: 'MAITRISE DE LA DEMARCHE CREATIVE',
      criteria2: 'MAITRISE DES RETOUCHES',
      score1: '6/20',
      score2: '8/20'
    },
    image: vogueImage
  },
  {
    id: 'album',
    title: 'INFOGRAPHIE - PHOTOSHOP',
    subtitle: 'ALBUM MUSIQUE',
    description: 'Re-créez le visuel d\'un album Mythique de l\'Histoire de la musique. Vous devez repartir de zéro, comme si rien n\'avait jamais été produit pour l\'artiste en question. Il faut également positionner votre création dans les codes graphique de notre époque.',
    objectives: 'FORMAT : 300 DPI - CMJN - 30x30cm CONSEILS : Vous pouvez utiliser illustrator pour dessiner. Vous pouvez également dessiner à la main. Vous pouvez utiliser des photos. Le rendu notre final doit Photoshop.',
    advice: 'Bien écouter la musique de l\'album, pour tenter de créer une cohérence entre son et image. Vous pouvez tenter également la cohérence entre le son et le texte.',
    techniques: 'FORMAT : 300 DPI - CMJN - 30x30cm CONSEILS : Vous pouvez utiliser illustrator pour dessiner. Vous pouvez également dessiner à la main. Vous pouvez utiliser des photos. Le rendu notre final doit Photoshop.',
    format: '300 DPI - CMJN - 30x30cm',
    notation: {
      criteria1: 'MAITRISE DES OUTILS DE REALISATION',
      criteria2: 'PERFORMANCE VISUELLE/ORIGINALITÉ',
      score1: '10/20',
      score2: '10/20'
    },
    image: albumImage
  },
  {
    id: 'motif',
    title: 'INFOGRAPHIE - PHOTOSHOP',
    subtitle: 'MOTIF " CAMELEON "',
    description: 'Insérer vos motifs sur votre support à l\'aide de Photoshop. Cette insertion sera sur le même modèle que le visuel ci-joint (rendu Cameleon)',
    objectives: 'ENVISAGEZ LE SUPPORT FINAL : Il est indispensable, pour une meilleure cohérence, de définir dès le début, le support sur lequel le motif sera posé.',
    advice: 'CONNAÎTRE & MAÎTRISER LES OUTILS NÉCESSAIRES À L\'INSERTION / INCRUSTATION SUR PHOTOSHOP : Le masque, le détourage, les color dodges, les fusions, les outils de déformations et d\'ajustement, la fluidité. ATTENTION ! Tenir compte de la fabrication de l\'objet (soudure, couture, ...) Pour insérer votre motif de manière la plus crédible possible. Un bon photo-montage ne doit pas être perceptible.',
    techniques: 'Le masque, le détourage, les color dodges, les fusions, les outils de déformations et d\'ajustement, la fluidité',
    format: '300 DPI - CMJN',
    notation: {
      criteria1: 'MAITRISE DES OUTILS DE REALISATION',
      criteria2: 'INTERACTIONS OBJETS/MOTIFS',
      score1: '10/20',
      score2: '10/20'
    },
    image: motifImage
  },
  {
    id: 'gifAnime',
    title: 'INFOGRAPHIE - PHOTOSHOP',
    subtitle: 'GIF ANIMÉ',
    description: 'Créez un gif animé avec votre Pixel art NFT pour vous entraîner, puis pour les voeux 2022',
    objectives: 'RÉFÉRENCEZ VOUS ! Regardez sur les différents sites tel, que Giphy, deviantart, https://opensea.io/, Pinterest pour vous inspirer',
    advice: 'POSSIBILITÉ : Il vous est possible de dessiner sur illustrator et/ou Photoshop et d\'animer sur Photoshop, et/ou de dessiner à la main. Vous pouvez également utiliser une photo. NE TOMBEZ PAS DANS LES CLICHÉS : Pour la carte de voeux, il est important de ne pas confondre noël et la nouvelle année. Il est fortement déconseillé d\'utiliser des éléments trop génériques et peu originaux, comme les coupes de champagne, feux d\'artifice, etc. Bref soyez originaux !',
    techniques: 'Les techniques principales les plus utilisées pour ce type d\'image sont le détourage, les ajustements chromatiques, tampon de duplication, palette de fusion, timeline d\'animation.',
    format: '300 DPI - CMJN',
    notation: {
      criteria1: 'MAITRISE DES OUTILS DE REALISATION',
      criteria2: 'ORIGINALITÉ',
      score1: '10/20',
      score2: '5/20'
    },
    image: gifAnimeImage
  },
  {
    id: 'surrealisme',
    title: 'INFOGRAPHIE - PHOTOSHOP',
    subtitle: 'SURRÉALISME',
    description: 'Créez une image surréaliste à l\'aide de Photoshop',
    objectives: 'QUE DOIS CONTENIR L\'IMAGE ? Il faut réaliser un photo-montage à l\'aide d\'image existante récoltée sur Internet. L\'image doit évoquer une scène non réelle, non réaliste.',
    advice: 'POSSIBILITÉS : Il faut favoriser le travail photographique. Pensez à utiliser de belles photos au départ, cela permet un beau rendu au final.',
    techniques: 'Les techniques principales les plus utilisées pour ce type d\'image sont le détourage, les ajustements chromatiques, le tampon de duplication, les fusions.',
    format: '300 DPI - CMJN',
    notation: {
      criteria1: 'MAITRISE DES OUTILS DE REALISATION',
      criteria2: 'PERFORMANCE VISUELLE/ORIGINALITÉ',
      score1: '10/20',
      score2: '10/20'
    },
    image: surrealismeImage
  },
  {
    id: 'cuthead',
    title: 'INFOGRAPHIE - PHOTOSHOP',
    subtitle: 'CUTHEAD',
    description: 'Créez une image dans photoshop en coupant le visage d\'une personne',
    objectives: 'QUE DOIS CONTENIR L\'IMAGE ? L\'image doit contenir un personnage qui à la tête coupé en deux. Il peut s\'agir d\'une illustration ou d\'une photo. Le travail de coupe doit obligatoirement être effectué dans Photoshop',
    advice: 'CONSEILS : L\'idéal étant de choisir deux très belles images et d\'évaluer les potentiels de photo-montage. Votre imagination doit être mise en action.',
    techniques: 'Les techniques principales les plus utilisées pour ce type d\'image sont le détourage, les ajustements chromatiques, tampon de duplication, techniques d\'ombrages, dégradés et volume.',
    format: '300 DPI - CMJN - 30x30cm',
    notation: {
      criteria1: 'MAITRISE DES OUTILS DE REALISATION',
      criteria2: 'PERFORMANCE VISUELLE/ORIGINALITÉ',
      score1: '10/20',
      score2: '10/20'
    },
    image: cutheadImage
  },
  {
    id: 'doubleExposure',
    title: 'INFOGRAPHIE - PHOTOSHOP',
    subtitle: 'DOUBLE EXPOSURE',
    description: 'Réalisez une double exposure dans Photoshop à l\'aide de deux photographies',
    objectives: 'QU\'EST CE QU\'UNE DOUBLE EXPOSURE ? Il s\'agit de deux images qui fusionnent par le phénomène de surexposition.',
    advice: 'CONSEILS : Bien choisir ses images. Il faut que le portrait et le paysage aient la même couleur de fond. L\'idéal étant de détourer le portrait pour permettre une fusion des deux images plus facilement.',
    techniques: 'Les techniques principales les plus utilisées pour ce type d\'image sont le détourage, les ajustements chromatiques, tampon de duplication, palette de fusion.',
    format: '300 DPI - CMJN',
    notation: {
      criteria1: 'MAITRISE DES OUTILS DE REALISATION',
      criteria2: 'PERFORMANCE VISUELLE/ORIGINALITÉ',
      score1: '10/20',
      score2: '10/20'
    },
    image: doubleExposureImage
  },
  {
    id: 'transparence',
    title: 'INFOGRAPHIE - PHOTOSHOP',
    subtitle: 'TRANSPARENCE',
    description: 'Créez un visuel à partir d\'une photo où un objet devient transparent.',
    objectives: 'Savoir manipuler une photo pour y insérer une transparence.',
    advice: 'Version simple et moins persuasive : Choisir une image avec une personne et un objet simple à soustraire, et choisir une autre photo comme décors de fond. Version plus complexe et plus persuasive (cf Photos exemple) : Choisir une seule image, découper l\'élément, puis le soustraire. Recréer à l\'aide du tampon de duplication la zone vide (exception : si vous êtes le photographe, vous pouvez faire une photo sans le personnage et une photo avec CF dessous le photographe, vous pouvez faire une photo sans le personnage et une photo avec).',
    techniques: 'détourage - contour progressif - tampon de duplication.',
    format: '300 DPI - CMJN 30x30 cm',
    notation: {
      criteria1: 'MAITRISE DES OUTILS DE REALISATION',
      criteria2: 'PERFORMANCE VISUELLE/ORIGINALITÉ',
      score1: '10/20',
      score2: '10/20'
    },
    image: transparenceImage
  },
  {
    id: 'lightning',
    title: 'INFOGRAPHIE - PHOTOSHOP',
    subtitle: 'LIGHTNING',
    description: 'Customisez un ou plusieurs visuels de votre choix en rajoutant divers effets lumineux.',
    objectives: 'Savoir manipuler les effets de lumières dans Photoshop.',
    advice: 'Choisir des préférences une image sombre ou prise la nuit pour mieux faire ressortir les effets.',
    techniques: 'Fluidité - lueur externe/interne, biseautage, dégradé, halo, fusion, pinceau, contour progressif, flou, ajustement colorimétrique',
    format: '300 DPI - CMJN 30x30 cm',
    notation: {
      criteria1: 'MAITRISE DES OUTILS DE REALISATION',
      criteria2: 'PERFORMANCE VISUELLE/ORIGINALITÉ',
      score1: '10/20',
      score2: '10/20'
    },
    image: lightningImage
  },
  {
    id: 'miniaturisation',
    title: 'INFOGRAPHIE - PHOTOSHOP',
    subtitle: 'MINIATURISATION & AGRANDISSEMENT',
    description: 'Créez une image dans photoshop à l\'aide des deux photographie différences.',
    objectives: 'L\'image doit mettre en évidence une réduction ou un agrandissement d\'un objet et/ou personnage',
    advice: 'L\'idéal étant de choisir deux très belles images et d\'évaluer les potentiels de photo-montage. Votre imagination doit être mise en action. Les thèmes un peu poétique peuvent être intéressant, ainsi que l\'humour',
    techniques: 'Les techniques principales les plus utilisées pour ce type d\'image sont le détourage, les ajustements chromatiques.',
    format: '300 DPI - CMJN',
    notation: {
      criteria1: 'MAITRISE DES OUTILS DE REALISATION',
      criteria2: 'PERFORMANCE VISUELLE/ORIGINALITÉ',
      score1: '10/20',
      score2: '10/20'
    },
    image: miniaturisationImage
  },
  {
    id: 'designApp',
    title: 'INFOGRAPHIE - PHOTOSHOP',
    subtitle: 'DESIGN APP',
    description: 'Concevez et designer votre propre application',
    objectives: 'Concevoir un projet réaliste et réaliser dans Photoshop ses pages types pour une première présentation.',
    advice: 'DÉTAILS : créez 4 pages type : Home page et 3 pages intérieure',
    techniques: 'Les techniques principales les plus utilisées pour ce type d\'image sont le détourage, les ajustements chromatiques, tampon de duplication, palette de fusion.',
    format: '300 DPI - CMJN',
    notation: {
      criteria1: 'MAITRISE DES OUTILS DE REALISATION',
      criteria2: 'EFFICACITÉ, MODERNITÉ',
      score1: '10/20',
      score2: '10/20'
    },
    image: designAppImage
  }
];

const illustratorModules: ModuleData[] = [
  {
    id: 'wordAsImage',
    title: 'INFOGRAPHIE/DG1 - ILLUSTRATOR',
    subtitle: 'WORD AS IMAGE',
    description: 'Réalisez une modification dans une typographie pour aider à la compréhension du sens d\'un mot.',
    objectives: 'TECHNIQUE : travail autour de la palette texte/caractère, vectorisation et modification autorisée. MINIMISER AU MAXIMUM : Il faut essayer de parvenir au résultat en modifiant le minimum d\'éléments dans la typographie. Plus la modification est minime et le résultat est atteint, plus le travail est de qualité. Il s\'agit ici d\'un travail de concision.',
    advice: 'COMMENT RENDRE MON WORD AS IMAGE EFFICACE ? - Simplicité & concision (ne pas chercher à en faire trop) - Travailler les espaces entre les lettres si c\'est possible - Ne pas déformer les lettres n\'importe comment, il faut tenir compte des règles typographiques évoquées en cours.',
    techniques: 'Travail autour de la palette texte/caractère, vectorisation et modification autorisée',
    format: '300 DPI - CMJN',
    notation: {
      criteria1: 'MAITRISE DES OUTILS DE REALISATION',
      criteria2: 'EFFICACITÉ, MODERNITÉ',
      score1: '10/20',
      score2: '10/20'
    },
    image: wordAsImageImage
  },
  {
    id: 'logoConcepteur',
    title: 'INFOGRAPHIE/DG1 - ILLUSTRATOR',
    subtitle: 'LOGO CONCEPTEUR DE FORME',
    description: 'Réalisez un logotype pour cette association en utilisant la technique du pathfinder ou du concepteur de forme. Vous pouvez voir le nom de votre association.',
    objectives: 'APPRENDRE À DESSINER EN UTILISANT LA GÉOMÉTRIE : Utiliser un rond parfait de différentes tailles pour composer son dessin graphique. Ce dessin peut être intégré au lettrage ou sur un idéogramme (isolé). Le lettrage choisi doit être en cohérence avec la forme de l\'idéogramme.',
    advice: 'COMMENT RENDRE MON LOGOTYPE EFFICACE AVEC CETTE TECHNIQUE ? - Simplicité & concision (ne pas chercher à en faire trop) - Dessiner sur papier une esquisse rapide avant réalisation. - Travailler le logo en noir et blanc, puis finalisez-le en proposant des choix de couleur.',
    techniques: 'Utiliser un rond parfait de différentes tailles pour composer son dessin graphique. Ce dessin peut être intégré au lettrage ou sur un idéogramme (isolé). La courbe de Bézier, les outils de dessin, la vectorisation, le pathfinder ou le concepteur de forme.',
    format: 'Rendu sous forme de planche paysage format A4. Il doit figurer la version noir & blanc, une version colorée, la version colorée devra également être déclinée en 3 tailles différentes (petit, moyen & grand)',
    notation: {
      criteria1: 'MAITRISE DES OUTILS DE REALISATION',
      criteria2: 'EFFICACITÉ, MODERNITÉ',
      score1: '10/20',
      score2: '10/20'
    },
    image: logoConcepteurImage
  },
  {
    id: 'trame',
    title: 'INFOGRAPHIE/DG1 - ILLUSTRATOR',
    subtitle: 'TRAME',
    description: 'Concevez une illustration libre en utilisant la technique des trames.',
    objectives: 'TYPE DE RENDU : La thématique du dessin est libre, il peut-être abstrait ou figuratif.',
    advice: 'EFFICACITÉ : - Pour un meilleur rendu, utilisez les sites références pour chercher une orientation la plus moderne possible. - Il faut essayer de dépasser le simple usage de l\'outil en produisant un résultat novateur, une idée simple et efficace, un graphisme plaisant.',
    techniques: 'Utilisez les techniques de duplication horizontale, verticale, en rotation, et transformation répartie, dégradé de formes expliquées en cours, pour concevoir votre illustration libre.',
    format: '300 DPI - CMJN',
    notation: {
      criteria1: 'MAITRISE DES OUTILS DE REALISATION',
      criteria2: 'EFFICACITÉ, MODERNITÉ',
      score1: '10/20',
      score2: '10/20'
    },
    image: trameImage
  },
  {
    id: 'motifCameleonIllustrator',
    title: 'INFOGRAPHIE/DG1 - ILLUSTRATOR',
    subtitle: 'MOTIF " CAMELEON "',
    description: 'Réalisez un motif vectoriel, en tenant compte de ses différentes valeur ajoutée, puis insérer ce motif sur votre support à l\'aide de Photoshop. Cette insertion sera sur le même modèle que le visuel ci-joint (rendu Caméléon / PS : La partie "insertion" sera réalisée en cours de Photoshop)',
    objectives: 'FAIRE DES RECHERCHES SUR LES GRANDES TENDANCES DE MOTIF : Recherchez sur des sites tel que Pinterest ou Behance, le type de motif que l\'on réalise à l\'heure actuelle. Ne pas hésiter à chercher ou il vous semble bon (livres, décoration, cahier de tendance...) Plus vous effectuez de recherches dans des supports différents, plus vous parviendrez à créer un motif performant, et original.',
    advice: 'OBSERVER LA NATURE / VOTRE ENVIRONNEMENT : Beaucoup de motif sont issu de la nature. Bien regarder autour de soi les motifs, que l\'on croise au quotidien. ENVISAGEZ LE SUPPORT FINAL : Il est indispensable, pour une meilleure cohérence, de définir dès le début, le support sur lequel le motif sera posé. CONNAÎTRE & MAÎTRISER LES OUTILS NÉCESSAIRES À LEUR CRÉATION SUR ILLUSTRATOR : La courbe de Bézier, les outils de dessin, la vectorisation, le pathfinder ou le concepteur de forme. Les outils de duplication horizontale, verticale, rotation, symétrie.',
    techniques: 'CONNAÎTRE & MAÎTRISER LES VALEURS AJOUTÉES DU MOTIF : - De la façon dont on le duplique, un motif peut considérablement gagner en valeur. - Il est parfois préférable de choisir les systèmes de duplication asymétrique. - Il faut minimiser les couleurs, et parvenir à un bon rendu. - Il faut que le motif fonctionne sur son support final (ton sur ton ex : certains motifs, marcheront très bien en décoration et ne fonctionneront pas sur du textile) - Dans un souci de perfection, on peut également travailler les espaces négatifs de son motif.',
    format: '300 DPI - CMJN',
    notation: {
      criteria1: 'MAITRISE DES OUTILS DE REALISATION',
      criteria2: 'EFFICACITÉ, MODERNITÉ',
      score1: '10/20',
      score2: '10/20'
    },
    image: motifCameleonIllustratorImage
  },
  {
    id: 'conceptNft',
    title: 'INFOGRAPHIE/DG1 - ILLUSTRATOR',
    subtitle: 'CONCEPT NFT & PIXEL ART',
    description: 'Création d\'une illustration Pixel art dans Illustrator. Utilisez ce traité pour concevoir un projet personnel qui pourrait illustrer un sujet de société, un fait d\'actualité, ou autres. (nous discuterons des possibilités en cours)',
    objectives: 'Utiliser ces éléments pixel dans le cours de Photoshop pour réaliser des gifs animés NFT qui seront transférés (pour ceux qui souhaitent réaliser le projet jusqu\'au bout) vers les plate forme crypto (ex https://opensea.io/, etc...). L\'objectif étant de se familiariser à cette nouvelle forme d\'art qu\'est le NFT, tout en apprenant les techniques nécessaire dans illustrator et Photoshop',
    advice: 'RÉFÉRENCEZ VOUS ! Regardez sur les différents sites tel, que Giphy, deviantart, https://opensea.io/, Pinterest pour vous inspirer',
    techniques: 'Les techniques principales les plus utilisées pour ce type d\'image sont le détourage, les ajustements chromatiques, tampon de duplication, palette de fusion, timeline d\'animation.',
    format: '300 DPI - CMJN',
    notation: {
      criteria1: 'MAITRISE DES OUTILS DE REALISATION',
      criteria2: 'EFFICACITÉ, MODERNITÉ',
      score1: '10/20',
      score2: '10/20'
    },
    image: conceptNftImage
  },
  {
    id: 'simpson',
    title: 'INFOGRAPHIE/DG1 - ILLUSTRATOR',
    subtitle: 'SIMPSON',
    description: 'Représentez vous en simpson en utilisant les outils de dessin vectoriel dans illustrator',
    objectives: 'Comprendre une charte graphique illustrative et parvenir à décliner un personnage supplémentaire.',
    advice: 'ASTUCES : - Choisissez un personnage des simpsons qui vous ressemble un peu, ainsi vous pourrez bénéficier d\'un dessin de base. - Pensez qu\'il s\'agit d\'une série comique, il est donc intéressant que votre simpson fasse réagir en ce sens.',
    techniques: 'Utilisation des outils de dessin vectoriel d\'Illustrator, courbe de Bézier, formes géométriques, dégradés et couleurs.',
    format: '300 DPI - CMJN',
    notation: {
      criteria1: 'MAITRISE DES OUTILS DE REALISATION',
      criteria2: 'EFFICACITÉ, MODERNITÉ',
      score1: '10/20',
      score2: '10/20'
    },
    image: simpsonImage
  },
  {
    id: 'grilleGraphique',
    title: 'INFOGRAPHIE/DG1 - ILLUSTRATOR',
    subtitle: 'GRILLE GRAPHIQUE',
    description: 'Créez une grille graphique qui vous permettra de parfaitement décliner un principe visuel sur au moins 2 affiches. Le thème de l\'affiche sera l\'événement "rendez-vous aux jardins" il doit figurer le même texte que celle sur la droite',
    objectives: 'Concevoir une grille graphique pour une affiche. Comprendre la notion de grille graphique : Il s\'agit d\'un outil de construction qui permet de décliner parfaitement un principe graphique. Dans un premier temps, il faut concevoir un motif en rapport avec son sujet (C\'est préférable). Ce motif doit être ensuite utilisé comme base de construction pour les 2 affiches OBLIGATOIREMENT.',
    advice: 'Rendu : 30x40 cm - CMJN - 300 DPI. 2 versions de l\'affiche déclinées à partir de la même grille graphique.',
    techniques: 'Les techniques principales les plus utilisées pour ce type d\'image sont la conception de grilles graphiques, motifs de construction, déclination.',
    format: '30x40 cm - CMJN - 300 DPI',
    notation: {
      criteria1: 'MAITRISE DES OUTILS DE REALISATION',
      criteria2: 'EFFICACITÉ, MODERNITÉ',
      score1: '10/20',
      score2: '10/20'
    },
    image: grilleGraphiqueImage
  },
  {
    id: 'logoEspaceNegatif',
    title: 'INFOGRAPHIE/DG1 - ILLUSTRATOR',
    subtitle: 'LOGO ESPACE NÉGATIF',
    description: 'Réalisez un logotype pour un restaurant, en utilisant la technique des espaces négatifs. Vous êtes libre sur le choix du type de restaurant (sushi - burger - Gastro, ...). Vous devez également trouver un nom de restaurant facilitant la réalisation de cet espace négatif (à l\'aide du choix typo et des différentes lettres.)',
    objectives: 'COMPRENDRE LA NOTION D\'ESPACE NÉGATIF : Il s\'agit d\'un espace vide qui dessine quelque chose.',
    advice: 'COMMENT RENDRE MON LOGOTYPE EFFICACE AVEC CETTE TECHNIQUE ? - Simplicité & concision (ne pas chercher à en faire trop) - Travailler les pleins et les vides pour qu\'il dessinent deux éléments différents (ex:ensemble) - Travailler le logo en noir et blanc, puis finalisez-le en proposant des choix de couleur. - Choisissez efficacement votre lettrage. - Essayez au maximum de décrire la valeur ajoutée du restaurant.',
    techniques: 'Il s\'agit d\'un espace vide qui dessine quelque chose.',
    format: 'Rendu sous forme de planche paysage format A4. Il doit figurer la version noir & blanc, une version colorée, la version colorée devra également être déclinée en 3 tailles différentes (petit, moyen & grand)',
    notation: {
      criteria1: 'MAITRISE DES OUTILS DE REALISATION',
      criteria2: 'EFFICACITÉ, MODERNITÉ',
      score1: '10/20',
      score2: '10/20'
    },
    image: logoEspaceNegatifImage
  }
];

export function ProgrammePage({ currentSubPage = 'photoshop' }: ProgrammePageProps) {
  // Protection d'authentification
  useAuthGuard();

  return (
    <div className="min-h-screen pt-4 pb-20">
      <div className="max-w-7xl mx-auto px-6">
        {/* Content Container */}
        <div className="bg-white/60 backdrop-blur-sm rounded-2xl shadow-2xl border border-white/20 overflow-hidden">
          <Tabs value={currentSubPage} className="w-full">
            {/* Photoshop Tab */}
            <TabsContent value="photoshop" className="pt-5 px-8 pb-8">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {photoshopModules.map((module, index) => (
                  <Card
                    key={index}
                    className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 group animate-stagger-in"
                    style={{ animationDelay: `${index * 100}ms` }}
                  >
                    <div className="relative">
                      <div className="w-full h-96 overflow-hidden rounded-t-lg">
                        <img
                          src={module.image}
                          alt={module.subtitle}
                          loading="lazy"
                          className="w-full h-full object-contain p-4 group-hover:scale-105 transition-transform duration-300"
                        />
                      </div>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            className="absolute top-2 right-2 bg-black/50 text-white hover:bg-black/70 rounded-full w-8 h-8 p-0"
                          >
                            <ZoomIn className="w-4 h-4" />
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-4xl max-h-[90vh] overflow-auto">
                          <DialogTitle>{module.subtitle}</DialogTitle>
                          <DialogDescription>
                            Aperçu du module de formation {module.subtitle}
                          </DialogDescription>
                          <img
                            src={module.image}
                            alt={module.subtitle}
                            loading="lazy"
                            className="w-full h-auto max-h-[70vh] object-contain"
                          />
                        </DialogContent>
                      </Dialog>
                    </div>
                    <CardHeader className="pb-4">
                      <CardTitle className="text-orange-600 text-xl font-semibold">{module.subtitle}</CardTitle>
                      <CardDescription className="text-gray-800">{module.title}</CardDescription>
                    </CardHeader>
                    <CardContent className="pt-0 space-y-4">
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2">Description</h4>
                        <p className="text-gray-900 text-sm leading-relaxed">{module.description}</p>
                      </div>
                      
                      <Separator />
                      
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2">Objectifs</h4>
                        <p className="text-gray-900 text-sm leading-relaxed">{module.objectives}</p>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2">Conseils</h4>
                        <p className="text-gray-900 text-sm leading-relaxed">{module.advice}</p>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2">Techniques</h4>
                        <p className="text-gray-900 text-sm leading-relaxed">{module.techniques}</p>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2">Format</h4>
                        <Badge variant="secondary" className="bg-orange-50 text-orange-700 border border-orange-200 whitespace-normal break-words inline-block w-full">
                          {module.format}
                        </Badge>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2">Notation</h4>
                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-gray-800">{module.notation.criteria1}</span>
                            <Badge variant="outline" className="text-orange-600 border-orange-200">
                              {module.notation.score1}
                            </Badge>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-gray-800">{module.notation.criteria2}</span>
                            <Badge variant="outline" className="text-orange-600 border-orange-200">
                              {module.notation.score2}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Illustrator Tab */}
            <TabsContent value="illustrator" className="pt-5 px-8 pb-8">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {illustratorModules.map((module, index) => (
                  <Card
                    key={index}
                    className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 group animate-stagger-in"
                    style={{ animationDelay: `${index * 100}ms` }}
                  >
                    <div className="relative">
                      <div className="w-full h-96 overflow-hidden rounded-t-lg">
                        <img
                          src={module.image}
                          alt={module.subtitle}
                          loading="lazy"
                          className="w-full h-full object-contain p-4 group-hover:scale-105 transition-transform duration-300"
                        />
                      </div>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="absolute top-2 right-2 bg-black/50 text-white hover:bg-black/70 rounded-full w-8 h-8 p-0"
                          >
                            <ZoomIn className="w-4 h-4" />
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-4xl max-h-[90vh] overflow-auto">
                          <DialogTitle>{module.subtitle}</DialogTitle>
                          <DialogDescription>
                            Aperçu du module de formation {module.subtitle}
                          </DialogDescription>
                          <img
                            src={module.image}
                            alt={module.subtitle}
                            className="w-full h-auto max-h-[70vh] object-contain"
                          />
                        </DialogContent>
                      </Dialog>
                    </div>
                    <CardHeader className="pb-4">
                      <CardTitle className="text-orange-600 text-xl font-semibold">{module.subtitle}</CardTitle>
                      <CardDescription className="text-gray-800">{module.title}</CardDescription>
                    </CardHeader>
                    <CardContent className="pt-0 space-y-4">
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2">Description</h4>
                        <p className="text-gray-900 text-sm leading-relaxed">{module.description}</p>
                      </div>

                      <Separator />

                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2">Objectifs</h4>
                        <p className="text-gray-900 text-sm leading-relaxed">{module.objectives}</p>
                      </div>

                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2">Conseils</h4>
                        <p className="text-gray-900 text-sm leading-relaxed">{module.advice}</p>
                      </div>

                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2">Techniques</h4>
                        <p className="text-gray-900 text-sm leading-relaxed">{module.techniques}</p>
                      </div>

                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2">Format</h4>
                        <Badge variant="secondary" className="bg-orange-50 text-orange-700 border border-orange-200 whitespace-normal break-words inline-block w-full">
                          {module.format}
                        </Badge>
                      </div>

                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2">Notation</h4>
                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-gray-800">{module.notation.criteria1}</span>
                            <Badge variant="outline" className="text-orange-600 border-orange-200">
                              {module.notation.score1}
                            </Badge>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-gray-800">{module.notation.criteria2}</span>
                            <Badge variant="outline" className="text-orange-600 border-orange-200">
                              {module.notation.score2}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* IA Tab */}
            <TabsContent value="ia" className="pt-5 px-8 pb-8">
              <div className="max-w-6xl mx-auto">
                <div className="grid gap-6 md:grid-cols-2">
                  {/* Module 1 */}
                  <Card className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/10 transition-all duration-300 hover:border-orange-300">
                    <CardHeader className="pb-4 border-b border-gray-100">
                      <div className="flex items-center justify-between mb-2">
                        <Badge variant="secondary" className="bg-orange-50 text-orange-700 border border-orange-200">
                          6h
                        </Badge>
                      </div>
                      <CardTitle className="text-orange-600 text-xl font-semibold">Module 1 — Fondamentaux IA</CardTitle>
                      <CardDescription className="text-gray-800">sem. 1–3</CardDescription>
                    </CardHeader>
                    <CardContent className="pt-6">
                      <p className="text-gray-900 leading-relaxed">
                        Culture IA, workflow image, premiers assets.
                      </p>
                    </CardContent>
                  </Card>

                  {/* Module 2 */}
                  <Card className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/10 transition-all duration-300 hover:border-orange-300">
                    <CardHeader className="pb-4 border-b border-gray-100">
                      <div className="flex items-center justify-between mb-2">
                        <Badge variant="secondary" className="bg-orange-50 text-orange-700 border border-orange-200">
                          6h
                        </Badge>
                      </div>
                      <CardTitle className="text-orange-600 text-xl font-semibold">Module 2 — Prompt Design sur Nano Banana</CardTitle>
                      <CardDescription className="text-gray-800">sem. 4–6</CardDescription>
                    </CardHeader>
                    <CardContent className="pt-6">
                      <p className="text-gray-900 leading-relaxed">
                        Anatomie du prompt, cohérence de série, et surtout : formaliser une DA image complète avant de passer à la vidéo — c'est le socle de tout ce qui suit.
                      </p>
                    </CardContent>
                  </Card>

                  {/* Module 3 */}
                  <Card className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/10 transition-all duration-300 hover:border-orange-300">
                    <CardHeader className="pb-4 border-b border-gray-100">
                      <div className="flex items-center justify-between mb-2">
                        <Badge variant="secondary" className="bg-orange-50 text-orange-700 border border-orange-200">
                          8h
                        </Badge>
                      </div>
                      <CardTitle className="text-orange-600 text-xl font-semibold">Module 3 — Portfolio Illustrator → Figma Make</CardTitle>
                      <CardDescription className="text-gray-800">sem. 7–10</CardDescription>
                    </CardHeader>
                    <CardContent className="pt-6">
                      <p className="text-gray-900 leading-relaxed">
                        Design des maquettes sous Illustrator, intégration dans Figma Make, publication du site avec la vidéo IA en Hero de la Home.
                      </p>
                    </CardContent>
                  </Card>

                  {/* Module 4 */}
                  <Card className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/10 transition-all duration-300 hover:border-orange-300">
                    <CardHeader className="pb-4 border-b border-gray-100">
                      <div className="flex items-center justify-between mb-2">
                        <Badge variant="secondary" className="bg-orange-50 text-orange-700 border border-orange-200">
                          6h
                        </Badge>
                      </div>
                      <CardTitle className="text-orange-600 text-xl font-semibold">Module 4 — Vidéo IA</CardTitle>
                      <CardDescription className="text-gray-800">sem. 11–13</CardDescription>
                    </CardHeader>
                    <CardContent className="pt-6">
                      <p className="text-gray-900 leading-relaxed">
                        Storyboard depuis la DA, génération image-to-video (Runway / Kling), montage + sound design IA.
                      </p>
                    </CardContent>
                  </Card>

                  {/* Module 5 */}
                  <Card className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/10 transition-all duration-300 hover:border-orange-300">
                    <CardHeader className="pb-4 border-b border-gray-100">
                      <div className="flex items-center justify-between mb-2">
                        <Badge variant="secondary" className="bg-orange-50 text-orange-700 border border-orange-200">
                          8h
                        </Badge>
                      </div>
                      <CardTitle className="text-orange-600 text-xl font-semibold">Module 5 — Publicité IA en mode nodal Freepik</CardTitle>
                      <CardDescription className="text-gray-800">sem. 14–17</CardDescription>
                    </CardHeader>
                    <CardContent className="pt-6">
                      <p className="text-gray-900 leading-relaxed">
                        Brief fictif → DA image sur papier en premier → workflow nodal → film pub finalisé 15–30 sec.
                      </p>
                    </CardContent>
                  </Card>

                  {/* Séance 18 - Notation */}
                  <Card className="bg-gradient-to-br from-orange-50 to-orange-100/50 border-orange-200 shadow-lg">
                    <CardHeader className="pb-4 border-b border-orange-200">
                      <div className="flex items-center justify-between mb-2">
                        <Badge variant="secondary" className="bg-white text-orange-700 border border-orange-300">
                          2h
                        </Badge>
                      </div>
                      <CardTitle className="text-orange-700 text-xl font-semibold">Séance 18 — Notation</CardTitle>
                      <CardDescription className="text-orange-600">Évaluation finale</CardDescription>
                    </CardHeader>
                    <CardContent className="pt-6">
                      <p className="text-gray-900 leading-relaxed">
                        Évaluation finale du parcours de formation en Intelligence Artificielle.
                      </p>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
import { useState } from 'react';
import { Tabs, TabsContent } from './ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Search, Pen, Play } from 'lucide-react';
import { useAuthGuard } from './useAuth';

interface IllustratorPageProps {
  currentSubPage?: string;
}

const illustratorShortcuts = [
  { keys: ['⌘', 'N'], description: 'Nouveau document' },
  { keys: ['⌘', 'O'], description: 'Ouvrir un fichier' },
  { keys: ['⌘', 'S'], description: 'Enregistrer' },
  { keys: ['⌘', '⇧', 'S'], description: 'Enregistrer sous' },
  { keys: ['⌘', 'Z'], description: 'Annuler' },
  { keys: ['⌘', '⇧', 'Z'], description: 'Rétablir' },
  { keys: ['⌘', 'C'], description: 'Copier' },
  { keys: ['⌘', 'V'], description: 'Coller' },
  { keys: ['⌘', 'X'], description: 'Couper' },
  { keys: ['⌘', 'A'], description: 'Tout sélectionner' },
  { keys: ['⌘', 'D'], description: 'Désélectionner' },
  { keys: ['⌘', '⇧', 'A'], description: 'Désélectionner tout' },
  { keys: ['V'], description: 'Outil Sélection' },
  { keys: ['A'], description: 'Outil Sélection directe' },
  { keys: ['Y'], description: 'Outil Baguette magique' },
  { keys: ['Q'], description: 'Outil Lasso' },
  { keys: ['P'], description: 'Outil Plume' },
  { keys: ['T'], description: 'Outil Texte' },
  { keys: ['L'], description: 'Outil Ellipse' },
  { keys: ['M'], description: 'Outil Rectangle' },
  { keys: ['B'], description: 'Outil Pinceau' },
  { keys: ['N'], description: 'Outil Crayon' },
  { keys: ['I'], description: 'Outil Pipette' },
  { keys: ['K'], description: 'Outil Seau de peinture' },
  { keys: ['G'], description: 'Outil Dégradé' },
  { keys: ['U'], description: 'Outil Mesh' },
  { keys: ['S'], description: 'Outil Échelle' },
  { keys: ['R'], description: 'Outil Rotation' },
  { keys: ['O'], description: 'Outil Réflexion' },
  { keys: ['F'], description: 'Outil Forme libre' },
  { keys: ['C'], description: 'Outil Ciseaux' },
  { keys: ['H'], description: 'Outil Main' },
  { keys: ['Z'], description: 'Outil Zoom' },
  { keys: ['⌘', '+'], description: 'Zoom avant' },
  { keys: ['⌘', '-'], description: 'Zoom arrière' },
  { keys: ['⌘', '0'], description: 'Ajuster à la fenêtre' },
  { keys: ['⌘', '1'], description: 'Taille réelle' },
  { keys: ['⌘', 'Y'], description: 'Mode Aperçu' },
  { keys: ['⌘', '⌥', 'Y'], description: 'Mode Tracés' },
  { keys: ['⌘', 'H'], description: 'Masquer/Afficher la sélection' },
  { keys: ['⌘', ';'], description: 'Afficher/Masquer les repères' },
  { keys: ['⌘', "'"], description: 'Afficher/Masquer la grille' },
  { keys: ['⌘', 'R'], description: 'Afficher/Masquer les règles' },
  { keys: ['Tab'], description: 'Masquer/Afficher les panneaux' },
  { keys: ['⌘', 'G'], description: 'Associer' },
  { keys: ['⌘', '⇧', 'G'], description: 'Dissocier' },
  { keys: ['⌘', '7'], description: 'Masque d\'écrêtage' },
  { keys: ['⌘', '⌥', '7'], description: 'Annuler le masque d\'écrêtage' },
  { keys: ['⌘', '8'], description: 'Créer un tracé composite' },
  { keys: ['⌘', '⌥', '8'], description: 'Annuler le tracé composite' },
  { keys: ['⌘', 'J'], description: 'Joindre' },
  { keys: ['⌘', '⌥', 'J'], description: 'Moyenne' },
  { keys: ['⌘', 'L'], description: 'Verrouiller' },
  { keys: ['⌘', '⌥', 'L'], description: 'Déverrouiller tout' },
  // Raccourcis avancés transformation
  { keys: ['⌘', 'D'], description: 'Transformer à nouveau' },
  { keys: ['⌘', '⇧', 'D'], description: 'Transformer chacun' },
  { keys: ['⌘', '⌥', 'D'], description: 'Dupliquer et transformer' },
  { keys: ['E'], description: 'Outil Transformation manuelle' },
  { keys: ['⇧', 'R'], description: 'Parcourir les outils Déformation' },
  { keys: ['⌘', '⇧', 'O'], description: 'Vectoriser le texte' },
  // Raccourcis Pathfinder et formes
  { keys: ['⌘', '⌥', '1'], description: 'Réunion (Pathfinder)' },
  { keys: ['⌘', '⌥', '2'], description: 'Soustraction (Pathfinder)' },
  { keys: ['⌘', '⌥', '3'], description: 'Intersection (Pathfinder)' },
  { keys: ['⌘', '⌥', '4'], description: 'Exclusion (Pathfinder)' },
  { keys: ['⌘', '⌥', '5'], description: 'Division (Pathfinder)' },
  { keys: ['⌘', '⌥', '6'], description: 'Découpe (Pathfinder)' },
  { keys: ['⌘', '⌥', '7'], description: 'Fusion (Pathfinder)' },
  // Raccourcis texte avancés
  { keys: ['⌘', '⇧', '>'], description: 'Augmenter la taille de police' },
  { keys: ['⌘', '⇧', '<'], description: 'Diminuer la taille de police' },
  { keys: ['⌘', '⌥', '↑'], description: 'Augmenter l\'interligne' },
  { keys: ['⌘', '⌥', '↓'], description: 'Diminuer l\'interligne' },
  { keys: ['⌥', '←'], description: 'Réduire l\'approche' },
  { keys: ['⌥', '→'], description: 'Augmenter l\'approche' },
  { keys: ['⌘', '⇧', 'Q'], description: 'Contour du texte' },
  // Raccourcis couleurs et nuancier
  { keys: ['F6'], description: 'Afficher le panneau Couleur' },
  { keys: ['F5'], description: 'Afficher le panneau Nuancier' },
  { keys: ['⌘', 'F3'], description: 'Bibliothèques de nuances' },
  { keys: ['D'], description: 'Couleurs par défaut' },
  { keys: ['X'], description: 'Permuter fond et contour' },
  { keys: ['/'], description: 'Aucun fond/contour' },
  { keys: [','], description: 'Fond seul' },
  { keys: ['.'], description: 'Contour seul' },
  // Raccourcis pinceaux et styles
  { keys: ['F5'], description: 'Afficher le panneau Formes' },
  { keys: ['⌥', 'F11'], description: 'Panneau Styles graphiques' },
  { keys: ['⌘', '⌥', 'X'], description: 'Réinitialiser le point de transformation' },
  { keys: ['⌘', '⇧', 'F'], description: 'Mode de dessin derrière' },
  { keys: ['⌘', '⇧', 'D'], description: 'Mode de dessin à l\'intérieur' },
  // Raccourcis symboles et motifs
  { keys: ['F8'], description: 'Afficher le panneau Symboles' },
  { keys: ['⇧', 'F8'], description: 'Créer un nouveau symbole' },
  { keys: ['⌘', '⇧', 'F8'], description: 'Bibliothèques de symboles' },
  { keys: ['⌘', 'F8'], description: 'Redéfinir le symbole' },
  // Raccourcis filets et dégradés
  { keys: ['⌘', '⌥', 'G'], description: 'Filet de dégradé' },
  { keys: ['⌘', 'F9'], description: 'Afficher le panneau Dégradé' },
  { keys: ['⌘', 'F10'], description: 'Afficher le panneau Transparence' },
  { keys: ['⌘', '⇧', 'F10'], description: 'Mode de fusion' },
  // Raccourcis calques avancés
  { keys: ['⌘', '['], description: 'Reculer' },
  { keys: ['⌘', ']'], description: 'Avancer' },
  { keys: ['⌘', '⇧', '['], description: 'Arrière-plan' },
  { keys: ['⌘', '⇧', ']'], description: 'Premier plan' },
  { keys: ['F7'], description: 'Afficher le panneau Calques' },
  { keys: ['⌘', 'F7'], description: 'Nouveau calque' },
  { keys: ['⌥', 'F7'], description: 'Options de calque' },
  // Raccourcis grille et magnétisme
  { keys: ['⌘', 'U'], description: 'Magnétisme intelligent' },
  { keys: ['⌘', '⇧', ';'], description: 'Magnétisme grille' },
  { keys: ['⌘', '⌥', ';'], description: 'Magnétisme points' },
  { keys: ['⌘', '⇧', '\"'], description: 'Verrouiller les repères' },
  { keys: ['⌘', '⌥', '\"'], description: 'Créer des repères' },
  // Raccourcis effets et apparence
  { keys: ['⇧', 'F6'], description: 'Panneau Apparence' },
  { keys: ['⌘', '⇧', 'F6'], description: 'Effets' },
  { keys: ['⌘', '⌥', 'F6'], description: 'Styles d\'effet' },
  { keys: ['⌘', 'F6'], description: 'Nouveau style' },
  // Raccourcis tracés et points
  { keys: ['⌘', '⌥', 'J'], description: 'Moyenne et joindre' },
  { keys: ['⌘', '⇧', '⌥', 'J'], description: 'Moyenne' },
  { keys: ['⌘', 'F'], description: 'Rechercher et remplacer' },
  { keys: ['⌘', 'I'], description: 'Vérifier l\'orthographe' },
  { keys: ['⌘', '⇧', 'P'], description: 'Format de document' },
  // Raccourcis export et impression
  { keys: ['⌘', 'E'], description: 'Exporter pour les écrans' },
  { keys: ['⌘', '⌥', 'E'], description: 'Exporter sous' },
  { keys: ['⌘', '⇧', 'E'], description: 'Exportation rapide' },
  { keys: ['⌘', 'P'], description: 'Imprimer' },
  { keys: ['⌘', '⌥', 'P'], description: 'Format d\'impression' }
];

const illustratorGlossary = [
  { term: 'Vectoriel', definition: 'Format d\'image basé sur des formules mathématiques, permettant un redimensionnement sans perte de qualité.' },
  { term: 'Tracé', definition: 'Ligne ou courbe créée avec l\'outil Plume, composée de points d\'ancrage et de segments.' },
  { term: 'Point d\'ancrage', definition: 'Point qui définit les extrémités d\'un segment de tracé.' },
  { term: 'Courbe de Bézier', definition: 'Courbe mathématique définie par des points de contrôle, utilisée pour créer des formes fluides.' },
  { term: 'Poignée directrice', definition: 'Élément qui contrôle la direction et la courbure d\'un segment de tracé.' },
  { term: 'Forme', definition: 'Objet vectoriel fermé qui peut être rempli de couleur, de dégradé ou de motif.' },
  { term: 'Contour', definition: 'Ligne qui définit le bord d\'un objet, pouvant avoir différentes épaisseurs et styles.' },
  { term: 'Fond', definition: 'Couleur, dégradé ou motif qui remplit l\'intérieur d\'une forme.' },
  { term: 'Dégradé', definition: 'Transition progressive entre plusieurs couleurs.' },
  { term: 'Motif', definition: 'Image répétitive utilisée pour remplir une forme.' },
  { term: 'Calque', definition: 'Plan de travail transparent permettant d\'organiser et de hiérarchiser les éléments.' },
  { term: 'Groupe', definition: 'Ensemble d\'objets liés qui se comportent comme un seul élément.' },
  { term: 'Masque d\'écrêtage', definition: 'Technique qui utilise un objet pour masquer des parties d\'autres objets.' },
  { term: 'Pathfinder', definition: 'Panneau d\'outils permettant de combiner, diviser ou modifier des formes.' },
  { term: 'Transformation', definition: 'Modification de la taille, rotation, inclinaison ou déformation d\'un objet.' },
  { term: 'Filet de dégradé', definition: 'Technique permettant de créer des dégradés complexes sur des objets.' },
  { term: 'Symbole', definition: 'Élément réutilisable stocké dans le panneau Symboles.' },
  { term: 'Pinceau', definition: 'Outil qui applique des effets artistiques le long d\'un tracé.' },
  { term: 'Style graphique', definition: 'Ensemble d\'attributs d\'apparence pouvant être appliqué à plusieurs objets.' },
  { term: 'Apparence', definition: 'Ensemble des propriétés visuelles d\'un objet (fonds, contours, effets).' },
  { term: 'Effet', definition: 'Modification de l\'apparence d\'un objet sans altérer sa géométrie de base.' },
  { term: 'Transparence', definition: 'Degré d\'opacité d\'un objet, permettant de voir les éléments sous-jacents.' },
  { term: 'Mode de fusion', definition: 'Méthode qui détermine comment les couleurs d\'un objet interagissent avec celles des objets inférieurs.' },
  { term: 'Plan de travail', definition: 'Zone délimitée représentant l\'espace imprimable du document.' },
  { term: 'Repère', definition: 'Ligne de guidage non imprimable facilitant l\'alignement des objets.' },
  { term: 'Grille', definition: 'Réseau de lignes servant de référence pour positionner les éléments.' },
  { term: 'Magnétisme', definition: 'Fonction qui attire automatiquement les objets vers les repères, grilles ou autres objets.' },
  { term: 'Alignement', definition: 'Positionnement précis des objets les uns par rapport aux autres.' },
  { term: 'Répartition', definition: 'Espacement régulier entre plusieurs objets sélectionnés.' },
  { term: 'Profil colorimétrique', definition: 'Ensemble de données décrivant les caractéristiques colorimétriques d\'un périphérique.' },
  // Termes techniques avancés
  { term: 'Nœud', definition: 'Point de contrôle sur un tracé vectoriel, également appelé point d\'ancrage.' },
  { term: 'Tangente', definition: 'Poignée directrice qui contrôle la direction et la courbure d\'un segment.' },
  { term: 'Spline', definition: 'Courbe mathématique lisse passant par plusieurs points de contrôle.' },
  { term: 'Tessellation', definition: 'Division d\'une surface en formes géométriques sans espaces ni chevauchements.' },
  { term: 'Anticrénelage', definition: 'Technique de lissage des contours pour éviter l\'effet d\'escalier.' },
  // Termes de typographie avancée
  { term: 'Approche', definition: 'Espacement horizontal entre les caractères individuels.' },
  { term: 'Crénage', definition: 'Ajustement spécifique de l\'espacement entre deux caractères.' },
  { term: 'Interligne', definition: 'Espacement vertical entre les lignes de texte.' },
  { term: 'Chasse', definition: 'Largeur totale d\'un caractère incluant ses espaces latéraux.' },
  { term: 'Empattement', definition: 'Petit trait qui termine les fûts des lettres dans certaines polices.' },
  { term: 'Graisse', definition: 'Épaisseur des traits d\'une police (light, regular, bold, etc.).' },
  { term: 'Corps', definition: 'Taille d\'une police, généralement exprimée en points.' },
  { term: 'Ligne de base', definition: 'Ligne imaginaire sur laquelle reposent les caractères.' },
  // Termes de couleur avancés
  { term: 'Espace colorimétrique', definition: 'Système de coordonnées permettant de définir et reproduire les couleurs.' },
  { term: 'Séparation des couleurs', definition: 'Processus de décomposition d\'une image en couches CMJN pour l\'impression.' },
  { term: 'Couleur directe', definition: 'Encre spécifique utilisée en impression, comme les couleurs Pantone.' },
  { term: 'Quadrichromie', definition: 'Procédé d\'impression utilisant quatre encres de base (CMJN).' },
  { term: 'Surimpression', definition: 'Superposition de couleurs d\'impression sans élimination de la couleur inférieure.' },
  { term: 'Défonce', definition: 'Suppression de la couleur inférieure là où une couleur supérieure est imprimée.' },
  // Termes d\'effets et filtres
  { term: 'Pixellisation', definition: 'Effet de transformation d\'un objet vectoriel en image bitmap.' },
  { term: 'Rastérisation', definition: 'Conversion d\'une image vectorielle en image bitmap.' },
  { term: 'Pathfinder', definition: 'Ensemble d\'opérations booléennes pour combiner ou diviser des formes.' },
  { term: 'Déformation d\'enveloppe', definition: 'Technique de déformation d\'objets à l\'aide d\'une forme contenante.' },
  { term: 'Extrusion', definition: 'Effet 3D donnant de la profondeur à un objet 2D.' },
  { term: 'Révolution', definition: 'Effet 3D créé par rotation d\'un profil autour d\'un axe.' },
  // Termes de composition et mise en page
  { term: 'Fond perdu', definition: 'Zone d\'impression qui dépasse le format final pour éviter les marges blanches.' },
  { term: 'Zone de sécurité', definition: 'Marge intérieure où placer les éléments importants pour éviter la coupe.' },
  { term: 'Repères de coupe', definition: 'Marques indiquant où découper le document final.' },
  { term: 'Repères de pliage', definition: 'Marques indiquant les lignes de pliage du document.' },
  { term: 'Hirondelle', definition: 'Repère de positionnement pour l\'alignement des couleurs en impression.' },
  // Termes de formats et export
  { term: 'Format vectoriel', definition: 'Format de fichier basé sur des formules mathématiques (AI, EPS, SVG).' },
  { term: 'Format bitmap', definition: 'Format d\'image basé sur une grille de pixels (JPEG, PNG, TIFF).' },
  { term: 'Résolution d\'impression', definition: 'Nombre de points par pouce (DPI) nécessaire pour l\'impression de qualité.' },
  { term: 'Compression vectorielle', definition: 'Réduction de la taille de fichier en optimisant les données vectorielles.' },
  { term: 'Métafichier', definition: 'Format de fichier contenant à la fois des données vectorielles et bitmap.' },
  // Termes de flux de travail
  { term: 'Gabarit', definition: 'Modèle de document prédéfini avec des éléments de mise en page.' },
  { term: 'Bibliothèque', definition: 'Collection d\'éléments réutilisables (couleurs, formes, symboles).' },
  { term: 'Variables', definition: 'Éléments dynamiques qui peuvent être modifiés automatiquement dans un modèle.' },
  { term: 'Script', definition: 'Programme automatisé pour exécuter des tâches répétitives.' },
  { term: 'Extension', definition: 'Module complémentaire ajoutant des fonctionnalités à Illustrator.' },
  // Termes techniques spécialisés
  { term: 'Courbe composite', definition: 'Tracé complexe composé de plusieurs segments et sous-tracés.' },
  { term: 'Direction de tracé', definition: 'Sens de création d\'un tracé, important pour les opérations booléennes.' },
  { term: 'Point d\'inflexion', definition: 'Point où la courbure d\'un tracé change de direction.' },
  { term: 'Continuité', definition: 'Propriété de liaison fluide entre segments de courbe.' },
  { term: 'Paramétrage', definition: 'Représentation mathématique d\'une courbe ou surface.' },
  // Termes d\'impression avancée
  { term: 'Prépresse', definition: 'Ensemble des opérations précédant l\'impression proprement dite.' },
  { term: 'Épreuve numérique', definition: 'Test d\'impression pour vérifier les couleurs et la mise en page.' },
  { term: 'Calage', definition: 'Ajustement précis de la position des couleurs en impression.' },
  { term: 'Maculage', definition: 'Défaut d\'impression causé par un transfert d\'encre indésirable.' },
  { term: 'Repérage', definition: 'Système de marques pour aligner les différentes couleurs d\'impression.' }
];

export function IllustratorPage({ currentSubPage = 'shortcuts' }: IllustratorPageProps) {
  // Protection d'authentification
  useAuthGuard();

  const [searchTerm, setSearchTerm] = useState('');

  const filteredShortcuts = illustratorShortcuts.filter(shortcut =>
    shortcut.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    shortcut.keys.some(key => key.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const filteredGlossary = illustratorGlossary.filter(term =>
    term.term.toLowerCase().includes(searchTerm.toLowerCase()) ||
    term.definition.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen pt-4 pb-20">
      <div className="max-w-7xl mx-auto px-6">
        {/* Content Container */}
        <div className="bg-white/60 backdrop-blur-sm rounded-2xl shadow-2xl border border-white/20 overflow-hidden">
          <Tabs value={currentSubPage} className="w-full">
            {/* Shortcuts Tab */}
            <TabsContent value="shortcuts" className="p-8">
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {filteredShortcuts.map((shortcut, index) => (
                  <Card
                    key={index}
                    className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 animate-stagger-in"
                    style={{ animationDelay: `${index * 30}ms` }}
                  >
                    <CardContent className="p-5">
                      <div className="flex items-center space-x-2 mb-3">
                        {shortcut.keys.map((key, keyIndex) => (
                          <Badge 
                            key={keyIndex} 
                            variant="secondary" 
                            className="bg-orange-50 text-orange-700 border border-orange-200 text-sm px-3 py-1 font-medium"
                          >
                            {key}
                          </Badge>
                        ))}
                      </div>
                      <p className="text-gray-900 font-medium">{shortcut.description}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
              {filteredShortcuts.length === 0 && (
                <div className="text-center py-16">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Search className="w-8 h-8 text-gray-400" />
                  </div>
                  <p className="text-gray-500 text-lg">Aucun raccourci trouvé pour "{searchTerm}"</p>
                </div>
              )}
            </TabsContent>

            {/* Glossary Tab */}
            <TabsContent value="glossary" className="p-8">
              <div className="grid gap-6 md:grid-cols-2">
                {filteredGlossary.map((item, index) => (
                  <Card
                    key={index}
                    className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 animate-stagger-in"
                    style={{ animationDelay: `${index * 40}ms` }}
                  >
                    <CardHeader className="pb-4">
                      <CardTitle className="text-orange-600 text-xl font-semibold">{item.term}</CardTitle>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <p className="text-gray-900 leading-relaxed">{item.definition}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
              {filteredGlossary.length === 0 && (
                <div className="text-center py-16">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Search className="w-8 h-8 text-gray-400" />
                  </div>
                  <p className="text-gray-500 text-lg">Aucun terme trouvé pour "{searchTerm}"</p>
                </div>
              )}
            </TabsContent>

            {/* Videos Tab */}
            <TabsContent value="videos" className="p-8">
              <div className="space-y-8">

                  <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2">
                    {/* Vidéo Illustrator 1 */}
                    <Card className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 animate-stagger-in" style={{ animationDelay: '0ms' }}>
                      <CardContent className="p-6">
                        <div className="aspect-video rounded-lg mb-4 overflow-hidden shadow-lg">
                          <iframe
                            width="100%"
                            height="100%"
                            src="https://drive.google.com/file/d/10WlZavk-Vmf_w_gYc5a47dsN0nIv8qFq/preview"
                            title="Tutoriel Illustrator"
                            frameBorder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowFullScreen
                            className="rounded-lg"
                          ></iframe>
                        </div>
                        <div className="text-center max-w-4xl mx-auto">
                          <h3 className="font-semibold text-gray-900 mb-2 text-xl">
                            Tutoriel Illustrator
                          </h3>
                          <p className="text-gray-900 text-sm mb-4">
                            Techniques professionnelles sur Adobe Illustrator
                          </p>
                          <div className="flex items-center justify-center space-x-4">
                            <Badge variant="secondary" className="bg-green-50 text-green-700 border border-green-200">
                              Disponible maintenant
                            </Badge>
                            <span className="text-gray-500 text-xs flex items-center space-x-1">
                              <Play className="w-3 h-3" />
                              <span>Vidéo complète</span>
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Vidéo Illustrator 2 - motif (coupe en 4) */}
                    <Card className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 animate-stagger-in" style={{ animationDelay: '100ms' }}>
                      <CardContent className="p-6">
                        <div className="aspect-video rounded-lg mb-4 overflow-hidden shadow-lg">
                          <iframe
                            width="100%"
                            height="100%"
                            src="https://drive.google.com/file/d/1C1yzIJlUi1fx2I6iL1_TlaZM0BPPQ_0-/preview"
                            title="motif (coupe en 4)"
                            frameBorder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowFullScreen
                            className="rounded-lg"
                          ></iframe>
                        </div>
                        <div className="text-center max-w-4xl mx-auto">
                          <h3 className="font-semibold text-gray-900 mb-2 text-xl">
                            motif (coupe en 4)
                          </h3>
                          <p className="text-gray-900 text-sm mb-4">
                            Tutoriel création de motifs répétitifs
                          </p>
                          <div className="flex items-center justify-center space-x-4">
                            <Badge variant="secondary" className="bg-orange-50 text-orange-700 border border-orange-200">
                              Nouveau
                            </Badge>
                            <span className="text-gray-500 text-xs flex items-center space-x-1">
                              <Play className="w-3 h-3" />
                              <span>Vidéo complète</span>
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
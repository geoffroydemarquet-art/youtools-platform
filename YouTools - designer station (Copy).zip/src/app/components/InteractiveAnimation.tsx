import { motion } from 'motion/react';
import { useState } from 'react';

interface InteractiveAnimationProps {
  onNavigate: (page: string) => void;
  exampleImage: string;
}

export function InteractiveAnimation({ onNavigate, exampleImage }: InteractiveAnimationProps) {
  const [clickedCard, setClickedCard] = useState<string | null>(null);

  const tools = [
    {
      id: 'photoshop',
      name: 'Adobe Photoshop',
      textColor: 'text-gray-700',
      dotColor: 'bg-blue-500',
      position: { top: '20%', left: '15%' },
      description: 'Raccourcis professionnels',
      glowColor: 'rgba(59, 130, 246, 0.6)'
    },
    {
      id: 'illustrator',
      name: 'Adobe Illustrator',
      textColor: 'text-gray-700',
      dotColor: 'bg-orange-500',
      position: { bottom: '25%', right: '10%' },
      description: 'Techniques avancées',
      glowColor: 'rgba(249, 115, 22, 0.6)'
    },
    {
      id: 'midjourney',
      name: 'Midjourney AI',
      textColor: 'text-gray-700',
      dotColor: 'bg-purple-500',
      position: { top: '40%', right: '5%' },
      description: '130+ astuces IA',
      glowColor: 'rgba(168, 85, 247, 0.6)'
    },
    {
      id: 'quiz',
      name: 'Évaluation',
      textColor: 'text-gray-700',
      dotColor: 'bg-teal-500',
      position: { bottom: '15%', left: '20%' },
      description: 'Testez vos connaissances',
      glowColor: 'rgba(20, 184, 166, 0.6)'
    }
  ];

  const handleCardClick = (toolId: string) => {
    setClickedCard(toolId);
    setTimeout(() => {
      onNavigate(toolId);
      setClickedCard(null);
    }, 300);
  };

  return (
    <div className="relative max-w-6xl mx-auto">
      {/* Image principale avec animation flottante plus dynamique */}
      <motion.div 
        className="relative z-10 mx-auto"
        animate={{ 
          y: [0, -20, 5, -15, 0],
          rotate: [0, 2, -1, 1, 0],
          scale: [1, 1.02, 0.98, 1.01, 1]
        }}
        transition={{ 
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      >
        <div className="relative">
          <img 
            src={exampleImage} 
            alt="Creative Professional Training" 
            className="w-64 h-64 lg:w-80 lg:h-80 xl:w-96 xl:h-96 object-cover rounded-2xl shadow-lg mx-auto"
          />
          
          {/* Subtle floating particles around image */}
          {[...Array(8)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1 h-1 bg-teal-400 rounded-full opacity-60"
              style={{
                top: `${20 + (i * 10)}%`,
                left: `${15 + (i * 8)}%`,
              }}
              animate={{
                y: [0, -30, 0],
                x: [0, 15, -10, 0],
                opacity: [0.3, 0.8, 0.3],
                scale: [1, 1.5, 1]
              }}
              transition={{
                duration: 4 + i * 0.5,
                repeat: Infinity,
                delay: i * 0.3,
                ease: "easeInOut"
              }}
            />
          ))}
        </div>
      </motion.div>
      
      {/* Éléments orbitaux cliquables avec effets de lumière */}
      {tools.map((tool, index) => (
        <motion.div
          key={tool.id}
          className="absolute cursor-pointer group"
          style={tool.position}
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: index * 0.2, duration: 0.8 }}
          whileHover={{ 
            scale: 1.08,
            transition: { duration: 0.2 }
          }}
          whileTap={{ 
            scale: 0.92,
            transition: { duration: 0.1 }
          }}
          onClick={() => handleCardClick(tool.id)}
        >
          {/* Carte cliquable avec effets de lumière */}
          <motion.div 
            className={`light-card bg-white/90 hover:bg-white backdrop-blur-sm border border-gray-200 rounded-xl p-4 shadow-lg min-w-[160px] transition-all duration-300 ${
              clickedCard === tool.id ? 'bg-white' : ''
            }`}
            animate={{ 
              y: [0, -12, 3, -8, 0],
              x: [0, 3, -2, 2, 0],
              rotateZ: [0, 0.5, -0.3, 0.2, 0]
            }}
            transition={{ 
              duration: 5 + index * 0.5,
              repeat: Infinity,
              ease: "easeInOut",
              delay: index * 0.3
            }}
            style={{
              boxShadow: clickedCard === tool.id 
                ? `0 0 30px ${tool.glowColor}, 0 10px 25px rgba(0,0,0,0.1)` 
                : undefined
            }}
            whileHover={{
              boxShadow: `0 0 20px ${tool.glowColor}, 0 8px 20px rgba(0,0,0,0.15)`,
              y: -4
            }}
          >
            <div className="flex items-center space-x-3">
              <motion.div 
                className={`w-3 h-3 ${tool.dotColor} rounded-full relative`}
                animate={{ 
                  scale: [1, 1.3, 1],
                  boxShadow: [`0 0 0 0 ${tool.glowColor}`, `0 0 0 4px ${tool.glowColor.replace('0.6', '0.2')}`, `0 0 0 0 ${tool.glowColor}`]
                }}
                transition={{ 
                  duration: 2.5,
                  repeat: Infinity,
                  delay: index * 0.4
                }}
              />
              <div>
                <div className={`${tool.textColor} text-sm lg:text-base font-medium transition-colors duration-200 group-hover:text-gray-900`}>
                  {tool.name}
                </div>
                <div className="text-gray-500 text-xs hidden lg:block group-hover:text-gray-600 transition-colors duration-200">
                  {tool.description}
                </div>
              </div>
            </div>
            
            {/* Indicateur de clic avec effet de lumière */}
            <motion.div 
              className="absolute -top-1 -right-1 bg-teal-500 rounded-full w-6 h-6 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300"
              whileHover={{ 
                rotate: 360,
                boxShadow: '0 0 15px rgba(20, 184, 166, 0.6)',
                scale: 1.1
              }}
              transition={{ duration: 0.6 }}
            >
              <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </motion.div>
            
            {/* Overlay shimmer effect */}
            <div className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -skew-x-12 -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>
            </div>
          </motion.div>
        </motion.div>
      ))}

      {/* Anneaux orbitaux animés plus dynamiques */}
      <motion.div 
        className="absolute -inset-12 border border-gray-300/30 rounded-full"
        animate={{ rotate: 360 }}
        transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
      />
      <motion.div 
        className="absolute -inset-8 border border-teal-400/20 rounded-full"
        animate={{ rotate: -360 }}
        transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
      />
      <motion.div 
        className="absolute -inset-4 border border-blue-400/15 rounded-full"
        animate={{ rotate: 360 }}
        transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
      />
      
      {/* Particules flottantes supplémentaires */}
      {[...Array(12)].map((_, i) => (
        <motion.div
          key={`particle-${i}`}
          className="absolute w-1 h-1 rounded-full opacity-40"
          style={{
            top: `${10 + (i * 7)}%`,
            left: `${5 + (i * 8)}%`,
            backgroundColor: i % 3 === 0 ? '#14b8a6' : i % 3 === 1 ? '#3b82f6' : '#8b5cf6'
          }}
          animate={{
            y: [0, -40, 10, -25, 0],
            x: [0, 20, -15, 10, 0],
            opacity: [0.2, 0.8, 0.3, 0.6, 0.2],
            scale: [1, 1.5, 0.8, 1.2, 1]
          }}
          transition={{
            duration: 6 + i * 0.3,
            repeat: Infinity,
            delay: i * 0.2,
            ease: "easeInOut"
          }}
        />
      ))}
      
      {/* Instructions d'interaction animées */}
      <motion.div 
        className="absolute -bottom-16 left-1/2 transform -translate-x-1/2 text-center"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.5, duration: 0.8 }}
      >
        <motion.p 
          className="text-gray-600 text-sm font-medium"
          animate={{ opacity: [0.6, 1, 0.6] }}
          transition={{ duration: 3, repeat: Infinity }}
        >
          Cliquez sur les modules pour explorer
        </motion.p>
        <motion.div 
          className="flex items-center justify-center space-x-2 mt-2"
          animate={{ y: [0, -5, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <motion.div 
            className="w-1.5 h-1.5 bg-teal-500 rounded-full"
            animate={{ scale: [1, 1.3, 1], opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 2, repeat: Infinity, delay: 0 }}
          />
          <motion.div 
            className="w-1.5 h-1.5 bg-blue-500 rounded-full"
            animate={{ scale: [1, 1.3, 1], opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 2, repeat: Infinity, delay: 0.3 }}
          />
          <motion.div 
            className="w-1.5 h-1.5 bg-purple-500 rounded-full"
            animate={{ scale: [1, 1.3, 1], opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 2, repeat: Infinity, delay: 0.6 }}
          />
        </motion.div>
      </motion.div>
    </div>
  );
}
import { motion } from 'motion/react';
import { Home, Image, PenTool, Bot, Brain, Trophy } from 'lucide-react';

interface FloatingNavigationProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

export function FloatingNavigation({ currentPage, onNavigate }: FloatingNavigationProps) {
  const navItems = [
    {
      id: 'home',
      icon: Home,
      label: 'Accueil',
      color: 'from-slate-400 to-slate-600',
      hoverColor: 'from-slate-300 to-slate-500',
      delay: 0
    },
    {
      id: 'photoshop',
      icon: Image,
      label: 'Photoshop',
      color: 'from-blue-400 to-blue-600',
      hoverColor: 'from-blue-300 to-blue-500',
      delay: 0.1
    },
    {
      id: 'illustrator',
      icon: PenTool,
      label: 'Illustrator',
      color: 'from-orange-400 to-orange-600',
      hoverColor: 'from-orange-300 to-orange-500',
      delay: 0.2
    },
    {
      id: 'midjourney',
      icon: Bot,
      label: 'Midjourney',
      color: 'from-purple-400 to-purple-600',
      hoverColor: 'from-purple-300 to-purple-500',
      delay: 0.3
    },
    {
      id: 'quiz',
      icon: Brain,
      label: 'Quiz',
      color: 'from-teal-400 to-teal-600',
      hoverColor: 'from-teal-300 to-teal-500',
      delay: 0.4
    },
    {
      id: 'quiz-results',
      icon: Trophy,
      label: 'Résultats',
      color: 'from-yellow-400 to-yellow-600',
      hoverColor: 'from-yellow-300 to-yellow-500',
      delay: 0.5
    }
  ];

  return (
    <motion.div 
      className="fixed right-6 top-1/2 transform -translate-y-1/2 z-40 space-y-4"
      initial={{ opacity: 0, x: 100 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.6, delay: 1 }}
    >
      {navItems.map((item) => {
        const Icon = item.icon;
        const isActive = currentPage === item.id || (item.id === 'quiz' && currentPage.startsWith('quiz'));
        
        return (
          <motion.div
            key={item.id}
            className="group relative"
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ 
              duration: 0.5, 
              delay: item.delay + 1.2,
              type: "spring",
              stiffness: 200
            }}
          >
            {/* Tooltip */}
            <motion.div
              className="absolute right-16 top-1/2 transform -translate-y-1/2 bg-white/95 backdrop-blur-sm text-slate-800 px-3 py-2 rounded-lg text-sm whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none transition-all duration-200"
              initial={{ x: 10, opacity: 0 }}
              whileHover={{ x: 0, opacity: 1 }}
            >
              {item.label}
              {/* Arrow */}
              <div className="absolute left-full top-1/2 transform -translate-y-1/2 w-0 h-0 border-l-4 border-l-white/95 border-t-4 border-t-transparent border-b-4 border-b-transparent"></div>
            </motion.div>

            {/* Icon Button */}
            <motion.button
              onClick={() => onNavigate(item.id)}
              className={`relative w-12 h-12 rounded-full bg-gradient-to-r ${
                isActive ? item.hoverColor : item.color
              } backdrop-blur-sm border border-white/20 flex items-center justify-center shadow-lg transition-all duration-200 overflow-hidden`}
              whileHover={{ 
                scale: 1.1,
                rotate: 5,
                boxShadow: "0 10px 25px rgba(0,0,0,0.2)"
              }}
              whileTap={{ scale: 0.95 }}
              animate={{
                y: [0, -3, 0],
                rotate: isActive ? [0, 10, -10, 0] : 0
              }}
              transition={{
                y: {
                  duration: 2 + (item.delay * 2),
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: item.delay
                },
                rotate: {
                  duration: 0.6,
                  ease: "easeInOut"
                }
              }}
            >
              {/* Active indicator ring */}
              {isActive && (
                <motion.div
                  className="absolute inset-0 rounded-full border-2 border-white/60"
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1.2, opacity: [0, 1, 0] }}
                  transition={{ 
                    duration: 1.5, 
                    repeat: Infinity,
                    ease: "easeOut"
                  }}
                />
              )}

              {/* Sparkle effect on hover */}
              <motion.div
                className="absolute inset-0 rounded-full opacity-0 group-hover:opacity-100"
                style={{
                  background: `conic-gradient(from 0deg, transparent, white, transparent)`
                }}
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              />
              
              {/* Icon */}
              <Icon 
                size={18} 
                className={`relative z-10 transition-colors duration-200 ${
                  isActive ? 'text-white drop-shadow-lg' : 'text-white/90'
                }`} 
              />

              {/* Pulse effect for active state */}
              {isActive && (
                <motion.div
                  className="absolute inset-0 rounded-full bg-white/20"
                  animate={{ scale: [1, 1.3, 1], opacity: [0.5, 0, 0.5] }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
              )}
            </motion.button>

            {/* Floating particles */}
            {isActive && (
              <>
                {[...Array(3)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="absolute w-1 h-1 bg-white/60 rounded-full pointer-events-none"
                    style={{
                      top: `${20 + (i * 10)}%`,
                      left: `${20 + (i * 15)}%`,
                    }}
                    animate={{
                      y: [-10, 10, -10],
                      x: [-5, 5, -5],
                      opacity: [0, 1, 0],
                      scale: [0.5, 1, 0.5]
                    }}
                    transition={{
                      duration: 2 + i,
                      repeat: Infinity,
                      delay: i * 0.3,
                      ease: "easeInOut"
                    }}
                  />
                ))}
              </>
            )}
          </motion.div>
        );
      })}

      {/* Decorative line */}
      <motion.div
        className="absolute -left-8 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-white/20 to-transparent"
        initial={{ scaleY: 0 }}
        animate={{ scaleY: 1 }}
        transition={{ duration: 1, delay: 2 }}
      />

      {/* Floating orb */}
      <motion.div
        className="absolute -left-12 top-1/2 w-2 h-2 bg-teal-400/60 rounded-full"
        animate={{
          y: [-80, 80, -80],
          opacity: [0.3, 0.8, 0.3]
        }}
        transition={{
          duration: 4,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />
    </motion.div>
  );
}
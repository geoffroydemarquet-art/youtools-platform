import { useEffect } from 'react';
import { PageType } from '../App';

// Configuration avancée pour les données structurées spécialisées
export const useAdvancedSEO = (currentPage: PageType) => {
  useEffect(() => {
    // Données structurées spécialisées par page
    const getAdvancedStructuredData = () => {
      const baseUrl = 'https://creative-tools.fr';
      
      switch (currentPage) {
        case 'photoshop':
          return {
            "@context": "https://schema.org",
            "@graph": [
              {
                "@type": "Course",
                "@id": `${baseUrl}/photoshop#course`,
                "name": "Formation Photoshop Mac - Raccourcis Professionnels",
                "description": "Formation complète aux raccourcis et techniques Photoshop pour macOS",
                "provider": {
                  "@type": "Organization",
                  "name": "Creative Tools",
                  "url": baseUrl
                },
                "hasCourseInstance": {
                  "@type": "CourseInstance",
                  "courseMode": "online",
                  "instructor": {
                    "@type": "Person",  
                    "name": "Expert Photoshop Demarquet",
                    "worksFor": {
                      "@type": "Organization",
                      "name": "Creative Tools"
                    }
                  },
                  "courseWorkload": "PT8H"
                },
                "teaches": [
                  "Raccourcis clavier Photoshop pour Mac",
                  "Techniques de retouche professionnelle",
                  "Gestion des calques et masques",
                  "Workflow non-destructif",
                  "Optimisation des performances"
                ],
                "coursePrerequisites": "Connaissances de base en informatique Mac",
                "educationalLevel": "Débutant à Avancé",
                "inLanguage": "fr-FR",
                "isAccessibleForFree": false,
                "offers": {
                  "@type": "Offer",
                  "price": "0",
                  "priceCurrency": "EUR",
                  "availability": "https://schema.org/InStock",
                  "validFrom": "2024-01-01"
                },
                "aggregateRating": {
                  "@type": "AggregateRating",
                  "ratingValue": "4.8",
                  "reviewCount": "89",
                  "bestRating": "5"
                },
                "review": [
                  {
                    "@type": "Review",
                    "reviewRating": {
                      "@type": "Rating",
                      "ratingValue": "5",
                      "bestRating": "5"
                    },
                    "author": {
                      "@type": "Person",
                      "name": "Marie D."
                    },
                    "reviewBody": "Formation exceptionnelle ! Les raccourcis Mac sont parfaitement expliqués."
                  }
                ]
              },
              {
                "@type": "SoftwareApplication",
                "@id": `${baseUrl}/photoshop#software`,
                "name": "Adobe Photoshop pour Mac",
                "applicationCategory": "DesignApplication",
                "operatingSystem": "macOS",
                "offers": {
                  "@type": "Offer",
                  "price": "Formation incluse",
                  "priceCurrency": "EUR"
                },
                "aggregateRating": {
                  "@type": "AggregateRating",
                  "ratingValue": "4.9",
                  "reviewCount": "150"
                }
              }
            ]
          };

        case 'illustrator':
          return {
            "@context": "https://schema.org",
            "@type": "Course",
            "name": "Formation Illustrator Mac - Design Vectoriel",
            "description": "Maîtrisez Adobe Illustrator pour créer des designs vectoriels professionnels sur Mac",
            "provider": {
              "@type": "Organization",
              "name": "Creative Tools"
            },
            "teaches": [
              "Outil Plume et courbes de Bézier",
              "Création de logos vectoriels",
              "Typographie créative",
              "Pathfinder et formes complexes",
              "Export multi-formats"
            ],
            "coursePrerequisites": "Bases du design graphique recommandées",
            "timeRequired": "PT10H",
            "educationalLevel": "Intermédiaire",
            "inLanguage": "fr-FR",
            "aggregateRating": {
              "@type": "AggregateRating",
              "ratingValue": "4.7",
              "reviewCount": "73"
            }
          };

        case 'midjourney':
          return {
            "@context": "https://schema.org",
            "@type": "Course",
            "name": "Formation Midjourney - 130+ Astuces IA",
            "description": "Formation complète à Midjourney avec plus de 130 astuces pour maîtriser l'IA générative",
            "provider": {
              "@type": "Organization",
              "name": "Creative Tools"
            },
            "teaches": [
              "Prompts avancés Midjourney",
              "Paramètres et réglages", 
              "Styles artistiques variés",
              "Techniques de composition",
              "Workflow créatif avec IA"
            ],
            "about": {
              "@type": "Thing",
              "name": "Intelligence Artificielle Générative",
              "description": "Art généré par intelligence artificielle"
            },
            "educationalLevel": "Tous niveaux",
            "timeRequired": "PT6H",
            "aggregateRating": {
              "@type": "AggregateRating", 
              "ratingValue": "4.9",
              "reviewCount": "112"
            }
          };

        case 'ai-assistant':
          return {
            "@context": "https://schema.org",
            "@type": "SoftwareApplication",
            "name": "Agent IA Creative Tools",
            "applicationCategory": "BusinessApplication",
            "description": "Assistant intelligence artificielle spécialisé en design graphique",
            "features": [
              "200+ suggestions de prompts créatifs",
              "Conseils Photoshop personnalisés",
              "Assistance Illustrator en temps réel",
              "Workflow créatif optimisé",
              "Intégration ChatGPT"
            ],
            "operatingSystem": "Web Browser",
            "browserRequirements": "Navigateur moderne avec JavaScript",
            "offers": {
              "@type": "Offer",
              "price": "0",
              "priceCurrency": "EUR",
              "availability": "https://schema.org/InStock"
            },
            "aggregateRating": {
              "@type": "AggregateRating",
              "ratingValue": "4.6",
              "reviewCount": "95"
            }
          };

        case 'home':
        default:
          return {
            "@context": "https://schema.org",
            "@graph": [
              {
                "@type": "Organization",
                "@id": `${baseUrl}/#organization`,
                "name": "Creative Tools",
                "alternateName": "Demarquet Tools",
                "url": baseUrl,
                "logo": {
                  "@type": "ImageObject",
                  "url": `${baseUrl}/logo.png`,
                  "width": 512,
                  "height": 512
                },
                "description": "Plateforme française de formation professionnelle en design graphique et outils créatifs numériques",
                "foundingDate": "2024",
                "areaServed": {
                  "@type": "Country",
                  "name": "France"
                },
                "knowsAbout": [
                  "Adobe Photoshop",
                  "Adobe Illustrator",
                  "Midjourney",
                  "Intelligence Artificielle Créative",
                  "Design Graphique",
                  "Formation Professionnelle"
                ],
                "contactPoint": {
                  "@type": "ContactPoint",
                  "telephone": "+33-1-XX-XX-XX-XX",
                  "contactType": "Customer Service",
                  "areaServed": "FR",
                  "availableLanguage": "French"
                },
                "sameAs": [
                  "https://www.linkedin.com/company/creative-tools-fr",
                  "https://twitter.com/CreativeToolsFR",
                  "https://www.facebook.com/CreativeToolsFrance",
                  "https://www.youtube.com/c/CreativeToolsFR"
                ]
              },
              {
                "@type": "WebSite",
                "@id": `${baseUrl}/#website`,
                "url": baseUrl,
                "name": "Creative Tools",
                "description": "Formation professionnelle en design graphique",
                "publisher": {
                  "@id": `${baseUrl}/#organization`
                },
                "potentialAction": {
                  "@type": "SearchAction",
                  "target": {
                    "@type": "EntryPoint",
                    "urlTemplate": `${baseUrl}/search?q={search_term_string}`
                  },
                  "query-input": "required name=search_term_string"
                }
              },
              {
                "@type": "EducationalOrganization",
                "@id": `${baseUrl}/#educational`,
                "name": "Creative Tools Formation",
                "description": "Centre de formation spécialisé en outils créatifs numériques",
                "url": baseUrl,
                "courseMode": "online",
                "hasCredential": {
                  "@type": "EducationalOccupationalCredential",
                  "name": "Certificat Creative Tools",
                  "description": "Certification en design graphique professionnel"
                }
              }
            ]
          };
      }
    };

    // Injection des données structurées avancées
    const structuredData = getAdvancedStructuredData();
    
    let script = document.querySelector('script[type="application/ld+json"][data-advanced]');
    if (!script) {
      script = document.createElement('script');
      script.type = 'application/ld+json';
      script.setAttribute('data-advanced', 'true');
      document.head.appendChild(script);
    }
    script.textContent = JSON.stringify(structuredData);

  }, [currentPage]);
};

// Fonction pour injecter les microdonnées dans les éléments HTML
export const injectMicrodata = (currentPage: PageType) => {
  useEffect(() => {
    // Ajout de microdonnées aux éléments existants
    const addMicrodata = () => {
      // Page d'accueil
      if (currentPage === 'home') {
        const title = document.querySelector('h1');
        if (title) {
          title.setAttribute('itemProp', 'name');
          if (!title.closest('[itemScope]')) {
            const wrapper = document.createElement('div');
            wrapper.setAttribute('itemScope', '');
            wrapper.setAttribute('itemType', 'https://schema.org/EducationalOrganization');
            title.parentNode?.insertBefore(wrapper, title);
            wrapper.appendChild(title);
          }
        }
      }

      // Pages de formation
      if (['photoshop', 'illustrator', 'midjourney'].includes(currentPage)) {
        const mainContent = document.querySelector('main');
        if (mainContent && !mainContent.getAttribute('itemScope')) {
          mainContent.setAttribute('itemScope', '');
          mainContent.setAttribute('itemType', 'https://schema.org/Course');
        }
      }

      // Page assistant IA
      if (currentPage === 'ai-assistant') {
        const mainContent = document.querySelector('main');
        if (mainContent && !mainContent.getAttribute('itemScope')) {
          mainContent.setAttribute('itemScope', '');
          mainContent.setAttribute('itemType', 'https://schema.org/SoftwareApplication');
        }
      }
    };

    // Délai pour laisser le temps aux composants de se monter
    setTimeout(addMicrodata, 100);

  }, [currentPage]);
};

// Hook combiné pour SEO avancé
export const useAdvancedSEOComplete = (currentPage: PageType) => {
  useAdvancedSEO(currentPage);
  injectMicrodata(currentPage);
  
  // Optimisations supplémentaires
  useEffect(() => {
    // Preload des ressources critiques selon la page
    const preloadCriticalResources = () => {
      const preloadLinks: string[] = [];
      
      switch (currentPage) {
        case 'photoshop':
          preloadLinks.push('/images/photoshop-interface.jpg');
          preloadLinks.push('/data/photoshop-shortcuts.json');
          break;
        case 'illustrator':
          preloadLinks.push('/images/illustrator-workspace.jpg');
          preloadLinks.push('/data/illustrator-shortcuts.json');
          break;
        case 'midjourney':
          preloadLinks.push('/images/midjourney-gallery.jpg');
          preloadLinks.push('/data/midjourney-prompts.json');
          break;
        case 'ai-assistant':
          preloadLinks.push('/data/ai-suggestions.json');
          break;
      }

      preloadLinks.forEach(href => {
        let link = document.querySelector(`link[href="${href}"]`) as HTMLLinkElement;
        if (!link) {
          link = document.createElement('link');
          link.rel = 'preload';
          link.href = href;
          if (href.endsWith('.jpg') || href.endsWith('.png')) {
            link.as = 'image';
          } else if (href.endsWith('.json')) {
            link.as = 'fetch';
            link.crossOrigin = 'anonymous';
          }
          document.head.appendChild(link);
        }
      });
    };

    preloadCriticalResources();
  }, [currentPage]);
};
import React, { useState, useRef, useEffect } from 'react';

interface LazyMediaProps {
  src: string;
  alt?: string;
  type: 'image' | 'video';
  className?: string;
  placeholder?: string;
  threshold?: number;
  loadingComponent?: React.ReactNode;
  errorComponent?: React.ReactNode;
  onLoad?: () => void;
  onError?: () => void;
  autoPlay?: boolean;
  muted?: boolean;
  loop?: boolean;
  playsInline?: boolean;
  preload?: 'none' | 'metadata' | 'auto';
}

export const LazyMedia: React.FC<LazyMediaProps> = ({
  src,
  alt = '',
  type,
  className = '',
  placeholder,
  threshold = 0.1,
  loadingComponent,
  errorComponent,
  onLoad,
  onError,
  autoPlay = false,
  muted = true,
  loop = false,
  playsInline = true,
  preload = 'metadata'
}) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [isInView, setIsInView] = useState(false);
  const [isError, setIsError] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const elementRef = useRef<HTMLDivElement>(null);

  // Intersection Observer pour détecter quand l'élément entre dans le viewport
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const [entry] = entries;
        if (entry.isIntersecting && !isInView) {
          setIsInView(true);
          setIsLoading(true);
        }
      },
      {
        threshold,
        rootMargin: '50px' // Commencer le chargement 50px avant que l'élément soit visible
      }
    );

    if (elementRef.current) {
      observer.observe(elementRef.current);
    }

    return () => {
      if (elementRef.current) {
        observer.unobserve(elementRef.current);
      }
    };
  }, [threshold, isInView]);

  const handleLoad = () => {
    setIsLoaded(true);
    setIsLoading(false);
    onLoad?.();
  };

  const handleError = () => {
    setIsError(true);
    setIsLoading(false);
    onError?.();
  };

  const defaultLoadingComponent = (
    <div className="flex items-center justify-center bg-gray-100 animate-pulse">
      <div className="w-8 h-8 border-2 border-orange-600/30 border-t-orange-600 rounded-full animate-spin"></div>
    </div>
  );

  const defaultErrorComponent = (
    <div className="flex items-center justify-center bg-gray-100 text-gray-500 text-sm">
      <span>Erreur de chargement</span>
    </div>
  );

  // Afficher le placeholder ou le composant de chargement si l'élément n'est pas encore visible
  if (!isInView) {
    return (
      <div ref={elementRef} className={className} style={{ minHeight: '200px' }}>
        {placeholder ? (
          <img src={placeholder} alt={alt} className={className} loading="eager" />
        ) : (
          <div className="w-full h-full bg-gray-100 animate-pulse rounded" />
        )}
      </div>
    );
  }

  // Afficher le composant d'erreur si le chargement a échoué
  if (isError) {
    return (
      <div ref={elementRef} className={className}>
        {errorComponent || defaultErrorComponent}
      </div>
    );
  }

  // Afficher le composant de chargement pendant le chargement
  if (isLoading && !isLoaded) {
    return (
      <div ref={elementRef} className={className}>
        {loadingComponent || defaultLoadingComponent}
        {/* Charger le média en arrière-plan */}
        {type === 'image' ? (
          <img
            src={src}
            alt={alt}
            onLoad={handleLoad}
            onError={handleError}
            style={{ display: 'none' }}
          />
        ) : (
          <video
            src={src}
            onLoadedData={handleLoad}
            onError={handleError}
            style={{ display: 'none' }}
            preload={preload}
          />
        )}
      </div>
    );
  }

  // Afficher le média une fois chargé
  return (
    <div ref={elementRef} className={className}>
      {type === 'image' ? (
        <img
          src={src}
          alt={alt}
          className={`transition-opacity duration-300 ${isLoaded ? 'opacity-100' : 'opacity-0'} ${className}`}
          onLoad={handleLoad}
          onError={handleError}
          loading="lazy"
        />
      ) : (
        <video
          src={src}
          className={`transition-opacity duration-300 ${isLoaded ? 'opacity-100' : 'opacity-0'} ${className}`}
          onLoadedData={handleLoad}
          onError={handleError}
          autoPlay={autoPlay}
          muted={muted}
          loop={loop}
          playsInline={playsInline}
          preload={preload}
        />
      )}
    </div>
  );
};

// Hook pour précharger des ressources de manière intelligente
export const useSmartPreloader = () => {
  const [preloadQueue, setPreloadQueue] = useState<string[]>([]);
  const [loadedResources, setLoadedResources] = useState<Set<string>>(new Set());

  const addToPreloadQueue = (urls: string | string[]) => {
    const urlArray = Array.isArray(urls) ? urls : [urls];
    setPreloadQueue(prev => [...prev, ...urlArray.filter(url => !loadedResources.has(url))]);
  };

  const preloadResource = async (url: string, type: 'image' | 'video' = 'image'): Promise<void> => {
    if (loadedResources.has(url)) return;

    return new Promise((resolve, reject) => {
      if (type === 'image') {
        const img = new Image();
        img.onload = () => {
          setLoadedResources(prev => new Set([...prev, url]));
          resolve();
        };
        img.onerror = reject;
        img.src = url;
      } else {
        const video = document.createElement('video');
        video.onloadeddata = () => {
          setLoadedResources(prev => new Set([...prev, url]));
          resolve();
        };
        video.onerror = reject;
        video.preload = 'metadata';
        video.src = url;
      }
    });
  };

  const processPreloadQueue = async (maxConcurrent: number = 3) => {
    const batch = preloadQueue.slice(0, maxConcurrent);
    setPreloadQueue(prev => prev.slice(maxConcurrent));

    const promises = batch.map(url => {
      const type = url.includes('.mp4') || url.includes('.webm') ? 'video' : 'image';
      return preloadResource(url, type).catch(() => {
        // Ignorer les erreurs de préchargement
        console.debug(`Erreur lors du préchargement de: ${url}`);
      });
    });

    await Promise.allSettled(promises);

    // Continuer avec le prochain batch si il y en a un
    if (preloadQueue.length > 0) {
      setTimeout(() => processPreloadQueue(maxConcurrent), 1000);
    }
  };

  useEffect(() => {
    if (preloadQueue.length > 0) {
      processPreloadQueue();
    }
  }, [preloadQueue]);

  return {
    addToPreloadQueue,
    loadedResources,
    isResourceLoaded: (url: string) => loadedResources.has(url)
  };
};

// Hook pour détecter l'engagement utilisateur avancé
export const useAdvancedEngagement = () => {
  const [engagement, setEngagement] = useState({
    scrollDepth: 0,
    timeOnPage: 0,
    interactions: 0,
    isActive: true,
    readingSpeed: 0
  });

  useEffect(() => {
    let startTime = Date.now();
    let lastScrollTime = 0;
    let scrollDistances: number[] = [];

    const updateScrollDepth = () => {
      const scrollTop = window.pageYOffset;
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      const scrollPercent = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0;
      
      setEngagement(prev => ({ 
        ...prev, 
        scrollDepth: Math.max(prev.scrollDepth, scrollPercent)
      }));

      // Calculer la vitesse de lecture basée sur le scroll
      const now = Date.now();
      if (lastScrollTime > 0) {
        const timeDiff = now - lastScrollTime;
        const scrollDiff = Math.abs(scrollTop - (scrollDistances[scrollDistances.length - 1] || 0));
        scrollDistances.push(scrollTop);
        
        // Garder seulement les 10 dernières mesures
        if (scrollDistances.length > 10) {
          scrollDistances.shift();
        }
        
        // Vitesse lente = lecture, vitesse rapide = scan
        const speed = scrollDiff / timeDiff;
        setEngagement(prev => ({ ...prev, readingSpeed: speed }));
      }
      lastScrollTime = now;
    };

    const updateTimeOnPage = () => {
      setEngagement(prev => ({ 
        ...prev, 
        timeOnPage: Date.now() - startTime 
      }));
    };

    const handleInteraction = () => {
      setEngagement(prev => ({ 
        ...prev, 
        interactions: prev.interactions + 1 
      }));
    };

    const handleVisibilityChange = () => {
      setEngagement(prev => ({ 
        ...prev, 
        isActive: !document.hidden 
      }));
    };

    // Event listeners
    window.addEventListener('scroll', updateScrollDepth, { passive: true });
    window.addEventListener('click', handleInteraction);
    window.addEventListener('keydown', handleInteraction);
    document.addEventListener('visibilitychange', handleVisibilityChange);

    // Timer pour le temps passé sur la page
    const timer = setInterval(updateTimeOnPage, 1000);

    return () => {
      window.removeEventListener('scroll', updateScrollDepth);
      window.removeEventListener('click', handleInteraction);
      window.removeEventListener('keydown', handleInteraction);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      clearInterval(timer);
    };
  }, []);

  return engagement;
};
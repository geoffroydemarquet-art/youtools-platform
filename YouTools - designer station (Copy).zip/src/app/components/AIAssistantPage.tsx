import { useAuthGuard } from './useAuth';
import { Bot, ExternalLink } from 'lucide-react';

export function AIAssistantPage() {
  // Protection d'authentification
  useAuthGuard();

  const openGemini = () => {
    window.open('https://gemini.google.com/gem/1hKA5_vYawvzREwO4BEMZlMK_JsPo595u?usp=sharing', '_blank', 'noopener,noreferrer');
  }

  const openTendances = () => {
    window.open('https://gemini.google.com/gem/1NmeBRXxg7kSvQAEij_HlhJ7QzAspu_6N?usp=sharing', '_blank', 'noopener,noreferrer');
  }

  const openMarketing = () => {
    window.open('https://gemini.google.com/gem/1umSMW0zSU-owjwiC85ctjFLTgpg4a5YQ?usp=sharing', '_blank', 'noopener,noreferrer');
  }

  const openNanoBanana = () => {
    window.open('https://gemini.google.com/gem/1ilorJPc-JPRkuEjYUAAY_MPMGHj23Ko_?usp=sharing', '_blank', 'noopener,noreferrer');
  }

  const openNaming = () => {
    window.open('https://gemini.google.com/gem/1xYMxvB_s1yovx5kRlTkxBRTsswAgdPOi?usp=sharing', '_blank', 'noopener,noreferrer');
  }

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Video Background */}
      <video
        autoPlay
        muted
        loop
        playsInline
        preload="metadata"
        className="fixed inset-0 w-full h-full object-cover z-0"
        style={{
          filter: 'brightness(0.75) contrast(1.1) saturate(1.15)',
        }}
      >
        <source src="https://cdn.midjourney.com/video/0ba69904-2801-4f13-b8b6-7dd6b7235814/0.mp4" type="video/mp4" />
      </video>

      {/* Overlay */}
      <div className="fixed inset-0 pointer-events-none bg-white/16 backdrop-blur-[1.2px] z-10"></div>

      {/* Content */}
      <div className="relative z-30 min-h-screen flex items-center justify-center p-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-5xl w-full">
          {/* PROF Button */}
          <button
            onClick={openGemini}
            className="group relative overflow-hidden px-4 py-4 bg-white/10 backdrop-blur-md border-2 border-white/20 hover:border-orange-400/60 rounded-xl text-white shadow-2xl hover:shadow-orange-500/30 transition-all duration-500 transform hover:scale-[1.02] active:scale-[0.98] animate-fade-in-up"
            style={{ animationDelay: '0ms' }}
          >
            {/* Gradient overlay on hover */}
            <div className="absolute inset-0 bg-gradient-to-br from-orange-500/0 to-orange-600/0 group-hover:from-orange-500/20 group-hover:to-orange-600/30 transition-all duration-500"></div>

            <div className="relative flex flex-col items-center space-y-2">
              <div className="w-12 h-12 bg-orange-500/20 rounded-full flex items-center justify-center group-hover:bg-orange-500/40 transition-all duration-300 group-hover:scale-110">
                <Bot className="w-6 h-6" />
              </div>
              <div className="text-center">
                <div className="text-xs uppercase tracking-wider opacity-60 mb-1">agent</div>
                <div className="text-2xl font-bold tracking-tight">PROF</div>
              </div>
              <ExternalLink className="w-5 h-5 opacity-0 group-hover:opacity-100 transition-all duration-300 absolute top-6 right-6" />
            </div>
          </button>

          {/* TENDANCES GRAPHIQUES Button */}
          <button
            onClick={openTendances}
            className="group relative overflow-hidden px-4 py-4 bg-white/10 backdrop-blur-md border-2 border-white/20 hover:border-orange-400/60 rounded-xl text-white shadow-2xl hover:shadow-orange-500/30 transition-all duration-500 transform hover:scale-[1.02] active:scale-[0.98] animate-fade-in-up"
            style={{ animationDelay: '150ms' }}
          >
            <div className="absolute inset-0 bg-gradient-to-br from-orange-500/0 to-orange-600/0 group-hover:from-orange-500/20 group-hover:to-orange-600/30 transition-all duration-500"></div>

            <div className="relative flex flex-col items-center space-y-2">
              <div className="w-12 h-12 bg-orange-500/20 rounded-full flex items-center justify-center group-hover:bg-orange-500/40 transition-all duration-300 group-hover:scale-110">
                <Bot className="w-6 h-6" />
              </div>
              <div className="text-center">
                <div className="text-xs uppercase tracking-wider opacity-60 mb-1">agent</div>
                <div className="text-xl font-bold tracking-tight">TENDANCES GRAPHIQUES</div>
              </div>
              <ExternalLink className="w-5 h-5 opacity-0 group-hover:opacity-100 transition-all duration-300 absolute top-6 right-6" />
            </div>
          </button>

          {/* MARKETING Button */}
          <button
            onClick={openMarketing}
            className="group relative overflow-hidden px-4 py-4 bg-white/10 backdrop-blur-md border-2 border-white/20 hover:border-orange-400/60 rounded-xl text-white shadow-2xl hover:shadow-orange-500/30 transition-all duration-500 transform hover:scale-[1.02] active:scale-[0.98] animate-fade-in-up"
            style={{ animationDelay: '300ms' }}
          >
            <div className="absolute inset-0 bg-gradient-to-br from-orange-500/0 to-orange-600/0 group-hover:from-orange-500/20 group-hover:to-orange-600/30 transition-all duration-500"></div>

            <div className="relative flex flex-col items-center space-y-2">
              <div className="w-12 h-12 bg-orange-500/20 rounded-full flex items-center justify-center group-hover:bg-orange-500/40 transition-all duration-300 group-hover:scale-110">
                <Bot className="w-6 h-6" />
              </div>
              <div className="text-center">
                <div className="text-xs uppercase tracking-wider opacity-60 mb-1">agent</div>
                <div className="text-2xl font-bold tracking-tight">MARKETING</div>
              </div>
              <ExternalLink className="w-5 h-5 opacity-0 group-hover:opacity-100 transition-all duration-300 absolute top-6 right-6" />
            </div>
          </button>

          {/* NANO BANANA Button */}
          <button
            onClick={openNanoBanana}
            className="group relative overflow-hidden px-4 py-4 bg-white/10 backdrop-blur-md border-2 border-white/20 hover:border-orange-400/60 rounded-xl text-white shadow-2xl hover:shadow-orange-500/30 transition-all duration-500 transform hover:scale-[1.02] active:scale-[0.98] animate-fade-in-up"
            style={{ animationDelay: '450ms' }}
          >
            <div className="absolute inset-0 bg-gradient-to-br from-orange-500/0 to-orange-600/0 group-hover:from-orange-500/20 group-hover:to-orange-600/30 transition-all duration-500"></div>

            <div className="relative flex flex-col items-center space-y-2">
              <div className="w-12 h-12 bg-orange-500/20 rounded-full flex items-center justify-center group-hover:bg-orange-500/40 transition-all duration-300 group-hover:scale-110">
                <Bot className="w-6 h-6" />
              </div>
              <div className="text-center">
                <div className="text-xs uppercase tracking-wider opacity-60 mb-1">agent</div>
                <div className="text-2xl font-bold tracking-tight">NANO BANANA</div>
              </div>
              <ExternalLink className="w-5 h-5 opacity-0 group-hover:opacity-100 transition-all duration-300 absolute top-6 right-6" />
            </div>
          </button>

          {/* NAMING Button */}
          <button
            onClick={openNaming}
            className="group relative overflow-hidden px-4 py-4 bg-white/10 backdrop-blur-md border-2 border-white/20 hover:border-orange-400/60 rounded-xl text-white shadow-2xl hover:shadow-orange-500/30 transition-all duration-500 transform hover:scale-[1.02] active:scale-[0.98] animate-fade-in-up"
            style={{ animationDelay: '600ms' }}
          >
            <div className="absolute inset-0 bg-gradient-to-br from-orange-500/0 to-orange-600/0 group-hover:from-orange-500/20 group-hover:to-orange-600/30 transition-all duration-500"></div>

            <div className="relative flex flex-col items-center space-y-2">
              <div className="w-12 h-12 bg-orange-500/20 rounded-full flex items-center justify-center group-hover:bg-orange-500/40 transition-all duration-300 group-hover:scale-110">
                <Bot className="w-6 h-6" />
              </div>
              <div className="text-center">
                <div className="text-xs uppercase tracking-wider opacity-60 mb-1">agent</div>
                <div className="text-2xl font-bold tracking-tight">NAMING</div>
              </div>
              <ExternalLink className="w-5 h-5 opacity-0 group-hover:opacity-100 transition-all duration-300 absolute top-6 right-6" />
            </div>
          </button>
        </div>
      </div>
    </div>
  );
}

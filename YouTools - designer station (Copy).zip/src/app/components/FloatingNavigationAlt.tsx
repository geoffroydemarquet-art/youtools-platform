import { motion } from 'motion/react';
import { Home, Layers, Pen, Sparkles, GraduationCap, Award } from 'lucide-react';

interface FloatingNavigationAltProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

export function FloatingNavigationAlt({ currentPage, onNavigate }: FloatingNavigationAltProps) {
  const navItems = [
    {
      id: 'home',
      icon: Home,
      label: 'Accueil',
      color: 'bg-slate-500',
      glowColor: 'shadow-slate-400/50',
      size: 'w-10 h-10',
      delay: 0
    },
    {
      id: 'photoshop',
      icon: Layers,
      label: 'Photoshop',
      color: 'bg-blue-500',
      glowColor: 'shadow-blue-400/50',
      size: 'w-12 h-12',
      delay: 0.15
    },
    {
      id: 'illustrator',
      icon: Pen,
      label: 'Illustrator',
      color: 'bg-orange-500',
      glowColor: 'shadow-orange-400/50',
      size: 'w-11 h-11',
      delay: 0.3
    },
    {
      id: 'midjourney',
      icon: Sparkles,
      label: 'Midjourney',
      color: 'bg-purple-500',
      glowColor: 'shadow-purple-400/50',
      size: 'w-13 h-13',
      delay: 0.45
    },
    {
      id: 'quiz',
      icon: GraduationCap,
      label: 'Quiz',
      color: 'bg-teal-500',
      glowColor: 'shadow-teal-400/50',
      size: 'w-11 h-11',
      delay: 0.6
    },
    {
      id: 'quiz-results',
      icon: Award,
      label: 'Résultats',
      color: 'bg-yellow-500',
      glowColor: 'shadow-yellow-400/50',
      size: 'w-10 h-10',
      delay: 0.75
    }
  ];

  return (
    <div className="fixed left-6 top-1/2 transform -translate-y-1/2 z-40">
      {/* Background glow */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-b from-transparent via-white/5 to-transparent rounded-full blur-xl w-20 h-80 -left-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1.5, delay: 1 }}
      />

      <div className="relative space-y-6">
        {navItems.map((item, index) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id || (item.id === 'quiz' && currentPage.startsWith('quiz'));
          
          return (
            <motion.div
              key={item.id}
              className="group relative flex items-center"
              initial={{ x: -100, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ 
                duration: 0.8, 
                delay: item.delay + 0.5,
                type: "spring",
                stiffness: 120
              }}
            >
              {/* Connection line */}
              {index < navItems.length - 1 && (
                <motion.div
                  className="absolute top-full left-1/2 transform -translate-x-1/2 w-px h-6 bg-gradient-to-b from-white/20 to-transparent"
                  initial={{ scaleY: 0 }}
                  animate={{ scaleY: 1 }}
                  transition={{ duration: 0.5, delay: item.delay + 1 }}
                />
              )}

              {/* Tooltip */}
              <motion.div
                className="absolute left-16 top-1/2 transform -translate-y-1/2 bg-white/90 backdrop-blur-md text-slate-800 px-4 py-2 rounded-full text-sm whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none transition-all duration-300 shadow-lg"
                initial={{ x: -20, opacity: 0 }}
                whileHover={{ x: 0, opacity: 1 }}
              >
                {item.label}
                {/* Connecting dot */}
                <div className="absolute right-full top-1/2 transform -translate-y-1/2 translate-x-1 w-2 h-2 bg-white/90 rounded-full"></div>
              </motion.div>

              {/* Icon Container */}
              <motion.button
                onClick={() => onNavigate(item.id)}
                className={`relative ${item.size} ${item.color} rounded-full flex items-center justify-center transition-all duration-300 ${
                  isActive ? `${item.glowColor} shadow-lg scale-110` : 'shadow-md hover:shadow-lg'
                } border-2 ${isActive ? 'border-white/60' : 'border-white/30'}`}
                whileHover={{ 
                  scale: 1.2,
                  rotate: 360,
                }}
                whileTap={{ scale: 0.9 }}
                animate={{
                  y: isActive ? [0, -5, 0] : [0, -2, 0],
                  boxShadow: isActive 
                    ? ["0 4px 20px rgba(255,255,255,0.3)", "0 8px 30px rgba(255,255,255,0.5)", "0 4px 20px rgba(255,255,255,0.3)"]
                    : ["0 2px 10px rgba(255,255,255,0.1)", "0 4px 15px rgba(255,255,255,0.2)", "0 2px 10px rgba(255,255,255,0.1)"]
                }}
                transition={{
                  y: { duration: 2 + index * 0.3, repeat: Infinity, ease: "easeInOut" },
                  boxShadow: { duration: 2, repeat: Infinity, ease: "easeInOut" },
                  rotate: { duration: 0.6, ease: "easeInOut" }
                }}
              >
                {/* Inner glow */}
                <motion.div
                  className="absolute inset-1 rounded-full bg-white/20"
                  animate={isActive ? {
                    opacity: [0.2, 0.5, 0.2],
                    scale: [0.8, 1, 0.8]
                  } : {}}
                  transition={{ duration: 1.5, repeat: Infinity }}
                />

                {/* Icon */}
                <Icon 
                  size={item.size.includes('w-10') ? 16 : item.size.includes('w-13') ? 20 : 18} 
                  className="relative z-10 text-white drop-shadow-lg" 
                />

                {/* Active state ring */}
                {isActive && (
                  <motion.div
                    className="absolute inset-0 rounded-full border border-white/40"
                    animate={{ 
                      scale: [1, 1.3, 1],
                      opacity: [0.5, 0, 0.5]
                    }}
                    transition={{ duration: 2, repeat: Infinity }}
                  />
                )}
              </motion.button>

              {/* Orbital dots for active state */}
              {isActive && (
                <div className="absolute inset-0">
                  {[...Array(3)].map((_, i) => (
                    <motion.div
                      key={i}
                      className="absolute w-1.5 h-1.5 bg-white/70 rounded-full"
                      style={{
                        left: '50%',
                        top: '50%',
                      }}
                      animate={{
                        rotate: 360,
                        x: Math.cos(i * (2 * Math.PI / 3)) * 30,
                        y: Math.sin(i * (2 * Math.PI / 3)) * 30,
                      }}
                      transition={{
                        rotate: { duration: 3 + i, repeat: Infinity, ease: "linear" },
                        x: { duration: 3 + i, repeat: Infinity, ease: "linear" },
                        y: { duration: 3 + i, repeat: Infinity, ease: "linear" }
                      }}
                    />
                  ))}
                </div>
              )}
            </motion.div>
          );
        })}

        {/* Progress indicator */}
        <motion.div
          className="absolute -right-4 top-0 bottom-0 w-1 bg-gradient-to-b from-transparent via-white/10 to-transparent rounded-full"
          initial={{ scaleY: 0 }}
          animate={{ scaleY: 1 }}
          transition={{ duration: 1.5, delay: 1.5 }}
        />
      </div>
    </div>
  );
}
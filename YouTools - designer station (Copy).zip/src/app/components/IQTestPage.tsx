import { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { Brain, Target, Award, Clock, ArrowLeft, ArrowRight, RotateCcw } from 'lucide-react';
import { useAuthGuard } from './useAuth';

interface IQQuestion {
  id: number;
  category: 'Logique' | 'Mathématiques' | 'Spatial' | 'Verbal' | 'Analogies';
  question: string;
  options: string[];
  correct: number;
  explanation?: string;
}

const iqQuestions: IQQuestion[] = [
  // Logique (15 questions)
  {
    id: 1,
    category: 'Logique',
    question: 'Si tous les A sont B, et tous les B sont C, alors :',
    options: ['Tous les A sont C', 'Certains A sont C', 'Aucun A n\'est C', 'Impossible à déterminer'],
    correct: 0,
    explanation: 'C\'est un syllogisme classique : A → B → C, donc A → C'
  },
  {
    id: 2,
    category: 'Logique',
    question: 'Quelle est la suite logique : 2, 4, 8, 16, ?',
    options: ['24', '32', '20', '18'],
    correct: 1,
    explanation: 'Chaque nombre est multiplié par 2'
  },
  {
    id: 3,
    category: 'Logique',
    question: 'Si P implique Q, et Q implique R, alors P implique :',
    options: ['R', 'Non-R', 'P', 'Rien'],
    correct: 0,
    explanation: 'Transitivité de l\'implication logique'
  },
  {
    id: 4,
    category: 'Logique',
    question: 'Dans une séquence : Rouge, Bleu, Rouge, Bleu, Rouge, ?, quelle couleur suit ?',
    options: ['Rouge', 'Bleu', 'Vert', 'Jaune'],
    correct: 1,
    explanation: 'Alternance simple Rouge-Bleu'
  },
  {
    id: 5,
    category: 'Logique',
    question: 'Si A = 1, B = 2, C = 3, alors CHAT = ?',
    options: ['3+8+1+20', '3+1+20+8', '8+1+20+3', '20+8+1+3'],
    correct: 0,
    explanation: 'C=3, H=8, A=1, T=20'
  },
  {
    id: 6,
    category: 'Logique',
    question: 'Quelle est la suite : 1, 4, 9, 16, 25, ?',
    options: ['30', '36', '35', '49'],
    correct: 1,
    explanation: 'Carrés parfaits : 1², 2², 3², 4², 5², 6²'
  },
  {
    id: 7,
    category: 'Logique',
    question: 'Si tous les X sont Y, et aucun Y n\'est Z, alors :',
    options: ['Aucun X n\'est Z', 'Tous les X sont Z', 'Certains X sont Z', 'Indéterminé'],
    correct: 0,
    explanation: 'Si X ⊆ Y et Y ∩ Z = ∅, alors X ∩ Z = ∅'
  },
  {
    id: 8,
    category: 'Logique',
    question: 'Trouvez l\'intrus : Triangle, Carré, Cercle, Rectangle',
    options: ['Triangle', 'Carré', 'Cercle', 'Rectangle'],
    correct: 2,
    explanation: 'Le cercle n\'a pas d\'angles contrairement aux autres'
  },
  {
    id: 9,
    category: 'Logique',
    question: 'Si P ou Q est vrai, et P est faux, alors :',
    options: ['Q est vrai', 'Q est faux', 'P est vrai', 'Indéterminé'],
    correct: 0,
    explanation: 'Dans un OU logique, si P est faux et (P OU Q) est vrai, alors Q doit être vrai'
  },
  {
    id: 10,
    category: 'Logique',
    question: 'Suite : AZ, BY, CX, DW, ?',
    options: ['EV', 'FU', 'EW', 'FV'],
    correct: 0,
    explanation: 'Première lettre : ordre alphabétique croissant, deuxième : décroissant'
  },
  {
    id: 11,
    category: 'Logique',
    question: 'Si 3 = 9, 4 = 16, 5 = 25, alors 7 = ?',
    options: ['49', '35', '42', '28'],
    correct: 0,
    explanation: 'Chaque nombre est élevé au carré'
  },
  {
    id: 12,
    category: 'Logique',
    question: 'Quelle figure complète la série : ○, △, □, ○, △, ?',
    options: ['○', '△', '□', '◇'],
    correct: 2,
    explanation: 'Répétition cyclique : cercle, triangle, carré'
  },
  {
    id: 13,
    category: 'Logique',
    question: 'Si demain nous sommes jeudi, quel jour étions-nous avant-hier ?',
    options: ['Lundi', 'Mardi', 'Dimanche', 'Mercredi'],
    correct: 0,
    explanation: 'Demain = jeudi, donc aujourd\'hui = mercredi, hier = mardi, avant-hier = lundi'
  },
  {
    id: 14,
    category: 'Logique',
    question: 'Trouvez le terme manquant : 2, 6, 12, 20, 30, ?',
    options: ['40', '42', '38', '45'],
    correct: 1,
    explanation: 'n(n+1) : 1×2, 2×3, 3×4, 4×5, 5×6, 6×7=42'
  },
  {
    id: 15,
    category: 'Logique',
    question: 'Si A > B, B > C, et C > D, quelle affirmation est vraie ?',
    options: ['A > D', 'D > A', 'A = D', 'Impossible à déterminer'],
    correct: 0,
    explanation: 'Transitivité de l\'ordre : A > B > C > D implique A > D'
  },

  // Mathématiques (10 questions)
  {
    id: 16,
    category: 'Mathématiques',
    question: 'Quel est le prochain nombre dans la suite : 1, 1, 2, 3, 5, 8, ?',
    options: ['11', '13', '15', '12'],
    correct: 1,
    explanation: 'Suite de Fibonacci : chaque terme = somme des deux précédents'
  },
  {
    id: 17,
    category: 'Mathématiques',
    question: 'Si x + 5 = 12, alors x = ?',
    options: ['7', '17', '5', '12'],
    correct: 0,
    explanation: 'x = 12 - 5 = 7'
  },
  {
    id: 18,
    category: 'Mathématiques',
    question: 'Combien de triangles peut-on former avec 6 points, aucun aligné ?',
    options: ['15', '20', '18', '24'],
    correct: 1,
    explanation: 'Combinaisons C(6,3) = 6!/(3!×3!) = 20'
  },
  {
    id: 19,
    category: 'Mathématiques',
    question: 'Si 2^x = 32, alors x = ?',
    options: ['4', '5', '6', '16'],
    correct: 1,
    explanation: '2^5 = 32, donc x = 5'
  },
  {
    id: 20,
    category: 'Mathématiques',
    question: 'Quelle est la moyenne de 7, 14, 21, 28 ?',
    options: ['17.5', '18', '15', '20'],
    correct: 0,
    explanation: '(7+14+21+28)/4 = 70/4 = 17.5'
  },
  {
    id: 21,
    category: 'Mathématiques',
    question: 'Si un rectangle a une longueur de 8 et une largeur de 5, quel est son périmètre ?',
    options: ['26', '40', '13', '24'],
    correct: 0,
    explanation: 'Périmètre = 2(L + l) = 2(8 + 5) = 26'
  },
  {
    id: 22,
    category: 'Mathématiques',
    question: 'Quel est le PGCD de 48 et 18 ?',
    options: ['6', '9', '12', '3'],
    correct: 0,
    explanation: '48 = 2⁴×3, 18 = 2×3², PGCD = 2×3 = 6'
  },
  {
    id: 23,
    category: 'Mathématiques',
    question: 'Si 3x - 7 = 14, alors x = ?',
    options: ['7', '21', '5', '14'],
    correct: 0,
    explanation: '3x = 14 + 7 = 21, donc x = 7'
  },
  {
    id: 24,
    category: 'Mathématiques',
    question: 'Combien y a-t-il de nombres premiers entre 1 et 20 ?',
    options: ['8', '7', '9', '6'],
    correct: 0,
    explanation: '2, 3, 5, 7, 11, 13, 17, 19 = 8 nombres premiers'
  },
  {
    id: 25,
    category: 'Mathématiques',
    question: 'Si f(x) = 2x + 3, alors f(5) = ?',
    options: ['13', '10', '8', '11'],
    correct: 0,
    explanation: 'f(5) = 2×5 + 3 = 10 + 3 = 13'
  },

  // Spatial (10 questions)
  {
    id: 26,
    category: 'Spatial',
    question: 'Un cube a combien de faces ?',
    options: ['6', '8', '12', '4'],
    correct: 0,
    explanation: 'Un cube a 6 faces carrées'
  },
  {
    id: 27,
    category: 'Spatial',
    question: 'Si on plie une feuille en deux, puis encore en deux, combien de sections a-t-on ?',
    options: ['4', '6', '8', '2'],
    correct: 0,
    explanation: 'Premier pli = 2 sections, deuxième pli = 4 sections'
  },
  {
    id: 28,
    category: 'Spatial',
    question: 'Combien d\'arêtes a un tétraèdre ?',
    options: ['6', '4', '8', '12'],
    correct: 0,
    explanation: 'Un tétraèdre (pyramide triangulaire) a 6 arêtes'
  },
  {
    id: 29,
    category: 'Spatial',
    question: 'Dans un carré, combien de diagonales peut-on tracer ?',
    options: ['2', '4', '1', '3'],
    correct: 0,
    explanation: 'Un carré a exactement 2 diagonales qui se croisent au centre'
  },
  {
    id: 30,
    category: 'Spatial',
    question: 'Si on fait tourner un triangle rectangle autour de son côté le plus long, on obtient :',
    options: ['Un cône', 'Un cylindre', 'Une sphère', 'Un cube'],
    correct: 0,
    explanation: 'La rotation d\'un triangle rectangle autour de l\'hypoténuse crée un cône'
  },
  {
    id: 31,
    category: 'Spatial',
    question: 'Combien de faces a un octaèdre ?',
    options: ['8', '6', '12', '10'],
    correct: 0,
    explanation: 'Un octaèdre régulier a 8 faces triangulaires'
  },
  {
    id: 32,
    category: 'Spatial',
    question: 'Une pyramide à base carrée a combien de sommets ?',
    options: ['5', '4', '6', '8'],
    correct: 0,
    explanation: '4 sommets à la base + 1 sommet au-dessus = 5 sommets'
  },
  {
    id: 33,
    category: 'Spatial',
    question: 'Dans un hexagone régulier, quel est l\'angle intérieur ?',
    options: ['120°', '108°', '90°', '135°'],
    correct: 0,
    explanation: 'Angle intérieur = (n-2)×180°/n = (6-2)×180°/6 = 120°'
  },
  {
    id: 34,
    category: 'Spatial',
    question: 'Combien de cubes unitaires faut-il pour construire un cube 3×3×3 ?',
    options: ['27', '9', '18', '24'],
    correct: 0,
    explanation: '3×3×3 = 27 cubes unitaires'
  },
  {
    id: 35,
    category: 'Spatial',
    question: 'Si on déplie un cube, on obtient au maximum combien de configurations différentes ?',
    options: ['11', '8', '6', '14'],
    correct: 0,
    explanation: 'Il existe exactement 11 patrons différents pour un cube'
  },

  // Verbal (10 questions)
  {
    id: 36,
    category: 'Verbal',
    question: 'Quel mot n\'appartient pas au groupe : Chien, Chat, Oiseau, Poisson ?',
    options: ['Chien', 'Chat', 'Oiseau', 'Tous appartiennent'],
    correct: 2,
    explanation: 'L\'oiseau est le seul qui peut voler naturellement'
  },
  {
    id: 37,
    category: 'Verbal',
    question: 'Complétez : Livre est à Bibliothèque ce que Tableau est à ?',
    options: ['Musée', 'Peintre', 'Cadre', 'Art'],
    correct: 0,
    explanation: 'Relation de lieu de conservation/exposition'
  },
  {
    id: 38,
    category: 'Verbal',
    question: 'Quel est l\'antonyme de "Éphémère" ?',
    options: ['Durable', 'Rapide', 'Fragile', 'Temporaire'],
    correct: 0,
    explanation: 'Éphémère signifie de courte durée, l\'opposé est durable'
  },
  {
    id: 39,
    category: 'Verbal',
    question: 'Trouvez l\'intrus : Optimiste, Pessimiste, Réaliste, Artiste',
    options: ['Optimiste', 'Pessimiste', 'Réaliste', 'Artiste'],
    correct: 3,
    explanation: 'Les trois premiers décrivent des attitudes, artiste décrit une profession'
  },
  {
    id: 40,
    category: 'Verbal',
    question: 'Quel mot peut suivre "Arc" pour former un mot composé ?',
    options: ['En-ciel', 'Boutant', 'Bouter', 'Toutes les réponses'],
    correct: 3,
    explanation: 'Arc-en-ciel, arc-boutant, arc-bouter sont tous valides'
  },
  {
    id: 41,
    category: 'Verbal',
    question: 'Synonyme de "Perspicace" :',
    options: ['Clairvoyant', 'Myope', 'Aveugle', 'Distrait'],
    correct: 0,
    explanation: 'Perspicace et clairvoyant signifient tous deux "qui voit bien, qui comprend"'
  },
  {
    id: 42,
    category: 'Verbal',
    question: 'Complétez l\'analogie : Médecin/Hôpital = Professeur/?',
    options: ['École', 'Livre', 'Élève', 'Cours'],
    correct: 0,
    explanation: 'Relation profession/lieu de travail'
  },
  {
    id: 43,
    category: 'Verbal',
    question: 'Quel mot signifie "qui peut être mangé" ?',
    options: ['Comestible', 'Digestible', 'Nutritif', 'Savoureux'],
    correct: 0,
    explanation: 'Comestible signifie exactement "qui peut être mangé sans danger"'
  },
  {
    id: 44,
    category: 'Verbal',
    question: 'L\'antonyme de "Concis" est :',
    options: ['Verbeux', 'Court', 'Précis', 'Bref'],
    correct: 0,
    explanation: 'Concis = bref, précis. L\'opposé est verbeux = qui utilise trop de mots'
  },
  {
    id: 45,
    category: 'Verbal',
    question: 'Quel préfixe signifie "contre" ?',
    options: ['Anti-', 'Pro-', 'Pré-', 'Sub-'],
    correct: 0,
    explanation: 'Le préfixe "anti-" signifie "contre" (antivirus, anticonstitutionnel)'
  },

  // Analogies (5 questions)
  {
    id: 46,
    category: 'Analogies',
    question: 'Eau : Glace = Vapeur : ?',
    options: ['Eau', 'Gaz', 'Condensation', 'Évaporation'],
    correct: 0,
    explanation: 'États de la matière : solide↔liquide = gaz↔liquide'
  },
  {
    id: 47,
    category: 'Analogies',
    question: 'Œil : Voir = Oreille : ?',
    options: ['Entendre', 'Son', 'Musique', 'Bruit'],
    correct: 0,
    explanation: 'Relation organe → fonction : œil sert à voir, oreille sert à entendre'
  },
  {
    id: 48,
    category: 'Analogies',
    question: 'Sculpteur : Marbre = Peintre : ?',
    options: ['Toile', 'Pinceau', 'Couleur', 'Art'],
    correct: 0,
    explanation: 'Relation artiste → support principal : sculpteur travaille le marbre, peintre la toile'
  },
  {
    id: 49,
    category: 'Analogies',
    question: 'Abeille : Ruche = Fourmi : ?',
    options: ['Fourmilière', 'Reine', 'Travail', 'Colonie'],
    correct: 0,
    explanation: 'Relation animal → habitat : abeille vit dans une ruche, fourmi dans une fourmilière'
  },
  {
    id: 50,
    category: 'Analogies',
    question: 'Capitaine : Navire = Pilote : ?',
    options: ['Avion', 'Voiture', 'Vol', 'Ciel'],
    correct: 0,
    explanation: 'Relation dirigeant → véhicule : capitaine dirige un navire, pilote un avion'
  }
];

export function IQTestPage() {
  useAuthGuard();
  
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [participantName, setParticipantName] = useState('');
  const [testStarted, setTestStarted] = useState(false);
  const [timeLeft, setTimeLeft] = useState(60 * 60); // 60 minutes
  const [testCompleted, setTestCompleted] = useState(false);

  // Timer
  useEffect(() => {
    if (testStarted && !testCompleted && timeLeft > 0) {
      const timer = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            finishTest();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [testStarted, testCompleted, timeLeft]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const startTest = () => {
    if (participantName.trim()) {
      setTestStarted(true);
    }
  };

  const selectAnswer = (answerIndex: number) => {
    const newAnswers = [...selectedAnswers];
    newAnswers[currentQuestion] = answerIndex;
    setSelectedAnswers(newAnswers);
  };

  const nextQuestion = () => {
    if (currentQuestion < iqQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      finishTest();
    }
  };

  const previousQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const finishTest = () => {
    setTestCompleted(true);
    setShowResults(true);
    saveResults();
  };

  const calculateIQ = () => {
    let score = 0;
    const categoryScores = {
      'Logique': { correct: 0, total: 0 },
      'Mathématiques': { correct: 0, total: 0 },
      'Spatial': { correct: 0, total: 0 },
      'Verbal': { correct: 0, total: 0 },
      'Analogies': { correct: 0, total: 0 }
    };

    iqQuestions.forEach((question, index) => {
      categoryScores[question.category].total++;
      if (selectedAnswers[index] === question.correct) {
        score++;
        categoryScores[question.category].correct++;
      }
    });

    // Calcul du QI basé sur un score sur 50 questions
    // QI moyen = 100, écart-type = 15
    const rawScore = score;
    const maxScore = iqQuestions.length;
    const percentage = (rawScore / maxScore) * 100;
    
    // Conversion en QI (distribution normale)
    let iq = 100;
    if (percentage >= 98) iq = 130; // Très supérieur
    else if (percentage >= 95) iq = 125; // Supérieur
    else if (percentage >= 85) iq = 115; // Au-dessus de la moyenne
    else if (percentage >= 75) iq = 110; // Légèrement au-dessus
    else if (percentage >= 65) iq = 105; // Moyen supérieur
    else if (percentage >= 55) iq = 100; // Moyen
    else if (percentage >= 45) iq = 95; // Moyen inférieur
    else if (percentage >= 35) iq = 90; // En dessous de la moyenne
    else if (percentage >= 25) iq = 85; // Limite inférieure
    else if (percentage >= 15) iq = 80; // Faible
    else iq = 75; // Très faible

    return { rawScore, maxScore, percentage, iq, categoryScores };
  };

  const getIQDescription = (iq: number) => {
    if (iq >= 130) return { level: 'QI Très Supérieur', description: 'Capacités intellectuelles exceptionnelles. Facilité remarquable pour l\'apprentissage et la résolution de problèmes complexes.', color: 'text-purple-600', bg: 'bg-purple-50' };
    if (iq >= 115) return { level: 'QI Supérieur', description: 'Excellentes capacités de raisonnement. Facilité pour les études supérieures et les professions intellectuelles.', color: 'text-blue-600', bg: 'bg-blue-50' };
    if (iq >= 100) return { level: 'QI Moyen Supérieur', description: 'Bonnes capacités intellectuelles. Potentiel d\'apprentissage solide dans la plupart des domaines.', color: 'text-green-600', bg: 'bg-green-50' };
    if (iq >= 85) return { level: 'QI Moyen', description: 'Capacités intellectuelles dans la norme. Apprentissage standard avec un effort approprié.', color: 'text-teal-600', bg: 'bg-teal-50' };
    if (iq >= 70) return { level: 'QI Moyen Inférieur', description: 'Capacités légèrement en dessous de la moyenne. Peut nécessiter plus de temps et d\'efforts pour l\'apprentissage.', color: 'text-orange-600', bg: 'bg-orange-50' };
    return { level: 'QI Limite', description: 'Difficultés possibles dans certains apprentissages. Un accompagnement spécialisé peut être bénéfique.', color: 'text-red-600', bg: 'bg-red-50' };
  };

  const saveResults = () => {
    const results = calculateIQ();
    const newResult = {
      type: 'IQ',
      name: participantName,
      date: new Date().toLocaleDateString('fr-FR'),
      time: new Date().toLocaleTimeString('fr-FR'),
      ...results
    };
    
    const existingResults = JSON.parse(localStorage.getItem('iqTestResults') || '[]');
    existingResults.push(newResult);
    localStorage.setItem('iqTestResults', JSON.stringify(existingResults));
  };

  const resetTest = () => {
    setCurrentQuestion(0);
    setSelectedAnswers([]);
    setShowResults(false);
    setTestStarted(false);
    setTestCompleted(false);
    setTimeLeft(60 * 60);
    setParticipantName('');
  };

  // Page de démarrage
  if (!testStarted) {
    return (
      <div className="min-h-screen pt-4 pb-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6">
          <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl border border-white/20 overflow-hidden">
            <div className="text-center py-8 sm:py-12 px-6 sm:px-8 bg-gradient-to-b from-white to-purple-50/30">
              <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-br from-purple-100 to-purple-200 rounded-2xl flex items-center justify-center mx-auto mb-4 sm:mb-6 shadow-lg">
                <Brain className="w-6 h-6 sm:w-8 sm:h-8 text-purple-600" />
              </div>
              <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-3 sm:mb-4">Test de QI (Quotient Intellectuel)</h1>
              <p className="text-gray-600 text-base sm:text-lg mb-4 sm:mb-6">
                Évaluez vos capacités de raisonnement logique, mathématique, spatial et verbal
              </p>
              <div className="bg-purple-50 border border-purple-200 p-4 sm:p-6 rounded-xl inline-block shadow-sm">
                <p className="text-purple-700 font-medium text-sm sm:text-base">
                  🧠 50 questions • ⏱️ 60 minutes • 📊 Analyse détaillée par domaine
                </p>
              </div>
            </div>
            
            <div className="p-6 sm:p-8 space-y-6">
              <div className="max-w-md mx-auto space-y-4">
                <div>
                  <label className="block font-medium text-gray-700 mb-2 text-sm sm:text-base">
                    Votre nom complet (obligatoire)
                  </label>
                  <Input
                    type="text"
                    placeholder="Entrez votre nom et prénom"
                    value={participantName}
                    onChange={(e) => setParticipantName(e.target.value)}
                    className="w-full bg-white border-gray-200 text-gray-900 placeholder-gray-500 focus:border-purple-500 focus:ring-purple-500/20 rounded-xl shadow-sm"
                  />
                </div>
                
                <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl">
                  <h3 className="font-semibold text-amber-800 mb-2">⚠️ Instructions importantes :</h3>
                  <ul className="text-amber-700 text-sm space-y-1">
                    <li>• Lisez attentivement chaque question</li>
                    <li>• Une seule réponse par question</li>
                    <li>• Vous avez 60 minutes au total</li>
                    <li>• Pas de retour en arrière après soumission</li>
                  </ul>
                </div>
                
                <Button 
                  onClick={startTest} 
                  disabled={!participantName.trim()}
                  className="w-full py-3 text-base sm:text-lg bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white shadow-lg disabled:opacity-50"
                >
                  <Brain className="w-5 h-5 mr-2" />
                  Commencer le Test de QI
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Page de résultats
  if (showResults) {
    const results = calculateIQ();
    const iqInfo = getIQDescription(results.iq);
    
    return (
      <div className="min-h-screen pt-4 pb-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl border border-white/20 overflow-hidden">
            {/* Header Résultats */}
            <div className="bg-gradient-to-r from-purple-50 to-purple-100/50 p-6 sm:p-8 border-b border-gray-200/50">
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-purple-100 to-purple-200 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <Award className="w-8 h-8 text-purple-600" />
                </div>
                <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">Résultats de votre Test de QI</h1>
                <p className="text-gray-600 text-lg">{participantName}</p>
              </div>
            </div>

            <div className="p-6 sm:p-8 space-y-8">
              {/* QI Principal */}
              <div className={`${iqInfo.bg} border border-purple-200 rounded-xl p-6 sm:p-8 text-center`}>
                <div className="mb-4">
                  <div className={`text-5xl sm:text-6xl font-bold ${iqInfo.color} mb-2`}>{results.iq}</div>
                  <div className={`text-lg sm:text-xl font-semibold ${iqInfo.color} mb-3`}>{iqInfo.level}</div>
                  <Progress value={(results.rawScore / results.maxScore) * 100} className="mb-4" />
                  <div className="text-gray-600 text-sm sm:text-base">
                    Score : {results.rawScore}/{results.maxScore} ({Math.round(results.percentage)}%)
                  </div>
                </div>
                <p className={`${iqInfo.color} text-sm sm:text-base font-medium`}>{iqInfo.description}</p>
              </div>

              {/* Analyse par catégorie */}
              <div>
                <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-6 text-center">Analyse détaillée par domaine</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                  {Object.entries(results.categoryScores).map(([category, score]: [string, any]) => {
                    const percentage = Math.round((score.correct / score.total) * 100);
                    let colorClass = 'text-green-600 bg-green-50';
                    if (percentage < 50) colorClass = 'text-red-600 bg-red-50';
                    else if (percentage < 70) colorClass = 'text-orange-600 bg-orange-50';
                    else if (percentage < 85) colorClass = 'text-blue-600 bg-blue-50';
                    
                    return (
                      <Card key={category} className="border-gray-200 shadow-sm hover:shadow-md transition-shadow">
                        <CardContent className="p-4 sm:p-6">
                          <div className="text-center">
                            <h4 className="font-semibold text-gray-900 mb-2 text-sm sm:text-base">{category}</h4>
                            <div className={`text-2xl sm:text-3xl font-bold mb-2 ${colorClass.split(' ')[0]}`}>
                              {percentage}%
                            </div>
                            <div className="text-gray-600 text-xs sm:text-sm">
                              {score.correct}/{score.total} bonnes réponses
                            </div>
                            <Progress value={percentage} className="mt-3" />
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>

              {/* Interprétation */}
              <div className="bg-gray-50 rounded-xl p-6 sm:p-8">
                <h3 className="text-lg sm:text-xl font-bold text-gray-900 mb-4">Interprétation de votre QI</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-3">Signification du score :</h4>
                    <ul className="space-y-2 text-gray-600 text-sm sm:text-base">
                      <li>• <strong>130+</strong> : QI très supérieur (2% population)</li>
                      <li>• <strong>115-129</strong> : QI supérieur (14% population)</li>
                      <li>• <strong>85-114</strong> : QI moyen (68% population)</li>
                      <li>• <strong>70-84</strong> : QI limite (14% population)</li>
                      <li>• <strong>&lt;70</strong> : Déficience intellectuelle (2% population)</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-3">Points à retenir :</h4>
                    <ul className="space-y-2 text-gray-600 text-sm sm:text-base">
                      <li>• Le QI mesure certaines capacités cognitives</li>
                      <li>• Il existe plusieurs formes d\'intelligence</li>
                      <li>• L\'effort et la pratique améliorent les performances</li>
                      <li>• Ce test donne une estimation indicative</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  onClick={resetTest}
                  className="bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white shadow-lg px-6 py-3"
                >
                  <RotateCcw className="w-5 h-5 mr-2" />
                  Refaire le test
                </Button>
                <Button 
                  onClick={() => window.print()}
                  variant="outline"
                  className="border-gray-300 text-gray-700 hover:bg-gray-50 px-6 py-3"
                >
                  Imprimer les résultats
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Test en cours
  const question = iqQuestions[currentQuestion];
  const progress = ((currentQuestion + 1) / iqQuestions.length) * 100;

  return (
    <div className="min-h-screen pt-4 pb-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl border border-white/20 overflow-hidden">
          {/* Header avec progression */}
          <div className="bg-gradient-to-r from-purple-50 to-purple-100/50 p-4 sm:p-6 border-b border-gray-200/50">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center space-x-3">
                <Brain className="w-6 h-6 text-purple-600" />
                <div>
                  <h2 className="font-bold text-gray-900 text-sm sm:text-base">Test de QI</h2>
                  <p className="text-gray-600 text-xs sm:text-sm">{participantName}</p>
                </div>
              </div>
              <div className="flex items-center space-x-4 text-center">
                <div className="flex items-center space-x-2">
                  <Clock className="w-4 h-4 text-gray-500" />
                  <span className={`font-mono text-sm sm:text-base ${timeLeft < 300 ? 'text-red-600' : 'text-gray-700'}`}>
                    {formatTime(timeLeft)}
                  </span>
                </div>
                <div className="text-xs sm:text-sm text-gray-600">
                  {currentQuestion + 1}/{iqQuestions.length}
                </div>
              </div>
            </div>
            <div className="mt-4">
              <Progress value={progress} className="h-2" />
            </div>
          </div>

          {/* Question */}
          <div className="p-6 sm:p-8">
            <div className="mb-6">
              <div className="flex items-center justify-between mb-4">
                <Badge variant="outline" className="text-purple-600 border-purple-200">
                  {question.category}
                </Badge>
                <span className="text-sm text-gray-500">Question {currentQuestion + 1}</span>
              </div>
              <h3 className="text-lg sm:text-xl font-semibold text-gray-900 mb-6">
                {question.question}
              </h3>
            </div>

            {/* Options */}
            <div className="space-y-3 mb-8">
              {question.options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => selectAnswer(index)}
                  className={`w-full p-4 text-left rounded-xl border-2 transition-all duration-200 ${
                    selectedAnswers[currentQuestion] === index
                      ? 'border-purple-500 bg-purple-50 text-purple-900'
                      : 'border-gray-200 hover:border-purple-300 hover:bg-purple-50/50'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center text-xs font-bold ${
                      selectedAnswers[currentQuestion] === index
                        ? 'border-purple-500 bg-purple-500 text-white'
                        : 'border-gray-300'
                    }`}>
                      {String.fromCharCode(65 + index)}
                    </div>
                    <span className="text-sm sm:text-base">{option}</span>
                  </div>
                </button>
              ))}
            </div>

            {/* Navigation */}
            <div className="flex justify-between">
              <Button
                onClick={previousQuestion}
                disabled={currentQuestion === 0}
                variant="outline"
                className="border-gray-300 text-gray-700 disabled:opacity-50"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Précédent
              </Button>
              
              <Button
                onClick={nextQuestion}
                disabled={selectedAnswers[currentQuestion] === undefined}
                className="bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white disabled:opacity-50"
              >
                {currentQuestion === iqQuestions.length - 1 ? (
                  <>
                    <Target className="w-4 h-4 mr-2" />
                    Terminer
                  </>
                ) : (
                  <>
                    Suivant
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
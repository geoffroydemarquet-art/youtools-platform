import { useEffect } from 'react';

const AUTH_KEY = 'demarquet_tools_auth';

export const useAuthGuard = () => {
  useEffect(() => {
    const checkAuth = () => {
      try {
        const authStatus = sessionStorage.getItem(AUTH_KEY);
        if (authStatus !== 'authenticated') {
          // Rediriger vers la page de connexion en forçant un rechargement
          window.location.reload();
        }
      } catch (error) {
        // En cas d'erreur de lecture du sessionStorage, forcer la reconnexion
        window.location.reload();
      }
    };

    checkAuth();
  }, []);
};

export const isAuthenticated = (): boolean => {
  try {
    return sessionStorage.getItem(AUTH_KEY) === 'authenticated';
  } catch {
    return false;
  }
};
import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Lock, Eye, EyeOff } from 'lucide-react';
import brandLogo from 'figma:asset/d1ed5250e08685dd71de28a35f8fb06a9fda3ac4.png';
import backgroundImage from 'figma:asset/88a091f90336a442fa7c496978d9a0226b121b23.png';

interface LoginPageProps {
  onLogin: () => void;
}

export function LoginPage({ onLogin }: LoginPageProps) {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isError, setIsError] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [logoHovered, setLogoHovered] = useState(false);

  const handleLogin = () => {
    if (password === 'mjm') {
      setIsLoading(true);
      // Petit délai pour l'effet de chargement
      setTimeout(() => {
        onLogin();
      }, 800);
    } else {
      setIsError(true);
      setPassword('');
      // Réinitialiser l'erreur après 3 secondes
      setTimeout(() => {
        setIsError(false);
      }, 3000);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && password.trim()) {
      handleLogin();
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      {/* Login Card */}
      <div className="relative z-30 w-full max-w-md">
        <div className="bg-white/40 backdrop-blur-sm rounded-3xl shadow-2xl border border-white/20 overflow-hidden">
          {/* Header avec logo YouTools */}
          <div className="text-center py-12 px-8 bg-gradient-to-b from-white/90 to-orange-50/40">
            <div className="mb-8">
              {/* Logo YouTools avec cercle orange 100% au-dessus */}
              <div className="flex flex-col items-center justify-center space-y-4 mb-6">
                <div 
                  className="relative"
                  onMouseEnter={() => setLogoHovered(true)}
                  onMouseLeave={() => setLogoHovered(false)}
                >
                  {/* Cercle orange 100% avec + */}
                  <div 
                    className="w-16 h-16 bg-orange-600 rounded-full flex items-center justify-center text-white text-3xl font-bold leading-none shadow-lg"
                  >
                    +
                  </div>
                </div>
                <div className="text-center">
                  <h1 className="font-condensed font-black tracking-tight text-4xl text-orange-600">
                    YouTools
                  </h1>
                  <p className="text-sm text-gray-500 mt-1">Professional Training Platform</p>
                </div>
              </div>
            </div>
            
            {/* Lock icon */}
            <div className="w-12 h-12 mx-auto bg-white/80 backdrop-blur-sm rounded-full flex items-center justify-center mb-4 shadow-sm border border-white/30">
              <Lock className="w-6 h-6 text-orange-600" />
            </div>
            <h2 className="text-lg font-semibold text-gray-800 mb-2">Accès Sécurisé</h2>
            <p className="text-gray-600 text-sm">Entrez le mot de passe pour continuer</p>
          </div>

          {/* Form */}
          <div className="p-8">
            <div className="space-y-6">
              {/* Password input */}
              <div className="space-y-2">
                <div className="relative">
                  <Input
                    type={showPassword ? "text" : "password"}
                    placeholder="Mot de passe"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    onKeyPress={handleKeyPress}
                    className={`w-full bg-white/90 border-2 text-gray-900 placeholder-gray-500 focus:ring-orange-500/20 rounded-xl shadow-sm py-3 px-4 pr-12 transition-all duration-300 ${
                      isError 
                        ? 'border-red-300 focus:border-red-500 bg-red-50/50' 
                        : 'border-gray-200 focus:border-orange-500'
                    }`}
                    disabled={isLoading}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                    disabled={isLoading}
                  >
                    {showPassword ? (
                      <EyeOff className="w-5 h-5" />
                    ) : (
                      <Eye className="w-5 h-5" />
                    )}
                  </button>
                </div>
                
                {/* Error message */}
                {isError && (
                  <div className="flex items-center space-x-2 text-red-600 text-sm animate-fade-in-scale">
                    <div className="w-4 h-4 rounded-full bg-red-100 flex items-center justify-center">
                      <div className="w-2 h-2 rounded-full bg-red-500"></div>
                    </div>
                    <span>Mot de passe incorrect. Veuillez réessayer.</span>
                  </div>
                )}
              </div>

              {/* Login button */}
              <Button 
                onClick={handleLogin}
                disabled={!password.trim() || isLoading}
                className={`w-full py-3 text-lg font-semibold rounded-xl transition-all duration-300 ${
                  isLoading
                    ? 'bg-orange-400 cursor-not-allowed'
                    : 'bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 hover:shadow-lg hover:shadow-orange-500/25 active:scale-[0.98]'
                } text-white shadow-lg disabled:opacity-50`}
              >
                {isLoading ? (
                  <div className="flex items-center justify-center space-x-2">
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    <span>Connexion...</span>
                  </div>
                ) : (
                  'Se connecter'
                )}
              </Button>
            </div>

            {/* Hint (subtil) */}
            <div className="mt-8 text-center">
              <div className="inline-flex items-center space-x-2 px-4 py-2 bg-orange-50/80 rounded-lg border border-orange-200/60">
                <div className="w-2 h-2 bg-orange-500 rounded-full animate-pulse"></div>
                <span className="text-orange-700 text-xs font-medium">Accès autorisé requis</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-8">
          <p className="text-white/80 text-sm">
            © 2026 YouTools - Formation Professionnelle
          </p>
        </div>
      </div>
    </div>
  );
}
import { useState } from 'react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ArrowLeft, ExternalLink, FormInput, Lock } from 'lucide-react';
import { useAuthGuard } from './useAuth';

interface GoogleFormEvaluationProps {
  onBack: () => void;
}

export function GoogleFormEvaluation({ onBack }: GoogleFormEvaluationProps) {
  // Protection d'authentification
  useAuthGuard();

  const [isLoading, setIsLoading] = useState(true);
  const [password, setPassword] = useState('');
  const [passwordVerified, setPasswordVerified] = useState(false);

  const handleIframeLoad = () => {
    setIsLoading(false);
  };

  const verifyPassword = () => {
    if (password === 'yoyo') {
      setPasswordVerified(true);
    } else {
      alert('Mot de passe incorrect');
      setPassword('');
    }
  };

  // Page de vérification du mot de passe
  if (!passwordVerified) {
    return (
      <div className="min-h-screen pt-4 pb-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6">
          <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl border border-white/20 overflow-hidden">
            {/* Header avec bouton retour */}
            <div className="bg-gradient-to-r from-orange-50 to-orange-100/50 p-6 border-b border-gray-200/50">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-orange-100 to-orange-200 rounded-xl flex items-center justify-center shadow-lg">
                    <Lock className="w-6 h-6 text-orange-600" />
                  </div>
                  <div>
                    <h1 className="text-2xl font-bold text-gray-900">Accès Évaluation Personnalisée</h1>
                    <p className="text-gray-600">Entrez le mot de passe pour accéder au formulaire</p>
                  </div>
                </div>
                <div className="flex space-x-3">
                  <Button 
                    onClick={onBack}
                    variant="outline" 
                    size="sm" 
                    className="border-gray-200 text-gray-600 hover:bg-gray-50"
                  >
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Retour
                  </Button>
                </div>
              </div>
            </div>

            {/* Contenu de vérification du mot de passe */}
            <div className="text-center py-12 px-8">
              <div className="w-20 h-20 bg-gradient-to-br from-orange-100 to-orange-200 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                <Lock className="w-10 h-10 text-orange-600" />
              </div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Accès Protégé</h2>
              <p className="text-gray-600 text-lg mb-8">
                Cette évaluation personnalisée nécessite un mot de passe d'accès
              </p>
              
              <div className="max-w-md mx-auto space-y-6">
                <Input
                  type="password"
                  placeholder="Entrez le mot de passe"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="text-center bg-white border-gray-200 text-gray-900 placeholder-gray-500 focus:border-orange-500 focus:ring-orange-500/20 rounded-xl shadow-sm"
                  onKeyPress={(e) => e.key === 'Enter' && verifyPassword()}
                />
                <Button 
                  onClick={verifyPassword} 
                  disabled={!password.trim()}
                  className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white shadow-lg disabled:opacity-50"
                >
                  <FormInput className="w-4 h-4 mr-2" />
                  Accéder à l'Évaluation
                </Button>
              </div>

              {/* Info supplémentaire */}
              <div className="mt-8 p-4 bg-orange-50 rounded-xl border border-orange-200">
                <p className="text-sm text-orange-700">
                  <span className="font-medium">Information :</span> Cette évaluation contient des questions 
                  approfondies nécessitant un accès spécialisé.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Page principale du formulaire (après vérification du mot de passe)
  return (
    <div className="min-h-screen pt-4 pb-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl border border-white/20 overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-orange-50 to-orange-100/50 p-6 border-b border-gray-200/50">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gradient-to-br from-orange-100 to-orange-200 rounded-xl flex items-center justify-center shadow-lg">
                  <FormInput className="w-6 h-6 text-orange-600" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">Évaluation Personnalisée</h1>
                  <p className="text-gray-600">Formulaire d'évaluation avec analyse détaillée</p>
                </div>
              </div>
              <div className="flex space-x-3">
                <Button 
                  onClick={onBack}
                  variant="outline" 
                  size="sm" 
                  className="border-gray-200 text-gray-600 hover:bg-gray-50"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Retour
                </Button>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="p-6 sm:p-8">
            {/* Instructions */}
            <div className="mb-6">
              <Card className="bg-gradient-to-r from-orange-50 to-orange-100/30 border-orange-200">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4">
                    <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                      <FormInput className="w-5 h-5 text-orange-600" />
                    </div>
                    <div className="space-y-3">
                      <h3 className="text-lg font-semibold text-gray-900">Instructions pour l'évaluation</h3>
                      <div className="text-gray-700 space-y-2">
                        <p>• Prenez le temps de répondre à chaque question de manière réfléchie</p>
                        <p>• Cette évaluation vous permettra d'obtenir une analyse personnalisée</p>
                        <p>• Durée estimée : 20-30 minutes</p>
                        <p>• Vos réponses sont confidentielles et utilisées uniquement pour l'évaluation</p>
                      </div>
                      <div className="flex items-center space-x-2 pt-2">
                        <Button 
                          onClick={() => window.open('https://docs.google.com/forms/d/e/1FAIpQLSfoBjyp4AR0mBTMEWWuL-YwgFmklKB8LaP3AAFk_9gZRE6u7w/viewform', '_blank')}
                          variant="outline"
                          size="sm"
                          className="border-orange-200 text-orange-600 hover:bg-orange-50"
                        >
                          <ExternalLink className="w-4 h-4 mr-2" />
                          Ouvrir dans un nouvel onglet
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Google Form iframe */}
            <div className="relative">
              <Card className="border-orange-200 overflow-hidden shadow-lg">
                <CardContent className="p-0">
                  {isLoading && (
                    <div className="absolute inset-0 bg-orange-50/50 backdrop-blur-sm flex items-center justify-center z-10">
                      <div className="text-center space-y-4">
                        <div className="w-12 h-12 bg-gradient-to-br from-orange-100 to-orange-200 rounded-xl flex items-center justify-center mx-auto animate-pulse">
                          <FormInput className="w-6 h-6 text-orange-600" />
                        </div>
                        <div className="space-y-2">
                          <div className="text-lg font-medium text-gray-900">Chargement du formulaire...</div>
                          <div className="text-sm text-gray-600">Veuillez patienter quelques instants</div>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  <div className="w-full" style={{ height: 'calc(100vh - 300px)', minHeight: '800px' }}>
                    <iframe 
                      src="https://docs.google.com/forms/d/e/1FAIpQLSfoBjyp4AR0mBTMEWWuL-YwgFmklKB8LaP3AAFk_9gZRE6u7w/viewform?embedded=true"
                      width="100%" 
                      height="100%"
                      style={{ 
                        border: 'none',
                        borderRadius: '0.75rem'
                      }}
                      onLoad={handleIframeLoad}
                      title="Formulaire d'évaluation Creative Tools"
                      className="w-full h-full"
                    >
                      Chargement…
                    </iframe>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Footer info */}
            <div className="mt-6 text-center">
              <div className="bg-gray-50 rounded-xl p-4 border border-gray-200">
                <p className="text-sm text-gray-600">
                  <span className="font-medium">Besoin d'aide ?</span> Si le formulaire ne se charge pas correctement, 
                  utilisez le bouton "Ouvrir dans un nouvel onglet" ci-dessus.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { CheckCircle, Lightbulb, AlertCircle, Layers, Scissors, MousePointer, Target, Sun } from 'lucide-react';

// Tutoriel Motifs
const patternTutorial = {
  title: 'Création de Motifs',
  description: 'Apprenez à créer des motifs répétitifs personnalisés',
  level: 'Intermédiaire',
  duration: '20 min',
  steps: [
    {
      step: 1,
      title: 'Créer le motif de base',
      description: 'Dessinez ou importez l\'élément qui servira de base à votre motif.',
      details: [
        'Créez un nouveau document carré (ex: 100x100px)',
        'Dessinez votre élément au centre du document',
        'Gardez des bords nets pour un motif qui se répète bien',
        'Évitez les éléments qui touchent les bords'
      ]
    },
    {
      step: 2,
      title: 'Définir comme motif',
      description: 'Enregistrez votre création comme motif réutilisable.',
      details: [
        'Allez dans Édition > Utiliser comme motif',
        'Nommez votre motif de façon descriptive',
        'Le motif est maintenant dans votre bibliothèque',
        'Testez le rendu avec l\'aperçu'
      ]
    },
    {
      step: 3,
      title: 'Appliquer le motif',
      description: 'Utilisez votre motif sur des formes ou arrière-plans.',
      details: [
        'Créez un calque de fond ou une forme',
        'Allez dans Calque > Style de calque > Incrustation de motif',
        'Sélectionnez votre motif personnalisé',
        'Ajustez l\'échelle et l\'opacité selon vos besoins'
      ]
    }
  ]
};

// Tutoriel Cuthead
const cutheadTutorial = {
  title: 'Technique Cuthead',
  description: 'Maîtrisez la découpe et le masquage créatif',
  level: 'Avancé',
  duration: '25 min',
  steps: [
    {
      step: 1,
      title: 'Préparer l\'image',
      description: 'Sélectionnez et préparez l\'image pour la découpe.',
      details: [
        'Ouvrez une image portrait de qualité',
        'Dupliquez le calque (⌘+J)',
        'Créez un nouveau calque pour le travail de découpe',
        'Organisez vos calques avec des noms clairs'
      ]
    },
    {
      step: 2,
      title: 'Créer la découpe',
      description: 'Utilisez l\'outil Plume pour découper la forme désirée.',
      details: [
        'Sélectionnez l\'outil Plume (P)',
        'Tracez le contour de la zone à découper',
        'Fermez le tracé en cliquant sur le point de départ',
        'Convertissez le tracé en sélection (⌘+Entrée)'
      ]
    },
    {
      step: 3,
      title: 'Appliquer l\'effet',
      description: 'Créez l\'effet cuthead avec masques et calques.',
      details: [
        'Ajoutez un masque de calque avec la sélection',
        'Créez un arrière-plan contrasté',
        'Ajustez les bords avec l\'outil Améliorer le contour',
        'Ajoutez des ombres portées pour plus de réalisme'
      ]
    }
  ]
};

// Tutoriel Pathfinder
const pathfinderTutorial = {
  title: 'Pathfinder Illustrator',
  description: 'Maîtrisez les opérations booléennes sur les formes',
  level: 'Intermédiaire',
  duration: '15 min',
  steps: [
    {
      step: 1,
      title: 'Créer les formes de base',
      description: 'Dessinez les formes qui serviront aux opérations.',
      details: [
        'Créez plusieurs formes géométriques',
        'Superposez-les partiellement',
        'Utilisez différentes couleurs pour distinguer',
        'Sélectionnez toutes les formes'
      ]
    },
    {
      step: 2,
      title: 'Utiliser Pathfinder',
      description: 'Appliquez les différentes opérations Pathfinder.',
      details: [
        'Ouvrez Fenêtre > Pathfinder',
        'Testez Union pour fusionner les formes',
        'Essayez Soustraction pour découper',
        'Explorez Intersection et Exclusion'
      ]
    },
    {
      step: 3,
      title: 'Finaliser la forme',
      description: 'Optimisez le résultat final.',
      details: [
        'Développez l\'objet si nécessaire',
        'Ajustez les couleurs et contours',
        'Simplifiez les tracés complexes',
        'Sauvegardez comme symbole réutilisable'
      ]
    }
  ]
};

// Tutoriel Détourage
const maskingTutorial = {
  title: 'Détourage Professionnel',
  description: 'Techniques avancées de détourage et masquage',
  level: 'Avancé',
  duration: '30 min',
  steps: [
    {
      step: 1,
      title: 'Analyser l\'image',
      description: 'Évaluez la complexité du détourage à effectuer.',
      details: [
        'Identifiez les zones complexes (cheveux, transparence)',
        'Choisissez la technique appropriée',
        'Préparez l\'image (contraste, netteté)',
        'Dupliquez le calque d\'origine'
      ]
    },
    {
      step: 2,
      title: 'Détourage principal',
      description: 'Effectuez le détourage des zones principales.',
      details: [
        'Utilisez l\'outil Plume pour les contours nets',
        'Employez Sélection d\'objet pour les formes simples',
        'Appliquez Sélectionner et masquer pour les détails',
        'Créez un masque de calque'
      ]
    },
    {
      step: 3,
      title: 'Affiner les détails',
      description: 'Perfectionnez les zones complexes.',
      details: [
        'Utilisez l\'outil Améliorer le contour',
        'Ajustez le contour progressif',
        'Peignez sur le masque pour les corrections',
        'Testez sur différents arrière-plans'
      ]
    }
  ]
};

// Tutoriel Dodge & Burn
const dodgeBurnTutorial = {
  title: 'Dodge & Burn',
  description: 'Techniques d\'éclaircissement et d\'assombrissement',
  level: 'Intermédiaire',
  duration: '25 min',
  steps: [
    {
      step: 1,
      title: 'Préparer l\'image',
      description: 'Configurez votre espace de travail pour le dodge & burn.',
      details: [
        'Ouvrez un portrait en haute résolution',
        'Créez un calque gris neutre (50% gray)',
        'Changez le mode de fusion en Lumière douce',
        'Dupliquez ce calque pour sauvegarder'
      ]
    },
    {
      step: 2,
      title: 'Éclaircir (Dodge)',
      description: 'Utilisez l\'outil Densité - pour éclaircir.',
      details: [
        'Sélectionnez l\'outil Densité - (O)',
        'Réglez sur Tons moyens, exposition 10-15%',
        'Peignez sur les zones à éclaircir',
        'Concentrez-vous sur les hautes lumières naturelles'
      ]
    },
    {
      step: 3,
      title: 'Assombrir (Burn)',
      description: 'Appliquez l\'outil Densité + pour les ombres.',
      details: [
        'Basculez sur l\'outil Densité + (O)',
        'Même réglage : Tons moyens, exposition 10-15%',
        'Renforcez les ombres naturelles',
        'Créez du volume et de la profondeur'
      ]
    }
  ]
};

export function TutorialPage() {
  const [selectedTutorial, setSelectedTutorial] = useState<string>('patterns');

  const tutorials = {
    patterns: patternTutorial,
    cuthead: cutheadTutorial,
    pathfinder: pathfinderTutorial,
    masking: maskingTutorial,
    dodgeburn: dodgeBurnTutorial
  };

  const tutorialIcons = {
    patterns: <Layers className="w-5 h-5" />,
    cuthead: <Scissors className="w-5 h-5" />,
    pathfinder: <MousePointer className="w-5 h-5" />,
    masking: <Target className="w-5 h-5" />,
    dodgeburn: <Sun className="w-5 h-5" />
  };

  const currentTutorial = tutorials[selectedTutorial as keyof typeof tutorials];

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'Débutant':
        return 'bg-green-100 text-green-800';
      case 'Intermédiaire':
        return 'bg-yellow-100 text-yellow-800';
      case 'Avancé':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="w-full">
      <Tabs value={selectedTutorial} onValueChange={setSelectedTutorial} className="w-full">
        <div className="text-center mb-8">
          <h1 className="text-4xl text-gray-900 mb-4">Tutoriels Créatifs</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Maîtrisez les techniques essentielles de Photoshop et Illustrator avec nos guides détaillés.
          </p>
        </div>

        <TabsList className="grid grid-cols-5 mb-8 bg-white/50 backdrop-blur-sm h-auto p-2">
          <TabsTrigger 
            value="patterns" 
            className="data-[state=active]:bg-white data-[state=active]:shadow-sm flex flex-col items-center p-4 space-y-2"
          >
            <Layers className="w-6 h-6" />
            <span className="text-xs">Motifs</span>
          </TabsTrigger>
          <TabsTrigger 
            value="cuthead" 
            className="data-[state=active]:bg-white data-[state=active]:shadow-sm flex flex-col items-center p-4 space-y-2"
          >
            <Scissors className="w-6 h-6" />
            <span className="text-xs">Cuthead</span>
          </TabsTrigger>
          <TabsTrigger 
            value="pathfinder" 
            className="data-[state=active]:bg-white data-[state=active]:shadow-sm flex flex-col items-center p-4 space-y-2"
          >
            <MousePointer className="w-6 h-6" />
            <span className="text-xs">Pathfinder</span>
          </TabsTrigger>
          <TabsTrigger 
            value="masking" 
            className="data-[state=active]:bg-white data-[state=active]:shadow-sm flex flex-col items-center p-4 space-y-2"
          >
            <Target className="w-6 h-6" />
            <span className="text-xs">Détourage</span>
          </TabsTrigger>
          <TabsTrigger 
            value="dodgeburn" 
            className="data-[state=active]:bg-white data-[state=active]:shadow-sm flex flex-col items-center p-4 space-y-2"
          >
            <Sun className="w-6 h-6" />
            <span className="text-xs">Dodge & Burn</span>
          </TabsTrigger>
        </TabsList>

        {Object.entries(tutorials).map(([key, tutorial]) => (
          <TabsContent key={key} value={key} className="space-y-8">
            {/* Tutorial Header */}
            <Card className="bg-white/70 backdrop-blur-sm border-gray-200/50">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-2xl text-gray-900 flex items-center">
                    {tutorialIcons[key as keyof typeof tutorialIcons]}
                    <span className="ml-3">{tutorial.title}</span>
                  </CardTitle>
                  <div className="flex items-center space-x-4">
                    <Badge className={`${getLevelColor(tutorial.level)}`}>
                      {tutorial.level}
                    </Badge>
                    <div className="text-sm text-gray-600 flex items-center">
                      <CheckCircle className="w-4 h-4 mr-1" />
                      {tutorial.duration}
                    </div>
                  </div>
                </div>
                <p className="text-gray-600 mt-2">{tutorial.description}</p>
              </CardHeader>
            </Card>

            {/* Tutorial Steps */}
            <div className="space-y-6">
              <h2 className="text-2xl text-gray-900 text-center">Étapes du Tutoriel</h2>
              {tutorial.steps.map((step, index) => (
                <Card key={index} className="bg-white/70 backdrop-blur-sm border-gray-200/50 hover:bg-white/90 transition-all duration-200">
                  <CardHeader>
                    <CardTitle className="text-lg text-gray-900 flex items-center">
                      <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center mr-3 text-sm">
                        {step.step}
                      </div>
                      {step.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <p className="text-gray-700">{step.description}</p>
                    <ul className="space-y-2">
                      {step.details.map((detail, detailIndex) => (
                        <li key={detailIndex} className="flex items-start text-sm text-gray-600">
                          <CheckCircle className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                          {detail}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Tutorial Tips */}
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-white/70 backdrop-blur-sm border-gray-200/50 border-l-4 border-l-blue-500">
                <CardContent className="p-4">
                  <div className="flex items-start space-x-3">
                    <Lightbulb className="w-5 h-5 text-blue-500" />
                    <div>
                      <h4 className="text-sm text-gray-900 mb-2">Astuce Pro</h4>
                      <p className="text-sm text-gray-600 leading-relaxed">
                        Créez toujours une copie de sauvegarde avant d'appliquer des effets destructifs.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white/70 backdrop-blur-sm border-gray-200/50 border-l-4 border-l-orange-500">
                <CardContent className="p-4">
                  <div className="flex items-start space-x-3">
                    <AlertCircle className="w-5 h-5 text-orange-500" />
                    <div>
                      <h4 className="text-sm text-gray-900 mb-2">Point d'Attention</h4>
                      <p className="text-sm text-gray-600 leading-relaxed">
                        Travaillez toujours sur des images en haute résolution pour un résultat optimal.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        ))}
      </Tabs>

      {/* Resources Section */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200/50 mt-12">
        <CardContent className="p-6 text-center">
          <h3 className="text-lg text-gray-900 mb-4">Ressources Pédagogiques</h3>
          <div className="grid md:grid-cols-3 gap-4 mb-6">
            <div className="bg-white/70 p-4 rounded-lg">
              <h4 className="text-sm text-gray-900 mb-2">Fichiers d'exercice</h4>
              <p className="text-xs text-gray-600">Téléchargez les fichiers pour pratiquer</p>
            </div>
            <div className="bg-white/70 p-4 rounded-lg">
              <h4 className="text-sm text-gray-900 mb-2">Actions & Presets</h4>
              <p className="text-xs text-gray-600">Outils pour automatiser vos workflows</p>
            </div>
            <div className="bg-white/70 p-4 rounded-lg">
              <h4 className="text-sm text-gray-900 mb-2">Ressources complémentaires</h4>
              <p className="text-xs text-gray-600">Guides PDF et aide-mémoires</p>
            </div>
          </div>
          <p className="text-sm text-gray-600">
            Tous les fichiers sont disponibles dans votre espace étudiant MJM Graphic Design.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
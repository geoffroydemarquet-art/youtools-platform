import { useEffect } from 'react';

// Configuration Google Analytics 4
const GA_MEASUREMENT_ID = 'G-XXXXXXXXXX'; // À remplacer par votre ID Google Analytics

export function GoogleAnalytics() {
  useEffect(() => {
    // Chargement asynchrone de Google Analytics
    const script1 = document.createElement('script');
    script1.async = true;
    script1.src = `https://www.googletagmanager.com/gtag/js?id=${GA_MEASUREMENT_ID}`;
    document.head.appendChild(script1);

    const script2 = document.createElement('script');
    script2.innerHTML = `
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', '${GA_MEASUREMENT_ID}', {
        send_page_view: true,
        page_title: document.title,
        page_location: window.location.href,
        custom_map: {
          'dimension1': 'user_type',
          'dimension2': 'page_category'
        }
      });
    `;
    document.head.appendChild(script2);

    // Configuration enhanced ecommerce pour tracking des formations
    window.gtag?.('config', GA_MEASUREMENT_ID, {
      custom_map: {
        'custom_parameter_1': 'formation_type',
        'custom_parameter_2': 'completion_rate'
      }
    });

    return () => {
      // Nettoyage des scripts
      document.head.removeChild(script1);
      document.head.removeChild(script2);
    };
  }, []);

  return null;
}

// Hook pour tracker les événements personnalisés
export const useGoogleAnalytics = () => {
  const trackEvent = (eventName: string, parameters: any = {}) => {
    if (typeof window !== 'undefined' && window.gtag) {
      window.gtag('event', eventName, {
        event_category: 'Creative_Tools',
        event_label: parameters.label || '',
        value: parameters.value || 0,
        custom_parameter_1: parameters.formation_type || '',
        custom_parameter_2: parameters.completion_rate || '',
        ...parameters
      });
    }
  };

  const trackPageView = (pageName: string, pageCategory: string) => {
    if (typeof window !== 'undefined' && window.gtag) {
      window.gtag('config', GA_MEASUREMENT_ID, {
        page_title: pageName,
        page_location: window.location.href,
        custom_map: {
          'dimension2': pageCategory
        }
      });
    }
  };

  const trackFormation = (formationType: string, action: string, progress?: number) => {
    trackEvent('formation_interaction', {
      formation_type: formationType,
      action: action,
      completion_rate: progress,
      label: `${formationType}_${action}`
    });
  };

  const trackQuiz = (quizType: string, score: number, totalQuestions: number) => {
    trackEvent('quiz_completion', {
      quiz_type: quizType,
      score: score,
      total_questions: totalQuestions,
      success_rate: Math.round((score / totalQuestions) * 100),
      label: `${quizType}_completed`
    });
  };

  const trackAIAssistant = (queryType: string, category: string) => {
    trackEvent('ai_assistant_query', {
      query_type: queryType,
      category: category,
      label: `ai_${category}_${queryType}`
    });
  };

  return {
    trackEvent,
    trackPageView,
    trackFormation,
    trackQuiz,
    trackAIAssistant
  };
};

// Déclaration TypeScript pour gtag
declare global {
  interface Window {
    gtag?: (...args: any[]) => void;
    dataLayer?: any[];
  }
}
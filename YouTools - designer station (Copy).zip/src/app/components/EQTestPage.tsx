import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { Heart, Target, Award, Clock, ArrowLeft, ArrowRight, RotateCcw, Users } from 'lucide-react';
import { useAuthGuard } from './useAuth';

interface EQQuestion {
  id: number;
  category: 'Conscience de soi' | 'Autorégulation' | 'Motivation' | 'Empathie' | 'Compétences sociales';
  question: string;
  options: string[];
  correct: number;
  explanation?: string;
}

const eqQuestions: EQQuestion[] = [
  // Conscience de soi (12 questions)
  {
    id: 1,
    category: 'Conscience de soi',
    question: 'Quand vous ressentez de la colère, votre première réaction est généralement de :',
    options: ['Analyser pourquoi vous êtes en colère', 'Exprimer immédiatement votre frustration', 'Ignorer ce sentiment', 'Blâmer les autres'],
    correct: 0,
    explanation: 'La conscience de soi implique de reconnaître et comprendre ses émotions avant d\'agir'
  },
  {
    id: 2,
    category: 'Conscience de soi',
    question: 'Vous êtes le plus conscient de vos émotions :',
    options: ['Au moment où elles surviennent', 'Après réflexion', 'Quand les autres vous les font remarquer', 'Rarement'],
    correct: 0,
    explanation: 'Une haute conscience émotionnelle permet de reconnaître ses émotions en temps réel'
  },
  {
    id: 3,
    category: 'Conscience de soi',
    question: 'Quand vous prenez une décision importante, vous :',
    options: ['Considérez vos émotions et votre logique', 'Suivez uniquement votre instinct', 'Ignorez vos émotions', 'Demandez toujours l\'avis des autres'],
    correct: 0,
    explanation: 'L\'intelligence émotionnelle intègre émotions et rationalité dans la prise de décision'
  },
  {
    id: 4,
    category: 'Conscience de soi',
    question: 'Vous reconnaissez généralement vos forces et faiblesses :',
    options: ['Très facilement', 'Avec un effort de réflexion', 'Difficilement', 'Jamais vraiment'],
    correct: 0,
    explanation: 'La conscience de soi inclut une évaluation réaliste de ses capacités'
  },
  {
    id: 5,
    category: 'Conscience de soi',
    question: 'Face à l\'échec, votre réaction typique est :',
    options: ['Analyser ce qui n\'a pas fonctionné', 'Vous blâmer entièrement', 'Blâmer les circonstances', 'Éviter d\'y penser'],
    correct: 0,
    explanation: 'La conscience de soi permet une analyse objective des situations d\'échec'
  },
  {
    id: 6,
    category: 'Conscience de soi',
    question: 'Vos valeurs personnelles sont :',
    options: ['Clairement définies et guident vos actions', 'Partiellement définies', 'Floues', 'Inexistantes'],
    correct: 0,
    explanation: 'La conscience de soi implique une compréhension claire de ses valeurs'
  },
  {
    id: 7,
    category: 'Conscience de soi',
    question: 'Quand vous êtes stressé, vous :',
    options: ['Reconnaissez rapidement les signes', 'Le réalisez après coup', 'Avez du mal à l\'identifier', 'Ne le remarquez jamais'],
    correct: 0,
    explanation: 'La reconnaissance précoce du stress est un signe de bonne conscience émotionnelle'
  },
  {
    id: 8,
    category: 'Conscience de soi',
    question: 'Votre estime de soi est généralement :',
    options: ['Stable et réaliste', 'Variable selon les circonstances', 'Plutôt faible', 'Excessivement élevée'],
    correct: 0,
    explanation: 'Une conscience de soi saine mène à une estime de soi équilibrée'
  },
  {
    id: 9,
    category: 'Conscience de soi',
    question: 'Vous comprenez l\'impact de vos émotions sur vos performances :',
    options: ['Très bien', 'Assez bien', 'Partiellement', 'Pas du tout'],
    correct: 0,
    explanation: 'Comprendre le lien émotion-performance est essentiel à la conscience de soi'
  },
  {
    id: 10,
    category: 'Conscience de soi',
    question: 'Face aux critiques, vous :',
    options: ['Évaluez objectivement leur validité', 'Vous défendez automatiquement', 'Les acceptez sans réfléchir', 'Les ignorez complètement'],
    correct: 0,
    explanation: 'La conscience de soi permet une réception constructive des critiques'
  },
  {
    id: 11,
    category: 'Conscience de soi',
    question: 'Vos réactions émotionnelles sont généralement :',
    options: ['Proportionnées à la situation', 'Parfois excessives', 'Souvent insuffisantes', 'Imprévisibles'],
    correct: 0,
    explanation: 'La conscience émotionnelle aide à calibrer ses réactions'
  },
  {
    id: 12,
    category: 'Conscience de soi',
    question: 'Vous identifiez vos déclencheurs émotionnels :',
    options: ['Facilement', 'Avec réflexion', 'Difficilement', 'Jamais'],
    correct: 0,
    explanation: 'Connaître ses déclencheurs est fondamental pour la gestion émotionnelle'
  },

  // Autorégulation (12 questions)
  {
    id: 13,
    category: 'Autorégulation',
    question: 'Quand vous êtes très en colère, vous :',
    options: ['Prenez du recul avant de réagir', 'Exprimez immédiatement votre colère', 'Gardez tout pour vous', 'Explosez sans réfléchir'],
    correct: 0,
    explanation: 'L\'autorégulation implique de gérer ses émotions avant de réagir'
  },
  {
    id: 14,
    category: 'Autorégulation',
    question: 'Face à une situation stressante, votre stratégie est :',
    options: ['Respiration profonde et réflexion', 'Action immédiate', 'Évitement', 'Panique'],
    correct: 0,
    explanation: 'Les techniques de relaxation sont essentielles à l\'autorégulation'
  },
  {
    id: 15,
    category: 'Autorégulation',
    question: 'Vous contrôlez vos impulsions :',
    options: ['La plupart du temps', 'Parfois', 'Rarement', 'Jamais'],
    correct: 0,
    explanation: 'Le contrôle des impulsions est un aspect clé de l\'autorégulation'
  },
  {
    id: 16,
    category: 'Autorégulation',
    question: 'Après une erreur importante, vous :',
    options: ['Apprenez et ajustez votre approche', 'Vous culpabilisez longtemps', 'Abandonnez facilement', 'Niez votre responsabilité'],
    correct: 0,
    explanation: 'La résilience et l\'apprentissage caractérisent une bonne autorégulation'
  },
  {
    id: 17,
    category: 'Autorégulation',
    question: 'Dans les conflits, vous :',
    options: ['Restez calme et cherchez des solutions', 'Vous emportez rapidement', 'Évitez la confrontation', 'Attaquez personnellement'],
    correct: 0,
    explanation: 'L\'autorégulation permet de gérer constructivement les conflits'
  },
  {
    id: 18,
    category: 'Autorégulation',
    question: 'Votre capacité à gérer le changement est :',
    options: ['Excellente', 'Bonne', 'Limitée', 'Très difficile'],
    correct: 0,
    explanation: 'L\'adaptabilité au changement reflète une bonne autorégulation'
  },
  {
    id: 19,
    category: 'Autorégulation',
    question: 'Vous gérez votre anxiété en :',
    options: ['Utilisant des techniques de relaxation', 'Évitant les situations anxiogènes', 'Ignorant vos sentiments', 'Laissant l\'anxiété vous submerger'],
    correct: 0,
    explanation: 'Les stratégies de coping actives caractérisent l\'autorégulation'
  },
  {
    id: 20,
    category: 'Autorégulation',
    question: 'Face à la frustration, vous :',
    options: ['Cherchez des alternatives', 'Abandonnez rapidement', 'Vous plaignez aux autres', 'Devenez agressif'],
    correct: 0,
    explanation: 'La persistence et la créativité face aux obstacles montrent l\'autorégulation'
  },
  {
    id: 21,
    category: 'Autorégulation',
    question: 'Votre discipline personnelle est :',
    options: ['Très forte', 'Bonne', 'Variable', 'Faible'],
    correct: 0,
    explanation: 'L\'autodiscipline est un pilier de l\'autorégulation émotionnelle'
  },
  {
    id: 22,
    category: 'Autorégulation',
    question: 'Vous récupérez d\'une déception :',
    options: ['Rapidement et efficacement', 'Assez rapidement', 'Lentement', 'Très difficilement'],
    correct: 0,
    explanation: 'La résilience émotionnelle caractérise une bonne autorégulation'
  },
  {
    id: 23,
    category: 'Autorégulation',
    question: 'Dans la pression, votre performance :',
    options: ['Reste stable ou s\'améliore', 'Diminue légèrement', 'Chute significativement', 'S\'effondre'],
    correct: 0,
    explanation: 'Maintenir ses performances sous pression montre l\'autorégulation'
  },
  {
    id: 24,
    category: 'Autorégulation',
    question: 'Vous exprimez vos émotions négatives :',
    options: ['De manière constructive', 'Parfois de manière explosive', 'En les gardant pour vous', 'De manière destructive'],
    correct: 0,
    explanation: 'L\'expression appropriée des émotions est un aspect de l\'autorégulation'
  },

  // Motivation (8 questions)
  {
    id: 25,
    category: 'Motivation',
    question: 'Votre principale source de motivation est :',
    options: ['Vos objectifs personnels', 'La reconnaissance des autres', 'L\'argent', 'Éviter les problèmes'],
    correct: 0,
    explanation: 'La motivation intrinsèque est plus durable et efficace'
  },
  {
    id: 26,
    category: 'Motivation',
    question: 'Face aux obstacles, vous :',
    options: ['Redoublez d\'efforts', 'Cherchez de l\'aide', 'Abandonnez facilement', 'Vous découragez'],
    correct: 0,
    explanation: 'La persistance face aux difficultés caractérise la motivation élevée'
  },
  {
    id: 27,
    category: 'Motivation',
    question: 'Vous vous fixez des objectifs :',
    options: ['Ambitieux mais réalisables', 'Très faciles', 'Impossibles à atteindre', 'Rarement'],
    correct: 0,
    explanation: 'Des objectifs équilibrés maintiennent la motivation optimale'
  },
  {
    id: 28,
    category: 'Motivation',
    question: 'Votre engagement dans vos projets est :',
    options: ['Total et durable', 'Fort mais variable', 'Modéré', 'Faible'],
    correct: 0,
    explanation: 'L\'engagement profond caractérise une motivation élevée'
  },
  {
    id: 29,
    category: 'Motivation',
    question: 'Vous cherchez l\'excellence :',
    options: ['Dans tout ce que vous faites', 'Dans certains domaines', 'Rarement', 'Jamais'],
    correct: 0,
    explanation: 'La recherche d\'excellence est un moteur de motivation intrinsèque'
  },
  {
    id: 30,
    category: 'Motivation',
    question: 'Face à un échec, vous :',
    options: ['L\'analysez et rebondissez', 'Vous découragez temporairement', 'Perdez confiance durablement', 'Abandonnez définitivement'],
    correct: 0,
    explanation: 'La capacité de rebond après échec montre une motivation solide'
  },
  {
    id: 31,
    category: 'Motivation',
    question: 'Votre optimisme face à l\'avenir est :',
    options: ['Constant et réaliste', 'Variable', 'Limité', 'Inexistant'],
    correct: 0,
    explanation: 'L\'optimisme réaliste soutient la motivation à long terme'
  },
  {
    id: 32,
    category: 'Motivation',
    question: 'Vous prenez des initiatives :',
    options: ['Fréquemment et spontanément', 'Parfois', 'Rarement', 'Jamais'],
    correct: 0,
    explanation: 'La proactivité reflète une motivation intrinsèque élevée'
  },

  // Empathie (9 questions)
  {
    id: 33,
    category: 'Empathie',
    question: 'Vous percevez les émotions des autres :',
    options: ['Facilement et précisément', 'Généralement bien', 'Parfois', 'Rarement'],
    correct: 0,
    explanation: 'L\'empathie commence par la perception des émotions d\'autrui'
  },
  {
    id: 34,
    category: 'Empathie',
    question: 'Quand quelqu\'un est triste, vous :',
    options: ['Ressentez sa tristesse et l\'aidez', 'Offrez des conseils logiques', 'Évitez la personne', 'Ignorez sa tristesse'],
    correct: 0,
    explanation: 'L\'empathie implique de ressentir et de répondre aux émotions d\'autrui'
  },
  {
    id: 35,
    category: 'Empathie',
    question: 'Vous comprenez les perspectives différentes :',
    options: ['Facilement', 'Avec effort', 'Difficilement', 'Jamais'],
    correct: 0,
    explanation: 'L\'empathie cognitive permet de comprendre d\'autres points de vue'
  },
  {
    id: 36,
    category: 'Empathie',
    question: 'Face à quelqu\'un en détresse, vous :',
    options: ['Proposez votre aide immédiatement', 'Attendez qu\'on vous demande', 'Vous sentez mal à l\'aise', 'Évitez la situation'],
    correct: 0,
    explanation: 'L\'empathie mène naturellement à des comportements d\'aide'
  },
  {
    id: 37,
    category: 'Empathie',
    question: 'Vous percevez les besoins non exprimés :',
    options: ['Souvent', 'Parfois', 'Rarement', 'Jamais'],
    correct: 0,
    explanation: 'L\'empathie avancée permet de détecter les besoins implicites'
  },
  {
    id: 38,
    category: 'Empathie',
    question: 'Dans les conflits, vous :',
    options: ['Comprenez les deux points de vue', 'Prenez parti rapidement', 'Évitez de vous impliquer', 'Aggravez la situation'],
    correct: 0,
    explanation: 'L\'empathie aide à voir tous les côtés d\'un conflit'
  },
  {
    id: 39,
    category: 'Empathie',
    question: 'Vous ajustez votre communication selon :',
    options: ['L\'état émotionnel de votre interlocuteur', 'Votre humeur du moment', 'Le sujet de conversation', 'Vous ne l\'ajustez pas'],
    correct: 0,
    explanation: 'L\'empathie guide l\'adaptation de la communication'
  },
  {
    id: 40,
    category: 'Empathie',
    question: 'Les émotions intenses des autres vous :',
    options: ['Touchent mais restent gérables', 'Submergent complètement', 'Laissent indifférent', 'Irritent'],
    correct: 0,
    explanation: 'L\'empathie équilibrée permet de ressentir sans être submergé'
  },
  {
    id: 41,
    category: 'Empathie',
    question: 'Vous vous souciez du bien-être d\'autrui :',
    options: ['Naturellement et sincèrement', 'Quand ça vous arrange', 'Par obligation sociale', 'Pas du tout'],
    correct: 0,
    explanation: 'L\'empathie authentique implique un souci sincère d\'autrui'
  },

  // Compétences sociales (9 questions)
  {
    id: 42,
    category: 'Compétences sociales',
    question: 'Dans un groupe, vous :',
    options: ['Facilitez la communication entre tous', 'Parlez surtout aux personnes que vous connaissez', 'Restez en retrait', 'Dominez les conversations'],
    correct: 0,
    explanation: 'Les compétences sociales incluent la facilitation des interactions de groupe'
  },
  {
    id: 43,
    category: 'Compétences sociales',
    question: 'Votre capacité à influencer positivement est :',
    options: ['Forte et respectueuse', 'Modérée', 'Limitée', 'Inexistante'],
    correct: 0,
    explanation: 'L\'influence positive est une compétence sociale clé'
  },
  {
    id: 44,
    category: 'Compétences sociales',
    question: 'Vous résolvez les conflits en :',
    options: ['Trouvant des solutions gagnant-gagnant', 'Imposant votre point de vue', 'Évitant la confrontation', 'Laissant les autres décider'],
    correct: 0,
    explanation: 'La résolution collaborative de conflits est une compétence sociale avancée'
  },
  {
    id: 45,
    category: 'Compétences sociales',
    question: 'Votre réseau social est :',
    options: ['Diversifié et de qualité', 'Limité mais proche', 'Superficiel', 'Quasi inexistant'],
    correct: 0,
    explanation: 'Développer des relations de qualité est une compétence sociale importante'
  },
  {
    id: 46,
    category: 'Compétences sociales',
    question: 'Vous collaborez avec les autres :',
    options: ['Très efficacement', 'Plutôt bien', 'Avec difficultés', 'Très mal'],
    correct: 0,
    explanation: 'La collaboration efficace est essentielle aux compétences sociales'
  },
  {
    id: 47,
    category: 'Compétences sociales',
    question: 'Votre communication est généralement :',
    options: ['Claire et adaptée au public', 'Correcte mais rigide', 'Souvent mal comprise', 'Confuse'],
    correct: 0,
    explanation: 'L\'adaptation de la communication au public est une compétence sociale clé'
  },
  {
    id: 48,
    category: 'Compétences sociales',
    question: 'Vous inspirez confiance aux autres :',
    options: ['Facilement', 'Généralement', 'Parfois', 'Rarement'],
    correct: 0,
    explanation: 'Inspirer confiance est le résultat de bonnes compétences sociales'
  },
  {
    id: 49,
    category: 'Compétences sociales',
    question: 'Dans le travail d\'équipe, vous :',
    options: ['Fédérez et motivez', 'Participez activement', 'Suivez les directives', 'Créez des tensions'],
    correct: 0,
    explanation: 'Le leadership émotionnel est une compétence sociale avancée'
  },
  {
    id: 50,
    category: 'Compétences sociales',
    question: 'Votre capacité à négocier est :',
    options: ['Excellente et équitable', 'Bonne', 'Limitée', 'Très faible'],
    correct: 0,
    explanation: 'La négociation équitable combine compétences sociales et intelligence émotionnelle'
  }
];

export function EQTestPage() {
  useAuthGuard();
  
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [participantName, setParticipantName] = useState('');
  const [testStarted, setTestStarted] = useState(false);
  const [timeLeft, setTimeLeft] = useState(45 * 60); // 45 minutes
  const [testCompleted, setTestCompleted] = useState(false);

  // Timer
  useEffect(() => {
    if (testStarted && !testCompleted && timeLeft > 0) {
      const timer = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            finishTest();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [testStarted, testCompleted, timeLeft]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const startTest = () => {
    if (participantName.trim()) {
      setTestStarted(true);
    }
  };

  const selectAnswer = (answerIndex: number) => {
    const newAnswers = [...selectedAnswers];
    newAnswers[currentQuestion] = answerIndex;
    setSelectedAnswers(newAnswers);
  };

  const nextQuestion = () => {
    if (currentQuestion < eqQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      finishTest();
    }
  };

  const previousQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const finishTest = () => {
    setTestCompleted(true);
    setShowResults(true);
    saveResults();
  };

  const calculateEQ = () => {
    let score = 0;
    const categoryScores = {
      'Conscience de soi': { correct: 0, total: 0 },
      'Autorégulation': { correct: 0, total: 0 },
      'Motivation': { correct: 0, total: 0 },
      'Empathie': { correct: 0, total: 0 },
      'Compétences sociales': { correct: 0, total: 0 }
    };

    eqQuestions.forEach((question, index) => {
      categoryScores[question.category].total++;
      if (selectedAnswers[index] === question.correct) {
        score++;
        categoryScores[question.category].correct++;
      }
    });

    // Calcul du QE basé sur un score sur 50 questions
    const rawScore = score;
    const maxScore = eqQuestions.length;
    const percentage = (rawScore / maxScore) * 100;
    
    // Conversion en QE (échelle similaire au QI)
    let eq = 100;
    if (percentage >= 95) eq = 130; // Exceptionnellement élevé
    else if (percentage >= 90) eq = 125; // Très élevé
    else if (percentage >= 80) eq = 115; // Élevé
    else if (percentage >= 70) eq = 110; // Au-dessus de la moyenne
    else if (percentage >= 60) eq = 105; // Légèrement au-dessus
    else if (percentage >= 50) eq = 100; // Moyen
    else if (percentage >= 40) eq = 95; // Légèrement en dessous
    else if (percentage >= 30) eq = 90; // En dessous de la moyenne
    else if (percentage >= 20) eq = 85; // Faible
    else if (percentage >= 10) eq = 80; // Très faible
    else eq = 75; // Extrêmement faible

    return { rawScore, maxScore, percentage, eq, categoryScores };
  };

  const getEQDescription = (eq: number) => {
    if (eq >= 125) return { 
      level: 'QE Exceptionnel', 
      description: 'Excellence émotionnelle remarquable. Leadership naturel, empathie profonde et gestion émotionnelle exemplaire. Capacité à inspirer et motiver les autres.',
      color: 'text-purple-600', 
      bg: 'bg-purple-50',
      advice: 'Utilisez vos talents pour mentorer et accompagner les autres dans leur développement émotionnel.'
    };
    if (eq >= 115) return { 
      level: 'QE Élevé', 
      description: 'Très bonnes compétences émotionnelles. Excellente conscience de soi et capacité à gérer les relations interpersonnelles avec succès.',
      color: 'text-blue-600', 
      bg: 'bg-blue-50',
      advice: 'Continuez à développer votre leadership émotionnel et votre capacité d\'influence positive.'
    };
    if (eq >= 105) return { 
      level: 'QE Au-dessus de la Moyenne', 
      description: 'Bonnes compétences émotionnelles. Capacité solide à comprendre et gérer vos émotions ainsi que celles des autres.',
      color: 'text-green-600', 
      bg: 'bg-green-50',
      advice: 'Travaillez sur l\'empathie et les compétences sociales pour atteindre l\'excellence émotionnelle.'
    };
    if (eq >= 95) return { 
      level: 'QE Moyen', 
      description: 'Compétences émotionnelles dans la norme. Base solide avec des opportunités d\'amélioration dans certains domaines.',
      color: 'text-teal-600', 
      bg: 'bg-teal-50',
      advice: 'Focalisez-vous sur la conscience de soi et l\'autorégulation pour progresser.'
    };
    if (eq >= 85) return { 
      level: 'QE En Dessous de la Moyenne', 
      description: 'Compétences émotionnelles à développer. Des efforts ciblés peuvent considérablement améliorer votre intelligence émotionnelle.',
      color: 'text-orange-600', 
      bg: 'bg-orange-50',
      advice: 'Pratiquez la méditation, l\'auto-réflexion et demandez des feedbacks pour progresser.'
    };
    return { 
      level: 'QE Faible', 
      description: 'Défis importants dans la gestion émotionnelle. Un accompagnement spécialisé peut être très bénéfique pour votre développement.',
      color: 'text-red-600', 
      bg: 'bg-red-50',
      advice: 'Considérez un coaching en intelligence émotionnelle ou une formation spécialisée.'
    };
  };

  const saveResults = () => {
    const results = calculateEQ();
    const newResult = {
      type: 'EQ',
      name: participantName,
      date: new Date().toLocaleDateString('fr-FR'),
      time: new Date().toLocaleTimeString('fr-FR'),
      ...results
    };
    
    const existingResults = JSON.parse(localStorage.getItem('eqTestResults') || '[]');
    existingResults.push(newResult);
    localStorage.setItem('eqTestResults', JSON.stringify(existingResults));
  };

  const resetTest = () => {
    setCurrentQuestion(0);
    setSelectedAnswers([]);
    setShowResults(false);
    setTestStarted(false);
    setTestCompleted(false);
    setTimeLeft(45 * 60);
    setParticipantName('');
  };

  // Page de démarrage
  if (!testStarted) {
    return (
      <div className="min-h-screen pt-4 pb-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6">
          <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl border border-white/20 overflow-hidden">
            <div className="text-center py-8 sm:py-12 px-6 sm:px-8 bg-gradient-to-b from-white to-pink-50/30">
              <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-br from-pink-100 to-pink-200 rounded-2xl flex items-center justify-center mx-auto mb-4 sm:mb-6 shadow-lg">
                <Heart className="w-6 h-6 sm:w-8 sm:h-8 text-pink-600" />
              </div>
              <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-3 sm:mb-4">Test de QE (Quotient Émotionnel)</h1>
              <p className="text-gray-600 text-base sm:text-lg mb-4 sm:mb-6">
                Évaluez votre intelligence émotionnelle et vos compétences relationnelles
              </p>
              <div className="bg-pink-50 border border-pink-200 p-4 sm:p-6 rounded-xl inline-block shadow-sm">
                <p className="text-pink-700 font-medium text-sm sm:text-base">
                  💕 50 questions • ⏱️ 45 minutes • 🎯 5 domaines d'évaluation
                </p>
              </div>
            </div>
            
            <div className="p-6 sm:p-8 space-y-6">
              <div className="max-w-md mx-auto space-y-4">
                <div>
                  <label className="block font-medium text-gray-700 mb-2 text-sm sm:text-base">
                    Votre nom complet (obligatoire)
                  </label>
                  <Input
                    type="text"
                    placeholder="Entrez votre nom et prénom"
                    value={participantName}
                    onChange={(e) => setParticipantName(e.target.value)}
                    className="w-full bg-white border-gray-200 text-gray-900 placeholder-gray-500 focus:border-pink-500 focus:ring-pink-500/20 rounded-xl shadow-sm"
                  />
                </div>
                
                <div className="bg-blue-50 border border-blue-200 p-4 rounded-xl">
                  <h3 className="font-semibold text-blue-800 mb-2">🎯 Domaines évalués :</h3>
                  <ul className="text-blue-700 text-sm space-y-1">
                    <li>• <strong>Conscience de soi</strong> - Connaissance de ses émotions</li>
                    <li>• <strong>Autorégulation</strong> - Gestion de ses émotions</li>
                    <li>• <strong>Motivation</strong> - Drive et engagement personnel</li>
                    <li>• <strong>Empathie</strong> - Compréhension des autres</li>
                    <li>• <strong>Compétences sociales</strong> - Relations interpersonnelles</li>
                  </ul>
                </div>
                
                <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl">
                  <h3 className="font-semibold text-amber-800 mb-2">💡 Conseils :</h3>
                  <ul className="text-amber-700 text-sm space-y-1">
                    <li>• Répondez instinctivement, sans trop réfléchir</li>
                    <li>• Soyez honnête avec vous-même</li>
                    <li>• Il n'y a pas de "bonnes" ou "mauvaises" réponses</li>
                    <li>• Choisissez ce qui vous correspond le mieux</li>
                  </ul>
                </div>
                
                <Button 
                  onClick={startTest} 
                  disabled={!participantName.trim()}
                  className="w-full py-3 text-base sm:text-lg bg-gradient-to-r from-pink-500 to-pink-600 hover:from-pink-600 hover:to-pink-700 text-white shadow-lg disabled:opacity-50"
                >
                  <Heart className="w-5 h-5 mr-2" />
                  Commencer le Test de QE
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Page de résultats
  if (showResults) {
    const results = calculateEQ();
    const eqInfo = getEQDescription(results.eq);
    
    return (
      <div className="min-h-screen pt-4 pb-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl border border-white/20 overflow-hidden">
            {/* Header Résultats */}
            <div className="bg-gradient-to-r from-pink-50 to-pink-100/50 p-6 sm:p-8 border-b border-gray-200/50">
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-pink-100 to-pink-200 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <Award className="w-8 h-8 text-pink-600" />
                </div>
                <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">Résultats de votre Test de QE</h1>
                <p className="text-gray-600 text-lg">{participantName}</p>
              </div>
            </div>

            <div className="p-6 sm:p-8 space-y-8">
              {/* QE Principal */}
              <div className={`${eqInfo.bg} border border-pink-200 rounded-xl p-6 sm:p-8 text-center`}>
                <div className="mb-4">
                  <div className={`text-5xl sm:text-6xl font-bold ${eqInfo.color} mb-2`}>{results.eq}</div>
                  <div className={`text-lg sm:text-xl font-semibold ${eqInfo.color} mb-3`}>{eqInfo.level}</div>
                  <Progress value={(results.rawScore / results.maxScore) * 100} className="mb-4" />
                  <div className="text-gray-600 text-sm sm:text-base">
                    Score : {results.rawScore}/{results.maxScore} ({Math.round(results.percentage)}%)
                  </div>
                </div>
                <p className={`${eqInfo.color} text-sm sm:text-base font-medium mb-4`}>{eqInfo.description}</p>
                <div className="bg-white/70 rounded-lg p-4">
                  <h4 className="font-semibold text-gray-800 mb-2">💡 Conseil personnalisé :</h4>
                  <p className="text-gray-700 text-sm">{eqInfo.advice}</p>
                </div>
              </div>

              {/* Analyse par catégorie */}
              <div>
                <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-6 text-center">Profil détaillé par compétence</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                  {Object.entries(results.categoryScores).map(([category, score]: [string, any]) => {
                    const percentage = Math.round((score.correct / score.total) * 100);
                    let colorClass = 'text-green-600 bg-green-50';
                    let statusIcon = '🟢';
                    if (percentage < 50) {
                      colorClass = 'text-red-600 bg-red-50';
                      statusIcon = '🔴';
                    } else if (percentage < 70) {
                      colorClass = 'text-orange-600 bg-orange-50';
                      statusIcon = '🟡';
                    } else if (percentage < 85) {
                      colorClass = 'text-blue-600 bg-blue-50';
                      statusIcon = '🔵';
                    }
                    
                    const getAdvice = (cat: string, perc: number) => {
                      if (cat === 'Conscience de soi') {
                        if (perc >= 80) return 'Excellente connaissance de vos émotions';
                        return 'Pratiquez l\'auto-observation et la méditation';
                      }
                      if (cat === 'Autorégulation') {
                        if (perc >= 80) return 'Maîtrise remarquable de vos émotions';
                        return 'Travaillez les techniques de respiration et de pause';
                      }
                      if (cat === 'Motivation') {
                        if (perc >= 80) return 'Drive et engagement exceptionnels';
                        return 'Clarifiez vos objectifs et valeurs personnelles';
                      }
                      if (cat === 'Empathie') {
                        if (perc >= 80) return 'Compréhension profonde des autres';
                        return 'Pratiquez l\'écoute active et l\'observation';
                      }
                      if (perc >= 80) return 'Leadership relationnel excellent';
                      return 'Développez votre communication et collaboration';
                    };
                    
                    return (
                      <Card key={category} className="border-gray-200 shadow-sm hover:shadow-md transition-shadow">
                        <CardContent className="p-4 sm:p-6">
                          <div className="text-center">
                            <div className="text-2xl mb-2">{statusIcon}</div>
                            <h4 className="font-semibold text-gray-900 mb-2 text-sm sm:text-base">{category}</h4>
                            <div className={`text-2xl sm:text-3xl font-bold mb-2 ${colorClass.split(' ')[0]}`}>
                              {percentage}%
                            </div>
                            <div className="text-gray-600 text-xs sm:text-sm mb-3">
                              {score.correct}/{score.total} bonnes réponses
                            </div>
                            <Progress value={percentage} className="mb-3" />
                            <p className="text-xs text-gray-600 italic">{getAdvice(category, percentage)}</p>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>

              {/* Guide de développement */}
              <div className="bg-gray-50 rounded-xl p-6 sm:p-8">
                <h3 className="text-lg sm:text-xl font-bold text-gray-900 mb-4">🚀 Guide de développement émotionnel</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-3">📈 Pour améliorer votre QE :</h4>
                    <ul className="space-y-2 text-gray-600 text-sm sm:text-base">
                      <li>• <strong>Méditation quotidienne</strong> - 10 min/jour minimum</li>
                      <li>• <strong>Journal émotionnel</strong> - Notez vos ressentis</li>
                      <li>• <strong>Feedback 360°</strong> - Demandez l'avis des autres</li>
                      <li>• <strong>Écoute active</strong> - Focalisez sur la compréhension</li>
                      <li>• <strong>Gestion du stress</strong> - Techniques de relaxation</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-3">💪 Exercices pratiques :</h4>
                    <ul className="space-y-2 text-gray-600 text-sm sm:text-base">
                      <li>• Pause de 10 secondes avant de réagir</li>
                      <li>• Identifier 3 émotions par jour</li>
                      <li>• Pratiquer la gratitude quotidienne</li>
                      <li>• Observer le langage corporel des autres</li>
                      <li>• Reformuler avant de répondre</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Interprétation globale */}
              <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-6 sm:p-8">
                <h3 className="text-lg sm:text-xl font-bold text-gray-900 mb-4">🎯 Votre profil émotionnel</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                  <div className="bg-white/70 rounded-lg p-4">
                    <div className="text-2xl mb-2">🧠</div>
                    <h4 className="font-semibold text-gray-800">Intelligence Personnelle</h4>
                    <p className="text-sm text-gray-600 mt-2">
                      {results.categoryScores['Conscience de soi'].correct + results.categoryScores['Autorégulation'].correct + results.categoryScores['Motivation'].correct} / 32
                    </p>
                  </div>
                  <div className="bg-white/70 rounded-lg p-4">
                    <div className="text-2xl mb-2">🤝</div>
                    <h4 className="font-semibold text-gray-800">Intelligence Sociale</h4>
                    <p className="text-sm text-gray-600 mt-2">
                      {results.categoryScores['Empathie'].correct + results.categoryScores['Compétences sociales'].correct} / 18
                    </p>
                  </div>
                  <div className="bg-white/70 rounded-lg p-4">
                    <div className="text-2xl mb-2">📊</div>
                    <h4 className="font-semibold text-gray-800">Score Global</h4>
                    <p className="text-sm text-gray-600 mt-2">
                      {Math.round(results.percentage)}% de maîtrise émotionnelle
                    </p>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  onClick={resetTest}
                  className="bg-gradient-to-r from-pink-500 to-pink-600 hover:from-pink-600 hover:to-pink-700 text-white shadow-lg px-6 py-3"
                >
                  <RotateCcw className="w-5 h-5 mr-2" />
                  Refaire le test
                </Button>
                <Button 
                  onClick={() => window.print()}
                  variant="outline"
                  className="border-gray-300 text-gray-700 hover:bg-gray-50 px-6 py-3"
                >
                  Imprimer les résultats
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Test en cours
  const question = eqQuestions[currentQuestion];
  const progress = ((currentQuestion + 1) / eqQuestions.length) * 100;

  return (
    <div className="min-h-screen pt-4 pb-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl border border-white/20 overflow-hidden">
          {/* Header avec progression */}
          <div className="bg-gradient-to-r from-pink-50 to-pink-100/50 p-4 sm:p-6 border-b border-gray-200/50">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center space-x-3">
                <Heart className="w-6 h-6 text-pink-600" />
                <div>
                  <h2 className="font-bold text-gray-900 text-sm sm:text-base">Test de QE</h2>
                  <p className="text-gray-600 text-xs sm:text-sm">{participantName}</p>
                </div>
              </div>
              <div className="flex items-center space-x-4 text-center">
                <div className="flex items-center space-x-2">
                  <Clock className="w-4 h-4 text-gray-500" />
                  <span className={`font-mono text-sm sm:text-base ${timeLeft < 300 ? 'text-red-600' : 'text-gray-700'}`}>
                    {formatTime(timeLeft)}
                  </span>
                </div>
                <div className="text-xs sm:text-sm text-gray-600">
                  {currentQuestion + 1}/{eqQuestions.length}
                </div>
              </div>
            </div>
            <div className="mt-4">
              <Progress value={progress} className="h-2" />
            </div>
          </div>

          {/* Question */}
          <div className="p-6 sm:p-8">
            <div className="mb-6">
              <div className="flex items-center justify-between mb-4">
                <Badge variant="outline" className="text-pink-600 border-pink-200">
                  {question.category}
                </Badge>
                <span className="text-sm text-gray-500">Question {currentQuestion + 1}</span>
              </div>
              <h3 className="text-lg sm:text-xl font-semibold text-gray-900 mb-6">
                {question.question}
              </h3>
            </div>

            {/* Options */}
            <div className="space-y-3 mb-8">
              {question.options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => selectAnswer(index)}
                  className={`w-full p-4 text-left rounded-xl border-2 transition-all duration-200 ${
                    selectedAnswers[currentQuestion] === index
                      ? 'border-pink-500 bg-pink-50 text-pink-900'
                      : 'border-gray-200 hover:border-pink-300 hover:bg-pink-50/50'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center text-xs font-bold ${
                      selectedAnswers[currentQuestion] === index
                        ? 'border-pink-500 bg-pink-500 text-white'
                        : 'border-gray-300'
                    }`}>
                      {String.fromCharCode(65 + index)}
                    </div>
                    <span className="text-sm sm:text-base">{option}</span>
                  </div>
                </button>
              ))}
            </div>

            {/* Navigation */}
            <div className="flex justify-between">
              <Button
                onClick={previousQuestion}
                disabled={currentQuestion === 0}
                variant="outline"
                className="border-gray-300 text-gray-700 disabled:opacity-50"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Précédent
              </Button>
              
              <Button
                onClick={nextQuestion}
                disabled={selectedAnswers[currentQuestion] === undefined}
                className="bg-gradient-to-r from-pink-500 to-pink-600 hover:from-pink-600 hover:to-pink-700 text-white disabled:opacity-50"
              >
                {currentQuestion === eqQuestions.length - 1 ? (
                  <>
                    <Target className="w-4 h-4 mr-2" />
                    Terminer
                  </>
                ) : (
                  <>
                    Suivant
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
import { useEffect } from 'react';

// Interface pour les métriques Web Vitals
interface WebVitalMetric {
  name: string;
  value: number;
  id: string;
  delta: number;
  rating: 'good' | 'needs-improvement' | 'poor';
}

export function WebVitals() {
  useEffect(() => {
    // Fonction pour envoyer les métriques à Google Analytics
    const sendToGoogleAnalytics = (metric: WebVitalMetric) => {
      if (typeof window !== 'undefined' && window.gtag) {
        window.gtag('event', metric.name, {
          event_category: 'Web Vitals',
          event_label: metric.rating,
          value: Math.round(metric.name === 'CLS' ? metric.value * 1000 : metric.value),
          non_interaction: true
        });
      }
    };

    // Fonction pour envoyer les métriques à votre propre analytics
    const sendToAnalytics = (metric: WebVitalMetric) => {
      // Envoi à Google Analytics
      sendToGoogleAnalytics(metric);
      
      // Optionnel: envoyer à votre propre endpoint d'analytics
      if (process.env.NODE_ENV === 'production') {
        fetch('/api/web-vitals', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            metric: metric.name,
            value: metric.value,
            rating: metric.rating,
            page: window.location.pathname,
            timestamp: new Date().toISOString(),
            userAgent: navigator.userAgent,
            connection: (navigator as any).connection?.effectiveType || 'unknown'
          })
        }).catch(error => {
          console.debug('Analytics error:', error);
        });
      }
    };

    // Note: web-vitals import désactivé pour éviter les erreurs de build
    // Si vous souhaitez activer les métriques web-vitals, installez le package séparément

    // Observer pour le Largest Contentful Paint manuel (fallback)
    if ('PerformanceObserver' in window) {
      try {
        const observer = new PerformanceObserver((list) => {
          for (const entry of list.getEntries()) {
            if (entry.entryType === 'largest-contentful-paint') {
              const lcpValue = entry.startTime;
              console.debug('LCP (manual):', lcpValue);
              
              // Catégorisation selon les seuils Google
              let rating: 'good' | 'needs-improvement' | 'poor';
              if (lcpValue <= 2500) rating = 'good';
              else if (lcpValue <= 4000) rating = 'needs-improvement';
              else rating = 'poor';
              
              if (window.gtag) {
                window.gtag('event', 'LCP_manual', {
                  event_category: 'Performance',
                  event_label: rating,
                  value: Math.round(lcpValue)
                });
              }
            }
          }
        });
        
        observer.observe({ entryTypes: ['largest-contentful-paint'] });
        
        // Nettoyage après 10 secondes
        setTimeout(() => observer.disconnect(), 10000);
        
      } catch (error) {
        console.debug('PerformanceObserver error:', error);
      }
    }

    // Mesure du Time to Interactive (TTI) manuel
    const measureTTI = () => {
      if (document.readyState === 'complete') {
        const navigationStart = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming;
        if (navigationStart) {
          const tti = navigationStart.loadEventEnd - navigationStart.fetchStart;
          
          let rating: 'good' | 'needs-improvement' | 'poor';
          if (tti <= 3800) rating = 'good';
          else if (tti <= 7300) rating = 'needs-improvement';  
          else rating = 'poor';

          if (window.gtag) {
            window.gtag('event', 'TTI', {
              event_category: 'Performance',
              event_label: rating,
              value: Math.round(tti)
            });
          }
        }
      }
    };

    // Mesurer TTI quand la page est complètement chargée
    if (document.readyState === 'complete') {
      measureTTI();
    } else {
      window.addEventListener('load', measureTTI);
    }

    // Mesure de la vitesse de navigation entre pages
    let navigationStartTime = performance.now();
    
    const measureNavigationSpeed = () => {
      const navigationTime = performance.now() - navigationStartTime;
      
      if (window.gtag && navigationTime > 100) { // Éviter les mesures trop courtes
        window.gtag('event', 'page_navigation_time', {
          event_category: 'Performance',
          value: Math.round(navigationTime),
          custom_parameter_1: window.location.pathname
        });
      }
      
      navigationStartTime = performance.now();
    };

    // Observer les changements de page pour SPA
    let lastUrl = window.location.href;
    new MutationObserver(() => {
      const url = window.location.href;
      if (url !== lastUrl) {
        lastUrl = url;
        measureNavigationSpeed();
      }
    }).observe(document, { subtree: true, childList: true });

    return () => {
      window.removeEventListener('load', measureTTI);
    };
  }, []);

  return null;
}

// Hook pour mesurer les performances personnalisées
export const usePerformanceMetrics = () => {
  const measureCustomMetric = (name: string, startTime: number) => {
    const duration = performance.now() - startTime;
    
    if (window.gtag) {
      window.gtag('event', `custom_${name}`, {
        event_category: 'Custom Performance',
        value: Math.round(duration),
        custom_parameter_1: window.location.pathname
      });
    }
    
    return duration;
  };

  const startMeasurement = (name: string) => {
    const startTime = performance.now();
    return () => measureCustomMetric(name, startTime);
  };

  const measureFormationLoad = (formationType: string) => {
    return startMeasurement(`formation_${formationType}_load`);
  };

  const measureQuizCompletion = (quizType: string) => {
    return startMeasurement(`quiz_${quizType}_completion`);
  };

  return {
    measureCustomMetric,
    startMeasurement,
    measureFormationLoad,
    measureQuizCompletion
  };
};
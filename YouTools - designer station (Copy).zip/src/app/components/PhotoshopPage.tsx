import { useState } from 'react';
import { Tabs, TabsContent } from './ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Search, Palette, Play } from 'lucide-react';
import { useAuthGuard } from './useAuth';

interface PhotoshopPageProps {
  currentSubPage?: string;
}

const photoshopShortcuts = [
  { keys: ['⌘', 'N'], description: 'Nouveau document' },
  { keys: ['⌘', 'O'], description: 'Ouvrir un fichier' },
  { keys: ['⌘', 'S'], description: 'Enregistrer' },
  { keys: ['⌘', '⇧', 'S'], description: 'Enregistrer sous' },
  { keys: ['⌘', 'Z'], description: 'Annuler' },
  { keys: ['⌘', '⇧', 'Z'], description: 'Rétablir' },
  { keys: ['⌘', 'C'], description: 'Copier' },
  { keys: ['⌘', 'V'], description: 'Coller' },
  { keys: ['⌘', 'X'], description: 'Couper' },
  { keys: ['⌘', 'A'], description: 'Tout sélectionner' },
  { keys: ['⌘', 'D'], description: 'Désélectionner' },
  { keys: ['⌘', '⇧', 'I'], description: 'Inverser la sélection' },
  { keys: ['⌘', 'T'], description: 'Transformation libre' },
  { keys: ['⌘', 'J'], description: 'Dupliquer le calque' },
  { keys: ['⌘', 'G'], description: 'Créer un groupe de calques' },
  { keys: ['⌘', '⇧', 'G'], description: 'Dissocier les calques' },
  { keys: ['⌘', 'E'], description: 'Fusionner avec le calque inférieur' },
  { keys: ['⌘', '⇧', 'E'], description: 'Fusionner les calques visibles' },
  { keys: ['V'], description: 'Outil Déplacement' },
  { keys: ['M'], description: 'Outil Rectangle de sélection' },
  { keys: ['L'], description: 'Outil Lasso' },
  { keys: ['W'], description: 'Outil Baguette magique' },
  { keys: ['C'], description: 'Outil Recadrage' },
  { keys: ['I'], description: 'Outil Pipette' },
  { keys: ['J'], description: 'Outil Correcteur localisé' },
  { keys: ['S'], description: 'Outil Tampon de duplication' },
  { keys: ['Y'], description: 'Outil Pinceau historique' },
  { keys: ['E'], description: 'Outil Gomme' },
  { keys: ['G'], description: 'Outil Dégradé' },
  { keys: ['O'], description: 'Outil Densité' },
  { keys: ['P'], description: 'Outil Plume' },
  { keys: ['T'], description: 'Outil Texte' },
  { keys: ['A'], description: 'Outil Sélection directe' },
  { keys: ['U'], description: 'Outil Rectangle' },
  { keys: ['N'], description: 'Outil Annotation' },
  { keys: ['H'], description: 'Outil Main' },
  { keys: ['Z'], description: 'Outil Zoom' },
  { keys: ['⌘', '+'], description: 'Zoom avant' },
  { keys: ['⌘', '-'], description: 'Zoom arrière' },
  { keys: ['⌘', '0'], description: 'Ajuster à la fenêtre' },
  { keys: ['⌘', '1'], description: 'Taille réelle (100%)' },
  { keys: ['⌘', 'R'], description: 'Afficher/Masquer les règles' },
  { keys: ['⌘', ';'], description: 'Afficher/Masquer les repères' },
  { keys: ['⌘', "'"], description: 'Afficher/Masquer la grille' },
  { keys: ['Tab'], description: 'Afficher/Masquer les panneaux' },
  { keys: ['F'], description: 'Modes d\'affichage' },
  { keys: ['⌘', '⌥', '0'], description: 'Zoom réel' },
  { keys: ['⌘', 'L'], description: 'Niveaux' },
  { keys: ['⌘', 'M'], description: 'Courbes' },
  { keys: ['⌘', 'U'], description: 'Teinte/Saturation' },
  { keys: ['⌘', 'B'], description: 'Balance des couleurs' },
  { keys: ['⌘', '⇧', 'U'], description: 'Désaturation' },
  { keys: ['⌘', 'I'], description: 'Négatif' },
  { keys: ['⌘', '⇧', 'A'], description: 'Réglage automatique des couleurs' },
  { keys: ['⌘', '⇧', 'L'], description: 'Réglage automatique des niveaux' },
  { keys: ['⌘', 'F'], description: 'Répéter le dernier filtre' },
  { keys: ['⌘', '⇧', 'F'], description: 'Estomper le dernier filtre' },
  { keys: ['⌘', '⇧', 'X'], description: 'Liquéfier' },
  // Raccourcis avancés calques
  { keys: ['⌘', '⌥', 'G'], description: 'Créer un masque d\'écrêtage' },
  { keys: ['⌘', '⌥', '⇧', 'G'], description: 'Libérer le masque d\'écrêtage' },
  { keys: ['⌘', '['], description: 'Reculer le calque' },
  { keys: ['⌘', ']'], description: 'Avancer le calque' },
  { keys: ['⌘', '⇧', '['], description: 'Placer en arrière' },
  { keys: ['⌘', '⇧', ']'], description: 'Placer au premier plan' },
  { keys: ['⌘', '⌥', 'A'], description: 'Sélectionner tous les calques' },
  { keys: ['⌘', '⇧', 'N'], description: 'Nouveau calque' },
  { keys: ['⌥', 'Clic'], description: 'Dupliquer le calque en déplaçant' },
  // Raccourcis sélection avancés
  { keys: ['⌘', '⌥', 'R'], description: 'Améliorer le contour' },
  { keys: ['⌘', '⇧', 'D'], description: 'Redéfinir la sélection' },
  { keys: ['Q'], description: 'Mode Masque rapide' },
  { keys: ['⌘', 'H'], description: 'Masquer les contours de sélection' },
  { keys: ['⌘', '⌥', 'D'], description: 'Contour progressif' },
  { keys: ['⌘', '⇧', 'I'], description: 'Intervertir la sélection' },
  // Raccourcis outils avancés
  { keys: ['⇧', 'B'], description: 'Parcourir les outils Pinceau' },
  { keys: ['⇧', 'E'], description: 'Parcourir les outils Gomme' },
  { keys: ['⇧', 'O'], description: 'Parcourir les outils Densité' },
  { keys: ['⇧', 'U'], description: 'Parcourir les outils Forme' },
  { keys: ['⇧', 'G'], description: 'Parcourir les outils Dégradé' },
  { keys: ['⇧', 'P'], description: 'Parcourir les outils Plume' },
  { keys: ['⇧', 'S'], description: 'Parcourir les outils Tampon' },
  { keys: ['⇧', 'J'], description: 'Parcourir les outils Correction' },
  { keys: ['⇧', 'Y'], description: 'Parcourir les outils Historique' },
  { keys: ['⇧', 'C'], description: 'Parcourir les outils Recadrage' },
  // Raccourcis masques et composites
  { keys: ['⌘', '\\'], description: 'Activer/Désactiver le masque de calque' },
  { keys: ['⌘', '⇧', '\\'], description: 'Afficher/Masquer le masque de calque' },
  { keys: ['⌘', '⌥', '\\'], description: 'Masque de calque en mode Ruby' },
  { keys: ['⌘', '⇧', 'K'], description: 'Préférences couleur' },
  { keys: ['⌘', 'K'], description: 'Préférences générales' },
  // Raccourcis transformation
  { keys: ['⌘', '⌥', 'T'], description: 'Répéter la transformation' },
  { keys: ['⌘', '⇧', 'T'], description: 'Répéter et dupliquer' },
  { keys: ['⌘', '⌥', '⇧', 'T'], description: 'Perspective libre' },
  { keys: ['⌘', '⇧', 'Alt', 'T'], description: 'Déformation de la marionnette' },
  // Raccourcis scripts et actions
  { keys: ['⌘', '⌥', 'F'], description: 'Redéfinir le filtre' },
  { keys: ['F9'], description: 'Afficher les Actions' },
  { keys: ['⌘', '⇧', 'F9'], description: 'Jouer l\'action' },
  { keys: ['⌘', 'F9'], description: 'Enregistrer l\'action' },
  // Raccourcis 3D et avancés
  { keys: ['⌘', '⇧', '⌥', 'N'], description: 'Nouveau calque 3D' },
  { keys: ['⌘', '⌥', '⇧', 'E'], description: 'Fusionner visible sur nouveau calque' },
  { keys: ['⌘', '⌥', 'Z'], description: 'Parcourir les états d\'historique' },
  { keys: ['⌘', '⇧', 'Z'], description: 'Avancer dans l\'historique' },
  // Raccourcis couleurs et réglages
  { keys: ['D'], description: 'Couleurs par défaut (noir/blanc)' },
  { keys: ['X'], description: 'Permuter premier plan/arrière-plan' },
  { keys: ['⌘', '⌥', '⇧', 'B'], description: 'Balance des couleurs automatique' },
  { keys: ['⌘', '⌥', '⇧', 'L'], description: 'Niveaux automatiques' },
  { keys: ['⌘', '⌥', '⇧', 'C'], description: 'Contraste automatique' },
  // Raccourcis Bridge et Camera Raw
  { keys: ['⌘', '⌥', 'O'], description: 'Ouvrir dans Bridge' },
  { keys: ['⌘', '⇧', 'O'], description: 'Ouvrir dans Camera Raw' },
  { keys: ['⌘', '⌥', '⇧', 'O'], description: 'Parcourir dans Bridge' }
];

const photoshopGlossary = [
  { term: 'Calque', definition: 'Élément transparent qui peut contenir des images, du texte ou des effets, empilé avec d\'autres calques pour créer une composition.' },
  { term: 'Masque de calque', definition: 'Technique qui permet de masquer ou révéler des parties d\'un calque sans les supprimer définitivement.' },
  { term: 'Mode de fusion', definition: 'Détermine comment les pixels d\'un calque se mélangent avec les pixels des calques inférieurs.' },
  { term: 'Résolution', definition: 'Nombre de pixels par pouce (DPI/PPI) qui détermine la qualité et la taille d\'impression d\'une image.' },
  { term: 'Opacité', definition: 'Degré de transparence d\'un calque, exprimé en pourcentage de 0% (transparent) à 100% (opaque).' },
  { term: 'Sélection', definition: 'Zone délimitée dans une image sur laquelle on peut appliquer des modifications.' },
  { term: 'Lasso', definition: 'Outil de sélection qui permet de tracer à main levée le contour d\'une zone à sélectionner.' },
  { term: 'Baguette magique', definition: 'Outil qui sélectionne automatiquement les pixels de couleur similaire dans une image.' },
  { term: 'Pipette', definition: 'Outil qui permet de prélever une couleur dans l\'image pour l\'utiliser comme couleur de premier plan.' },
  { term: 'Pinceau', definition: 'Outil de peinture qui applique de la couleur avec différentes formes et tailles de brosse.' },
  { term: 'Tampon de duplication', definition: 'Outil qui copie des pixels d\'une zone pour les appliquer dans une autre zone de l\'image.' },
  { term: 'Correcteur', definition: 'Outil qui corrige les imperfections en mélangeant les pixels environnants.' },
  { term: 'Gomme', definition: 'Outil qui efface les pixels d\'un calque, révélant le contenu des calques inférieurs.' },
  { term: 'Dégradé', definition: 'Transition progressive entre deux ou plusieurs couleurs.' },
  { term: 'Filtre', definition: 'Effet appliqué à une image ou un calque pour modifier son apparence.' },
  { term: 'Netteté', definition: 'Clarté et précision des détails dans une image.' },
  { term: 'Flou', definition: 'Effet qui réduit la netteté d\'une image ou d\'une zone spécifique.' },
  { term: 'Contraste', definition: 'Différence entre les zones claires et sombres d\'une image.' },
  { term: 'Luminosité', definition: 'Intensité de la lumière dans une image.' },
  { term: 'Saturation', definition: 'Intensité ou pureté des couleurs dans une image.' },
  { term: 'Teinte', definition: 'Couleur pure sans mélange avec du blanc, du noir ou du gris.' },
  { term: 'Courbes', definition: 'Outil de correction permettant d\'ajuster finement la luminosité et le contraste.' },
  { term: 'Niveaux', definition: 'Outil qui ajuste la gamme tonale d\'une image en modifiant les tons sombres, moyens et clairs.' },
  { term: 'Histogramme', definition: 'Graphique qui montre la distribution des pixels selon leur luminosité.' },
  { term: 'Balance des couleurs', definition: 'Ajustement des couleurs pour corriger les dominantes colorées.' },
  { term: 'RVB', definition: 'Mode colorimétrique basé sur les couleurs Rouge, Vert et Bleu, utilisé pour l\'affichage écran.' },
  { term: 'CMJN', definition: 'Mode colorimétrique Cyan, Magenta, Jaune, Noir utilisé pour l\'impression.' },
  { term: 'Profil colorimétrique', definition: 'Ensemble de données qui décrit les caractéristiques colorimétriques d\'un périphérique.' },
  { term: 'Échantillonnage', definition: 'Processus de modification de la résolution ou de la taille d\'une image.' },
  { term: 'Interpolation', definition: 'Méthode de calcul des nouveaux pixels lors du redimensionnement d\'une image.' },
  // Termes avancés de retouche
  { term: 'Masque de fusion', definition: 'Technique permettant de mélanger plusieurs images ou calques de manière graduelle.' },
  { term: 'Composite', definition: 'Image créée en combinant plusieurs éléments graphiques distincts.' },
  { term: 'Photomontage', definition: 'Technique consistant à assembler plusieurs photographies pour créer une image unique.' },
  { term: 'Détourage', definition: 'Action de séparer un objet de son arrière-plan en traçant son contour.' },
  { term: 'Incrustation', definition: 'Technique permettant d\'insérer une image dans une autre en remplaçant une couleur spécifique.' },
  // Termes techniques avancés
  { term: 'Tramage', definition: 'Technique de simulation de nuances par disposition de points de couleurs pures.' },
  { term: 'Anti-aliasing', definition: 'Technique de lissage des contours pour éviter l\'effet d\'escalier.' },
  { term: 'Mémoire virtuelle', definition: 'Espace disque utilisé comme extension de la mémoire vive pour les gros fichiers.' },
  { term: 'Métadonnées', definition: 'Informations techniques et descriptives intégrées dans un fichier image.' },
  { term: 'Calque de réglage', definition: 'Calque spécial qui applique des corrections sans modifier l\'image originale.' },
  // Termes de couleur avancés
  { term: 'Couches', definition: 'Composantes colorimétriques séparées d\'une image (Rouge, Vert, Bleu ou Cyan, Magenta, Jaune, Noir).' },
  { term: 'Couche alpha', definition: 'Couche supplémentaire contenant les informations de transparence.' },
  { term: 'Gamut', definition: 'Étendue des couleurs qu\'un périphérique peut reproduire.' },
  { term: 'Rendering Intent', definition: 'Méthode de conversion des couleurs lors du changement d\'espace colorimétrique.' },
  { term: 'Point blanc', definition: 'Référence de blanc utilisée pour l\'étalonnage et la gestion des couleurs.' },
  // Termes de filtres et effets
  { term: 'Convolution', definition: 'Opération mathématique utilisée par les filtres pour modifier les pixels.' },
  { term: 'Kernel', definition: 'Matrice de valeurs utilisée dans les filtres de convolution.' },
  { term: 'Bokeh', definition: 'Qualité esthétique du flou d\'arrière-plan dans une image.' },
  { term: 'Chromatic aberration', definition: 'Défaut optique créant des franges colorées sur les contours.' },
  { term: 'Vignettage', definition: 'Assombrissement progressif vers les bords de l\'image.' },
  // Termes de composition avancés
  { term: 'Règle des tiers', definition: 'Principe de composition divisant l\'image en neuf zones égales.' },
  { term: 'Point focal', definition: 'Élément principal sur lequel l\'œil se concentre dans une composition.' },
  { term: 'Équilibre des masses', definition: 'Répartition harmonieuse des éléments visuels dans l\'image.' },
  { term: 'Ligne de force', definition: 'Ligne directrice qui guide l\'œil à travers la composition.' },
  { term: 'Profondeur de champ', definition: 'Zone de netteté acceptable devant et derrière le sujet principal.' },
  // Termes de flux de travail
  { term: 'Workflow', definition: 'Processus organisé de traitement des images de la capture à la diffusion.' },
  { term: 'Batch processing', definition: 'Traitement automatisé d\'un lot d\'images avec les mêmes paramètres.' },
  { term: 'Action', definition: 'Séquence d\'opérations enregistrée pour automatiser des tâches répétitives.' },
  { term: 'Script', definition: 'Programme automatisé pour exécuter des tâches complexes dans Photoshop.' },
  { term: 'Droplet', definition: 'Application autonome créée à partir d\'une action pour traiter des fichiers par glisser-déposer.' },
  // Termes de formats et compression
  { term: 'Compression avec perte', definition: 'Méthode de compression qui réduit la taille en sacrifiant certaines données (JPEG).' },
  { term: 'Compression sans perte', definition: 'Méthode de compression qui préserve toutes les données originales (PNG, TIFF).' },
  { term: 'Format RAW', definition: 'Format de fichier contenant toutes les données brutes du capteur sans traitement.' },
  { term: 'EXIF', definition: 'Données techniques intégrées dans les fichiers photo (exposition, focale, date, etc.).' },
  { term: 'ICC Profile', definition: 'Profil standard décrivant les caractéristiques colorimétriques d\'un périphérique.' },
  // Termes de typographie
  { term: 'Kerning', definition: 'Ajustement de l\'espacement entre deux caractères spécifiques.' },
  { term: 'Tracking', definition: 'Ajustement uniforme de l\'espacement entre tous les caractères d\'un texte.' },
  { term: 'Leading', definition: 'Espacement vertical entre les lignes de texte.' },
  { term: 'Baseline', definition: 'Ligne de référence sur laquelle reposent les caractères.' },
  { term: 'Hinting', definition: 'Informations intégrées dans les polices pour optimiser leur affichage à petite taille.' }
];

export function PhotoshopPage({ currentSubPage = 'shortcuts' }: PhotoshopPageProps) {
  // Protection d'authentification
  useAuthGuard();

  const [searchTerm, setSearchTerm] = useState('');

  const filteredShortcuts = photoshopShortcuts.filter(shortcut =>
    shortcut.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    shortcut.keys.some(key => key.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const filteredGlossary = photoshopGlossary.filter(term =>
    term.term.toLowerCase().includes(searchTerm.toLowerCase()) ||
    term.definition.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen pt-4 pb-20">
      <div className="max-w-7xl mx-auto px-6">
        {/* Content Container */}
        <div className="bg-white/60 backdrop-blur-sm rounded-2xl shadow-2xl border border-white/20 overflow-hidden">
          <Tabs value={currentSubPage} className="w-full">
            {/* Shortcuts Tab */}
            <TabsContent value="shortcuts" className="p-8">
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {filteredShortcuts.map((shortcut, index) => (
                  <Card
                    key={index}
                    className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 animate-stagger-in"
                    style={{ animationDelay: `${index * 30}ms` }}
                  >
                    <CardContent className="p-5">
                      <div className="flex items-center space-x-2 mb-3">
                        {shortcut.keys.map((key, keyIndex) => (
                          <Badge 
                            key={keyIndex} 
                            variant="secondary" 
                            className="bg-orange-50 text-orange-700 border border-orange-200 text-sm px-3 py-1 font-medium"
                          >
                            {key}
                          </Badge>
                        ))}
                      </div>
                      <p className="text-gray-900 font-medium">{shortcut.description}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
              {filteredShortcuts.length === 0 && (
                <div className="text-center py-16">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Search className="w-8 h-8 text-gray-400" />
                  </div>
                  <p className="text-gray-500 text-lg">Aucun raccourci trouvé pour "{searchTerm}"</p>
                </div>
              )}
            </TabsContent>

            {/* Glossary Tab */}
            <TabsContent value="glossary" className="p-8">
              <div className="grid gap-6 md:grid-cols-2">
                {filteredGlossary.map((item, index) => (
                  <Card
                    key={index}
                    className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 animate-stagger-in"
                    style={{ animationDelay: `${index * 40}ms` }}
                  >
                    <CardHeader className="pb-4">
                      <CardTitle className="text-orange-600 text-xl font-semibold">{item.term}</CardTitle>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <p className="text-gray-900 leading-relaxed">{item.definition}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
              {filteredGlossary.length === 0 && (
                <div className="text-center py-16">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Search className="w-8 h-8 text-gray-400" />
                  </div>
                  <p className="text-gray-500 text-lg">Aucun terme trouvé pour "{searchTerm}"</p>
                </div>
              )}
            </TabsContent>

            {/* Videos Tab */}
            <TabsContent value="videos" className="p-8">
              <div className="space-y-8">

                  <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2">
                    {/* Tutoriel 1 - Vidéo réelle */}
                    <Card className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 lg:col-span-2 animate-stagger-in" style={{ animationDelay: '0ms' }}>
                      <CardContent className="p-6">
                        <div className="aspect-video rounded-lg mb-4 overflow-hidden shadow-lg">
                          <iframe
                            width="100%"
                            height="100%"
                            src="https://drive.google.com/file/d/1MfoDhKDd7z7yjMesbPTn11xIrV78nUXb/preview"
                            title="Tutoriel Photoshop - Formation Complète"
                            frameBorder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowFullScreen
                            className="rounded-lg"
                          ></iframe>
                        </div>
                        <div className="text-center max-w-4xl mx-auto">
                          <h3 className="font-semibold text-gray-900 mb-2 text-xl">Tutoriel 1 - Détourage de cheveux + détourage plume (Sans IA-Custom)</h3>
                          <p className="text-gray-900 text-sm mb-4">Maîtrisez les techniques de détourage avancé : cheveux complexes et détourage à la plume sans utiliser l'intelligence artificielle.</p>
                          <div className="flex items-center justify-center space-x-4">
                            <Badge variant="secondary" className="bg-green-50 text-green-700 border border-green-200">
                              Disponible maintenant
                            </Badge>
                            <span className="text-gray-500 text-xs flex items-center space-x-1">
                              <Play className="w-3 h-3" />
                              <span>Vidéo complète</span>
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Tutoriel 2 - Barre d'outil 1 */}
                    <Card className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 lg:col-span-2 animate-stagger-in" style={{ animationDelay: '100ms' }}>
                      <CardContent className="p-6">
                        <div className="aspect-video rounded-lg mb-4 overflow-hidden shadow-lg">
                          <iframe
                            width="100%"
                            height="100%"
                            src="https://drive.google.com/file/d/1zTK5vCp0qXEbM9QQEU0q6z2O_3_0R3Ke/preview"
                            title="Tutoriel 2 - Barre d'outil 1"
                            frameBorder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowFullScreen
                            className="rounded-lg"
                          ></iframe>
                        </div>
                        <div className="text-center max-w-4xl mx-auto">
                          <h3 className="font-semibold text-gray-900 mb-2 text-xl">Tutoriel 2 - Barre d'outil 1</h3>
                          <p className="text-gray-900 text-sm mb-4">Découvrez les outils essentiels de Photoshop et leur utilisation professionnelle.</p>
                          <div className="flex items-center justify-center space-x-4">
                            <Badge variant="secondary" className="bg-green-50 text-green-700 border border-green-200">
                              Disponible maintenant
                            </Badge>
                            <span className="text-gray-500 text-xs flex items-center space-x-1">
                              <Play className="w-3 h-3" />
                              <span>Vidéo complète</span>
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Tutoriel 3 - Creation de fichier */}
                    <Card className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 lg:col-span-2 animate-stagger-in" style={{ animationDelay: '200ms' }}>
                      <CardContent className="p-6">
                        <div className="aspect-video rounded-lg mb-4 overflow-hidden shadow-lg">
                          <iframe
                            width="100%"
                            height="100%"
                            src="https://drive.google.com/file/d/1iyQGL9V3I7QAg0yyl76mo0PEHHNtPzD6/preview"
                            title="Tutoriel 3 - Creation de fichier"
                            frameBorder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowFullScreen
                            className="rounded-lg"
                          ></iframe>
                        </div>
                        <div className="text-center max-w-4xl mx-auto">
                          <h3 className="font-semibold text-gray-900 mb-2 text-xl">Tutoriel 3 - Creation de fichier</h3>
                          <p className="text-gray-900 text-sm mb-4">Apprenez à créer et configurer correctement vos fichiers Photoshop pour différents usages.</p>
                          <div className="flex items-center justify-center space-x-4">
                            <Badge variant="secondary" className="bg-green-50 text-green-700 border border-green-200">
                              Disponible maintenant
                            </Badge>
                            <span className="text-gray-500 text-xs flex items-center space-x-1">
                              <Play className="w-3 h-3" />
                              <span>Vidéo complète</span>
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Tutoriel 4 - Calque et masque */}
                    <Card className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 lg:col-span-2 animate-stagger-in" style={{ animationDelay: '300ms' }}>
                      <CardContent className="p-6">
                        <div className="aspect-video rounded-lg mb-4 overflow-hidden shadow-lg">
                          <iframe
                            width="100%"
                            height="100%"
                            src="https://drive.google.com/file/d/138IcNhrzmstCf4J0jZ8JpASc8ShrOM6v/preview"
                            title="Tutoriel 4 - Calque et masque"
                            frameBorder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowFullScreen
                            className="rounded-lg"
                          ></iframe>
                        </div>
                        <div className="text-center max-w-4xl mx-auto">
                          <h3 className="font-semibold text-gray-900 mb-2 text-xl">Tutoriel 4 - Calque et masque</h3>
                          <p className="text-gray-900 text-sm mb-4">Maîtrisez la gestion des calques et l'utilisation des masques pour des compositions professionnelles.</p>
                          <div className="flex items-center justify-center space-x-4">
                            <Badge variant="secondary" className="bg-green-50 text-green-700 border border-green-200">
                              Disponible maintenant
                            </Badge>
                            <span className="text-gray-500 text-xs flex items-center space-x-1">
                              <Play className="w-3 h-3" />
                              <span>Vidéo complète</span>
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Tutoriel 5 - Barre d'outil 2 */}
                    <Card className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 lg:col-span-2 animate-stagger-in" style={{ animationDelay: '400ms' }}>
                      <CardContent className="p-6">
                        <div className="aspect-video rounded-lg mb-4 overflow-hidden shadow-lg">
                          <iframe
                            width="100%"
                            height="100%"
                            src="https://drive.google.com/file/d/1JtWu4fJMixUiKxoG61suomlA6_aiqVkc/preview"
                            title="Tutoriel 5 - Barre d'outil 2"
                            frameBorder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowFullScreen
                            className="rounded-lg"
                          ></iframe>
                        </div>
                        <div className="text-center max-w-4xl mx-auto">
                          <h3 className="font-semibold text-gray-900 mb-2 text-xl">Tutoriel 5 - Barre d'outil 2</h3>
                          <p className="text-gray-900 text-sm mb-4">Continuez votre apprentissage avec les outils avancés de la barre d'outils Photoshop.</p>
                          <div className="flex items-center justify-center space-x-4">
                            <Badge variant="secondary" className="bg-green-50 text-green-700 border border-green-200">
                              Disponible maintenant
                            </Badge>
                            <span className="text-gray-500 text-xs flex items-center space-x-1">
                              <Play className="w-3 h-3" />
                              <span>Vidéo complète</span>
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Tutoriel 6 - Retouche basique */}
                    <Card className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 lg:col-span-2 animate-stagger-in" style={{ animationDelay: '500ms' }}>
                      <CardContent className="p-6">
                        <div className="aspect-video rounded-lg mb-4 overflow-hidden shadow-lg">
                          <iframe
                            width="100%"
                            height="100%"
                            src="https://drive.google.com/file/d/1hApNH-enpftLfA-YLXWBWjAA77ypf2qg/preview"
                            title="Tutoriel 6 - Retouche basique"
                            frameBorder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowFullScreen
                            className="rounded-lg"
                          ></iframe>
                        </div>
                        <div className="text-center max-w-4xl mx-auto">
                          <h3 className="font-semibold text-gray-900 mb-2 text-xl">Tutoriel 6 - Retouche basique</h3>
                          <p className="text-gray-900 text-sm mb-4">Découvrez les techniques essentielles de retouche photo pour sublimer vos images.</p>
                          <div className="flex items-center justify-center space-x-4">
                            <Badge variant="secondary" className="bg-green-50 text-green-700 border border-green-200">
                              Disponible maintenant
                            </Badge>
                            <span className="text-gray-500 text-xs flex items-center space-x-1">
                              <Play className="w-3 h-3" />
                              <span>Vidéo complète</span>
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Tutoriel 7 - Nouvelle vidéo */}
                    <Card className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 lg:col-span-2 animate-stagger-in" style={{ animationDelay: '600ms' }}>
                      <CardContent className="p-6">
                        <div className="aspect-video rounded-lg mb-4 overflow-hidden shadow-lg">
                          <iframe
                            width="100%"
                            height="100%"
                            src="https://drive.google.com/file/d/16rFg3JIiej71UBNj0YdV2N3hkwjRdPl5/preview"
                            title="Tutoriel 7 - Retouche basique niveau 1 Photoshop"
                            frameBorder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowFullScreen
                            className="rounded-lg"
                          ></iframe>
                        </div>
                        <div className="text-center max-w-4xl mx-auto">
                          <h3 className="font-semibold text-gray-900 mb-2 text-xl">Tutoriel 7 - Retouche basique niveau 1 Photoshop</h3>
                          <p className="text-gray-900 text-sm mb-4">Initiez-vous aux techniques fondamentales de retouche photo avec ce tutoriel niveau 1.</p>
                          <div className="flex items-center justify-center space-x-4">
                            <Badge variant="secondary" className="bg-green-50 text-green-700 border border-green-200">
                              Disponible maintenant
                            </Badge>
                            <span className="text-gray-500 text-xs flex items-center space-x-1">
                              <Play className="w-3 h-3" />
                              <span>Vidéo complète</span>
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Tutoriel 8 - Nouvelle vidéo */}
                    <Card className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 lg:col-span-2 animate-stagger-in" style={{ animationDelay: '700ms' }}>
                      <CardContent className="p-6">
                        <div className="aspect-video rounded-lg mb-4 overflow-hidden shadow-lg">
                          <iframe
                            width="100%"
                            height="100%"
                            src="https://drive.google.com/file/d/1v_7DcccPDPNrFUV6Bd7ylseOgHHmPz4B/preview"
                            title="Tutoriel 8 - Retouche sur visage/basique suite"
                            frameBorder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowFullScreen
                            className="rounded-lg"
                          ></iframe>
                        </div>
                        <div className="text-center max-w-4xl mx-auto">
                          <h3 className="font-semibold text-gray-900 mb-2 text-xl">Tutoriel 8 - Retouche sur visage/basique suite</h3>
                          <p className="text-gray-900 text-sm mb-4">Poursuivez votre apprentissage des techniques de retouche visage avec ce tutoriel avancé.</p>
                          <div className="flex items-center justify-center space-x-4">
                            <Badge variant="secondary" className="bg-green-50 text-green-700 border border-green-200">
                              Disponible maintenant
                            </Badge>
                            <span className="text-gray-500 text-xs flex items-center space-x-1">
                              <Play className="w-3 h-3" />
                              <span>Vidéo complète</span>
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Tutoriel 9 - Techniques de Mockup */}
                    <Card className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 lg:col-span-2 animate-stagger-in" style={{ animationDelay: '800ms' }}>
                      <CardContent className="p-6">
                        <div className="aspect-video rounded-lg mb-4 overflow-hidden shadow-lg">
                          <iframe
                            width="100%"
                            height="100%"
                            src="https://drive.google.com/file/d/1LIJbyzfznEwuUStVfg76VlRAa13ksJ1i/preview"
                            title="Tutoriel 9 - Techniques de Mockup"
                            frameBorder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowFullScreen
                            className="rounded-lg"
                          ></iframe>
                        </div>
                        <div className="text-center max-w-4xl mx-auto">
                          <h3 className="font-semibold text-gray-900 mb-2 text-xl">Tutoriel 9 - Techniques de Mockup</h3>
                          <p className="text-gray-900 text-sm mb-4">Apprenez à créer des mockups professionnels pour présenter vos créations de manière réaliste et impactante.</p>
                          <div className="flex items-center justify-center space-x-4">
                            <Badge variant="secondary" className="bg-green-50 text-green-700 border border-green-200">
                              Disponible maintenant
                            </Badge>
                            <span className="text-gray-500 text-xs flex items-center space-x-1">
                              <Play className="w-3 h-3" />
                              <span>Vidéo complète</span>
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Tutoriel 10 - Fusion */}
                    <Card className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 lg:col-span-2 animate-stagger-in" style={{ animationDelay: '900ms' }}>
                      <CardContent className="p-6">
                        <div className="aspect-video rounded-lg mb-4 overflow-hidden shadow-lg">
                          <iframe
                            width="100%"
                            height="100%"
                            src="https://drive.google.com/file/d/1hxTY66bw47NkidXffRlAPI3LjdljrT--/preview"
                            title="Tutoriel 10 - Fusion"
                            frameBorder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowFullScreen
                            className="rounded-lg"
                          ></iframe>
                        </div>
                        <div className="text-center max-w-4xl mx-auto">
                          <h3 className="font-semibold text-gray-900 mb-2 text-xl">Tutoriel 10 - Fusion</h3>
                          <p className="text-gray-900 text-sm mb-4">Maîtrisez les techniques de fusion pour créer des compositions harmonieuses et des effets visuels avancés.</p>
                          <div className="flex items-center justify-center space-x-4">
                            <Badge variant="secondary" className="bg-green-50 text-green-700 border border-green-200">
                              Disponible maintenant
                            </Badge>
                            <span className="text-gray-500 text-xs flex items-center space-x-1">
                              <Play className="w-3 h-3" />
                              <span>Vidéo complète</span>
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Tutoriel 11 - Fusion & light */}
                    <Card className="bg-white border-gray-200 hover:shadow-lg hover:shadow-orange-500/5 transition-all duration-300 hover:border-orange-200 lg:col-span-2 animate-stagger-in" style={{ animationDelay: '1000ms' }}>
                      <CardContent className="p-6">
                        <div className="aspect-video rounded-lg mb-4 overflow-hidden shadow-lg">
                          <iframe
                            width="100%"
                            height="100%"
                            src="https://drive.google.com/file/d/1qJK6bnxqMmkH4uMBIC1EMhDSH1NMxQgj/preview"
                            title="Tutoriel 11 - Fusion & light"
                            frameBorder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowFullScreen
                            className="rounded-lg"
                          ></iframe>
                        </div>
                        <div className="text-center max-w-4xl mx-auto">
                          <h3 className="font-semibold text-gray-900 mb-2 text-xl">Tutoriel 11 - Fusion & light</h3>
                          <p className="text-gray-900 text-sm mb-4">Approfondissez vos compétences en fusion et découvrez comment jouer avec la lumière pour des rendus spectaculaires.</p>
                          <div className="flex items-center justify-center space-x-4">
                            <Badge variant="secondary" className="bg-green-50 text-green-700 border border-green-200">
                              Disponible maintenant
                            </Badge>
                            <span className="text-gray-500 text-xs flex items-center space-x-1">
                              <Play className="w-3 h-3" />
                              <span>Vidéo complète</span>
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
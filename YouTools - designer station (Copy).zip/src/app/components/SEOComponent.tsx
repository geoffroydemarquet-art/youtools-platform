import { useEffect } from 'react';

interface SEOProps {
  title?: string;
  description?: string;
  keywords?: string;
  canonical?: string;
  ogImage?: string;
  ogType?: string;
  twitterCard?: string;
  structuredData?: object;
  noIndex?: boolean;
}

export function SEOComponent({
  title = "Creative Tools - Formation Professionnelle Design Graphique | Photoshop, Illustrator, Midjourney",
  description = "Maîtrisez les outils créatifs avec Creative Tools : formations Photoshop, Illustrator, Midjourney + IA. Tests QI/QE, quiz d'évaluation et assistant IA. Plateforme 100% française.",
  keywords = "formation photoshop, cours illustrator, midjourney tutorial, design graphique, formation créative, photoshop mac, illustrator vectoriel, intelligence artificielle design, quiz créatif, test QI design, formation professionnelle, créativité digitale, outils Adobe, design thinking, portfolio design",
  canonical = "https://creative-tools.fr",
  ogImage = "https://creative-tools.fr/og-image.jpg",
  ogType = "website",
  twitterCard = "summary_large_image",
  structuredData,
  noIndex = false
}: SEOProps) {

  useEffect(() => {
    // Mise à jour du titre
    document.title = title;

    // Fonction pour créer ou mettre à jour une meta tag
    const updateMetaTag = (name: string, content: string, property?: boolean) => {
      const attribute = property ? 'property' : 'name';
      let meta = document.querySelector(`meta[${attribute}="${name}"]`) as HTMLMetaElement;
      
      if (!meta) {
        meta = document.createElement('meta');
        meta.setAttribute(attribute, name);
        document.head.appendChild(meta);
      }
      meta.content = content;
    };

    // Meta tags essentiels
    updateMetaTag('description', description);
    updateMetaTag('keywords', keywords);
    updateMetaTag('author', 'Creative Tools - Demarquet Formation');
    updateMetaTag('viewport', 'width=device-width, initial-scale=1.0, maximum-scale=5.0');
    updateMetaTag('theme-color', '#0d9488');
    updateMetaTag('msapplication-TileColor', '#0d9488');
    
    // Langue et région
    updateMetaTag('language', 'fr-FR');
    updateMetaTag('geo.region', 'FR');
    updateMetaTag('geo.country', 'France');
    
    // Open Graph Meta Tags
    updateMetaTag('og:title', title, true);
    updateMetaTag('og:description', description, true);
    updateMetaTag('og:type', ogType, true);
    updateMetaTag('og:url', canonical, true);
    updateMetaTag('og:image', ogImage, true);
    updateMetaTag('og:image:width', '1200', true);
    updateMetaTag('og:image:height', '630', true);
    updateMetaTag('og:site_name', 'Creative Tools', true);
    updateMetaTag('og:locale', 'fr_FR', true);
    
    // Twitter Card Meta Tags
    updateMetaTag('twitter:card', twitterCard);
    updateMetaTag('twitter:title', title);
    updateMetaTag('twitter:description', description);
    updateMetaTag('twitter:image', ogImage);
    updateMetaTag('twitter:site', '@CreativeToolsFR');
    updateMetaTag('twitter:creator', '@DemarquetTools');
    
    // Meta tags techniques
    updateMetaTag('robots', noIndex ? 'noindex, nofollow' : 'index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1');
    updateMetaTag('googlebot', 'index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1');
    updateMetaTag('bingbot', 'index, follow');
    
    // Canonical URL
    let canonicalLink = document.querySelector('link[rel="canonical"]') as HTMLLinkElement;
    if (!canonicalLink) {
      canonicalLink = document.createElement('link');
      canonicalLink.rel = 'canonical';
      document.head.appendChild(canonicalLink);
    }
    canonicalLink.href = canonical;

    // Données structurées JSON-LD
    if (structuredData) {
      let script = document.querySelector('script[type="application/ld+json"]');
      if (!script) {
        script = document.createElement('script');
        script.type = 'application/ld+json';
        document.head.appendChild(script);
      }
      script.textContent = JSON.stringify(structuredData);
    }

    // Preconnect pour optimiser les performances
    const preconnectDomains = [
      'https://fonts.googleapis.com',
      'https://fonts.gstatic.com',
      'https://cdn.pixabay.com',
      'https://www.google-analytics.com',
      'https://www.googletagmanager.com'
    ];

    preconnectDomains.forEach(domain => {
      let link = document.querySelector(`link[href="${domain}"]`) as HTMLLinkElement;
      if (!link) {
        link = document.createElement('link');
        link.rel = 'preconnect';
        link.href = domain;
        link.crossOrigin = 'anonymous';
        document.head.appendChild(link);
      }
    });

    // DNS Prefetch pour améliorer les performances
    const dnsPrefetchDomains = [
      '//www.google.com',
      '//www.facebook.com',
      '//platform.twitter.com',
      '//www.linkedin.com'
    ];

    dnsPrefetchDomains.forEach(domain => {
      let link = document.querySelector(`link[href="${domain}"]`) as HTMLLinkElement;
      if (!link) {
        link = document.createElement('link');
        link.rel = 'dns-prefetch';
        link.href = domain;
        document.head.appendChild(link);
      }
    });

  }, [title, description, keywords, canonical, ogImage, ogType, twitterCard, structuredData, noIndex]);

  return null;
}

// Données structurées pour la page d'accueil
export const homePageStructuredData = {
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "Organization",
      "@id": "https://creative-tools.fr/#organization",
      "name": "Creative Tools",
      "alternateName": "Demarquet Tools",
      "url": "https://creative-tools.fr",
      "logo": {
        "@type": "ImageObject",
        "url": "https://creative-tools.fr/logo.png",
        "width": 512,
        "height": 512
      },
      "description": "Plateforme de formation professionnelle en design graphique et outils créatifs numériques",
      "foundingDate": "2024",
      "founder": {
        "@type": "Person",
        "name": "Demarquet"
      },
      "areaServed": {
        "@type": "Country",
        "name": "France"
      },
      "serviceType": "Formation professionnelle",
      "knowsAbout": [
        "Adobe Photoshop",
        "Adobe Illustrator", 
        "Midjourney",
        "Intelligence Artificielle",
        "Design Graphique",
        "Créativité Numérique"
      ],
      "sameAs": [
        "https://www.linkedin.com/company/creative-tools-fr",
        "https://twitter.com/CreativeToolsFR",
        "https://www.facebook.com/CreativeToolsFrance"
      ]
    },
    {
      "@type": "WebSite",
      "@id": "https://creative-tools.fr/#website",
      "url": "https://creative-tools.fr",
      "name": "Creative Tools",
      "description": "Formation professionnelle en design graphique : Photoshop, Illustrator, Midjourney + IA",
      "inLanguage": "fr-FR",
      "publisher": {
        "@id": "https://creative-tools.fr/#organization"
      },
      "potentialAction": {
        "@type": "SearchAction",
        "target": {
          "@type": "EntryPoint",
          "urlTemplate": "https://creative-tools.fr/search?q={search_term_string}"
        },
        "query-input": "required name=search_term_string"
      }
    },
    {
      "@type": "Course",
      "@id": "https://creative-tools.fr/#course",
      "name": "Formation Complète Creative Tools",
      "description": "Formation professionnelle complète en design graphique couvrant Photoshop, Illustrator, Midjourney et l'IA créative",
      "provider": {
        "@id": "https://creative-tools.fr/#organization"
      },
      "courseMode": "online",
      "educationalLevel": "beginner to advanced",
      "inLanguage": "fr-FR",
      "teaches": [
        "Maîtrise d'Adobe Photoshop pour Mac",
        "Techniques avancées d'Adobe Illustrator",
        "Génération d'images avec Midjourney",
        "Intelligence artificielle appliquée au design",
        "Workflow de création professionnelle",
        "Évaluation des compétences créatives"
      ],
      "hasCourseInstance": [
        {
          "@type": "CourseInstance",
          "courseMode": "online",
          "courseWorkload": "P4W",
          "instructor": {
            "@type": "Person",
            "name": "Expert Demarquet Tools"
          }
        }
      ],
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": "4.8",
        "reviewCount": "127",
        "bestRating": "5",
        "worstRating": "1"
      }
    },
    {
      "@type": "BreadcrumbList",
      "@id": "https://creative-tools.fr/#breadcrumb",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Accueil",
          "item": "https://creative-tools.fr"
        },
        {
          "@type": "ListItem", 
          "position": 2,
          "name": "Formations",
          "item": "https://creative-tools.fr/formations"
        },
        {
          "@type": "ListItem",
          "position": 3,
          "name": "Outils Créatifs",
          "item": "https://creative-tools.fr/outils"
        }
      ]
    }
  ]
};

// Données structurées pour les pages de formation
export const coursePageStructuredData = (courseName: string, courseDescription: string, courseUrl: string) => ({
  "@context": "https://schema.org",
  "@type": "Course",
  "name": courseName,
  "description": courseDescription,
  "url": courseUrl,
  "provider": {
    "@type": "Organization",
    "name": "Creative Tools",
    "url": "https://creative-tools.fr"
  },
  "courseMode": "online",
  "educationalLevel": "beginner to advanced",
  "inLanguage": "fr-FR",
  "isAccessibleForFree": false,
  "hasCourseInstance": {
    "@type": "CourseInstance",
    "courseMode": "online",
    "courseWorkload": "P2W"
  },
  "teaches": courseDescription,
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "4.7",
    "reviewCount": "89",
    "bestRating": "5"
  }
});

// Générateur de FAQ structurées
export const generateFAQStructuredData = (faqs: Array<{question: string, answer: string}>) => ({
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": faqs.map(faq => ({
    "@type": "Question",
    "name": faq.question,
    "acceptedAnswer": {
      "@type": "Answer",
      "text": faq.answer
    }
  }))
});
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { CheckCircle, XCircle, Award, Lock, Trash2, Eye, HelpCircle, FormInput, ExternalLink } from 'lucide-react';
import { useAuthGuard } from './useAuth';
import { GoogleFormEvaluation } from './GoogleFormEvaluation';

interface Question {
  id: number;
  software: 'Photoshop' | 'Illustrator' | 'Midjourney';
  question: string;
  options: string[];
  correct: number;
}

const questions: Question[] = [
  // Photoshop Questions (33 questions)
  {
    id: 1,
    software: 'Photoshop',
    question: 'Quel raccourci Mac permet de créer un nouveau calque ?',
    options: ['⌘+Shift+N', '⌘+N', '⌘+L', '⌘+Shift+L'],
    correct: 0
  },
  {
    id: 2,
    software: 'Photoshop',
    question: 'Raccourci Mac pour dupliquer un calque ?',
    options: ['⌘+J', '⌘+D', '⌘+Shift+D', '⌘+Option+J'],
    correct: 0
  },
  {
    id: 3,
    software: 'Photoshop',
    question: 'Comment accéder à l\'outil Plume sur Mac ?',
    options: ['P', 'Shift+P', '⌘+P', 'Option+P'],
    correct: 0
  },
  {
    id: 4,
    software: 'Photoshop',
    question: 'Raccourci Mac pour transformer librement ?',
    options: ['⌘+T', '⌘+Shift+T', '⌘+Option+T', 'T'],
    correct: 0
  },
  {
    id: 5,
    software: 'Photoshop',
    question: 'Comment inverser une sélection sur Mac ?',
    options: ['⌘+Shift+I', '⌘+I', '⌘+Option+I', 'Shift+I'],
    correct: 0
  },
  {
    id: 6,
    software: 'Photoshop',
    question: 'Raccourci pour l\'outil Déplacement ?',
    options: ['V', 'M', 'A', 'S'],
    correct: 0
  },
  {
    id: 7,
    software: 'Photoshop',
    question: 'Comment créer un masque de calque ?',
    options: ['Clic sur l\'icône masque', '⌘+M', 'Layer > Mask', 'Toutes les réponses'],
    correct: 0
  },
  {
    id: 8,
    software: 'Photoshop',
    question: 'Raccourci pour la Pipette ?',
    options: ['I', 'P', 'E', 'Y'],
    correct: 0
  },
  {
    id: 9,
    software: 'Photoshop',
    question: 'Comment ajuster les niveaux ?',
    options: ['⌘+L', '⌘+M', '⌘+U', '⌘+B'],
    correct: 0
  },
  {
    id: 10,
    software: 'Photoshop',
    question: 'Raccourci pour les courbes ?',
    options: ['⌘+M', '⌘+L', '⌘+U', '⌘+I'],
    correct: 0
  },
  {
    id: 11,
    software: 'Photoshop',
    question: 'Comment fusionner vers le bas ?',
    options: ['⌘+E', '⌘+Shift+E', '⌘+M', '⌘+F'],
    correct: 0
  },
  {
    id: 12,
    software: 'Photoshop',
    question: 'Raccourci pour zoom 100% ?',
    options: ['⌘+1', '⌘+0', '⌘+Alt+0', 'Z'],
    correct: 0
  },
  {
    id: 13,
    software: 'Photoshop',
    question: 'Comment désélectionner ?',
    options: ['⌘+D', '⌘+Shift+D', '⌘+A', '⌘+I'],
    correct: 0
  },
  {
    id: 14,
    software: 'Photoshop',
    question: 'Raccourci pour l\'outil Texte ?',
    options: ['T', 'X', 'F', 'W'],
    correct: 0
  },
  {
    id: 15,
    software: 'Photoshop',
    question: 'Comment afficher/masquer les calques ?',
    options: ['F7', 'F8', 'F9', 'F10'],
    correct: 0
  },
  {
    id: 16,
    software: 'Photoshop',
    question: 'Raccourci pour l\'outil Gomme ?',
    options: ['E', 'G', 'R', 'X'],
    correct: 0
  },
  {
    id: 17,
    software: 'Photoshop',
    question: 'Comment créer une sélection elliptique ?',
    options: ['M puis maintenir Shift', 'L', 'W', 'U'],
    correct: 0
  },
  {
    id: 18,
    software: 'Photoshop',
    question: 'Raccourci pour teinte/saturation ?',
    options: ['⌘+U', '⌘+H', '⌘+S', '⌘+T'],
    correct: 0
  },
  {
    id: 19,
    software: 'Photoshop',
    question: 'Comment inverser les couleurs ?',
    options: ['⌘+I', '⌘+Shift+I', '⌘+Alt+I', 'I'],
    correct: 0
  },
  {
    id: 20,
    software: 'Photoshop',
    question: 'Raccourci pour l\'outil Correcteur ?',
    options: ['J', 'H', 'S', 'C'],
    correct: 0
  },
  {
    id: 21,
    software: 'Photoshop',
    question: 'Comment afficher la grille ?',
    options: ['⌘+\'', '⌘+;', '⌘+G', '⌘+R'],
    correct: 0
  },
  {
    id: 22,
    software: 'Photoshop',
    question: 'Raccourci pour l\'outil Main ?',
    options: ['H', 'M', 'V', 'G'],
    correct: 0
  },
  {
    id: 23,
    software: 'Photoshop',
    question: 'Comment créer un nouveau document ?',
    options: ['⌘+N', '⌘+Shift+N', '⌘+Alt+N', 'Ctrl+N'],
    correct: 0
  },
  {
    id: 24,
    software: 'Photoshop',
    question: 'Raccourci pour coller sur place ?',
    options: ['⌘+Shift+V', '⌘+V', '⌘+Alt+V', '⌘+F'],
    correct: 0
  },
  {
    id: 25,
    software: 'Photoshop',
    question: 'Comment afficher les règles ?',
    options: ['⌘+R', '⌘+Shift+R', '⌘+Alt+R', 'R'],
    correct: 0
  },
  {
    id: 26,
    software: 'Photoshop',
    question: 'Raccourci pour l\'outil Dégradé ?',
    options: ['G', 'D', 'F', 'L'],
    correct: 0
  },
  {
    id: 27,
    software: 'Photoshop',
    question: 'Comment basculer entre les modes d\'écran ?',
    options: ['F', 'Tab', 'Space', 'Shift'],
    correct: 0
  },
  {
    id: 28,
    software: 'Photoshop',
    question: 'Raccourci pour l\'outil Lasso ?',
    options: ['L', 'S', 'M', 'W'],
    correct: 0
  },
  {
    id: 29,
    software: 'Photoshop',
    question: 'Comment remplir avec la couleur d\'avant-plan ?',
    options: ['Alt+Backspace', '⌘+Backspace', 'Shift+Backspace', 'G'],
    correct: 0
  },
  {
    id: 30,
    software: 'Photoshop',
    question: 'Raccourci pour la balance des couleurs ?',
    options: ['⌘+B', '⌘+Shift+B', '⌘+Alt+B', 'B'],
    correct: 0
  },
  {
    id: 31,
    software: 'Photoshop',
    question: 'Comment masquer/afficher les repères ?',
    options: ['⌘+;', '⌘+R', '⌘+\'', '⌘+G'],
    correct: 0
  },
  {
    id: 32,
    software: 'Photoshop',
    question: 'Raccourci pour l\'outil Tampon ?',
    options: ['S', 'T', 'C', 'J'],
    correct: 0
  },
  {
    id: 33,
    software: 'Photoshop',
    question: 'Comment faire un zoom avant ?',
    options: ['⌘++', '⌘+-', 'Z', '⌘+Space'],
    correct: 0
  },

  // Illustrator Questions (33 questions)
  {
    id: 34,
    software: 'Illustrator',
    question: 'Raccourci Mac pour l\'outil Sélection directe ?',
    options: ['A', 'V', 'D', 'S'],
    correct: 0
  },
  {
    id: 35,
    software: 'Illustrator',
    question: 'Comment créer un groupe d\'objets sur Mac ?',
    options: ['⌘+G', '⌘+Shift+G', '⌘+Option+G', 'G'],
    correct: 0
  },
  {
    id: 36,
    software: 'Illustrator',
    question: 'Raccourci pour l\'outil Plume ?',
    options: ['P', 'N', 'B', 'L'],
    correct: 0
  },
  {
    id: 37,
    software: 'Illustrator',
    question: 'Comment dissocier un groupe ?',
    options: ['⌘+Shift+G', '⌘+G', '⌘+U', 'G'],
    correct: 0
  },
  {
    id: 38,
    software: 'Illustrator',
    question: 'Raccourci pour l\'outil Rectangle ?',
    options: ['M', 'R', 'L', 'U'],
    correct: 0
  },
  {
    id: 39,
    software: 'Illustrator',
    question: 'Comment verrouiller un objet ?',
    options: ['⌘+2', '⌘+L', '⌘+Lock', 'L'],
    correct: 0
  },
  {
    id: 40,
    software: 'Illustrator',
    question: 'Raccourci pour l\'outil Ellipse ?',
    options: ['L', 'E', 'O', 'C'],
    correct: 0
  },
  {
    id: 41,
    software: 'Illustrator',
    question: 'Comment créer un tracé composé ?',
    options: ['⌘+8', '⌘+J', '⌘+U', '⌘+P'],
    correct: 0
  },
  {
    id: 42,
    software: 'Illustrator',
    question: 'Raccourci pour l\'outil Texte ?',
    options: ['T', 'X', 'F', 'W'],
    correct: 0
  },
  {
    id: 43,
    software: 'Illustrator',
    question: 'Comment dupliquer un objet en le déplaçant ?',
    options: ['Alt+glisser', '⌘+glisser', 'Shift+glisser', '⌘+D'],
    correct: 0
  },
  {
    id: 44,
    software: 'Illustrator',
    question: 'Raccourci pour l\'outil Rotation ?',
    options: ['R', 'O', 'T', 'S'],
    correct: 0
  },
  {
    id: 45,
    software: 'Illustrator',
    question: 'Comment envoyer un objet à l\'arrière ?',
    options: ['⌘+Shift+[', '⌘+[', '⌘+]', '⌘+Shift+]'],
    correct: 0
  },
  {
    id: 46,
    software: 'Illustrator',
    question: 'Raccourci pour l\'outil Échelle ?',
    options: ['S', 'E', 'Z', 'X'],
    correct: 0
  },
  {
    id: 47,
    software: 'Illustrator',
    question: 'Comment créer un masque d\'écrêtage ?',
    options: ['⌘+7', '⌘+M', '⌘+K', '⌘+C'],
    correct: 0
  },
  {
    id: 48,
    software: 'Illustrator',
    question: 'Raccourci pour l\'outil Pipette ?',
    options: ['I', 'E', 'P', 'D'],
    correct: 0
  },
  {
    id: 49,
    software: 'Illustrator',
    question: 'Comment afficher le mode Aperçu ?',
    options: ['⌘+Y', 'Y', '⌘+P', 'P'],
    correct: 0
  },
  {
    id: 50,
    software: 'Illustrator',
    question: 'Raccourci pour l\'outil Pinceau ?',
    options: ['B', 'P', 'N', 'X'],
    correct: 0
  },
  {
    id: 51,
    software: 'Illustrator',
    question: 'Comment joindre des points d\'ancrage ?',
    options: ['⌘+J', '⌘+K', '⌘+L', 'J'],
    correct: 0
  },
  {
    id: 52,
    software: 'Illustrator',
    question: 'Raccourci pour l\'outil Crayon ?',
    options: ['N', 'P', 'B', 'C'],
    correct: 0
  },
  {
    id: 53,
    software: 'Illustrator',
    question: 'Comment dupliquer et transformer ?',
    options: ['⌘+D', '⌘+R', '⌘+T', '⌘+Shift+D'],
    correct: 0
  },
  {
    id: 54,
    software: 'Illustrator',
    question: 'Raccourci pour l\'outil Ciseaux ?',
    options: ['C', 'S', 'X', 'K'],
    correct: 0
  },
  {
    id: 55,
    software: 'Illustrator',
    question: 'Comment aligner au centre horizontalement ?',
    options: ['Align panel', '⌘+A', 'A', 'Center'],
    correct: 0
  },
  {
    id: 56,
    software: 'Illustrator',
    question: 'Raccourci pour l\'outil Dégradé ?',
    options: ['G', 'D', 'F', 'L'],
    correct: 0
  },
  {
    id: 57,
    software: 'Illustrator',
    question: 'Comment convertir un point d\'ancrage lisse ?',
    options: ['Alt+clic', 'Shift+clic', '⌘+clic', 'Double-clic'],
    correct: 0
  },
  {
    id: 58,
    software: 'Illustrator',
    question: 'Raccourci pour l\'outil Forme libre ?',
    options: ['Shift+M', 'F', 'L', 'X'],
    correct: 0
  },
  {
    id: 59,
    software: 'Illustrator',
    question: 'Comment déverrouiller tous les objets ?',
    options: ['⌘+Alt+2', '⌘+2', '⌘+Shift+2', 'Alt+2'],
    correct: 0
  },
  {
    id: 60,
    software: 'Illustrator',
    question: 'Raccourci pour afficher/masquer les repères ?',
    options: ['⌘+;', '⌘+R', '⌘+G', ';'],
    correct: 0
  },
  {
    id: 61,
    software: 'Illustrator',
    question: 'Comment créer des contours ?',
    options: ['Object > Path > Outline Stroke', '⌘+O', 'Stroke', 'O'],
    correct: 0
  },
  {
    id: 62,
    software: 'Illustrator',
    question: 'Raccourci pour zoom adapté à la fenêtre ?',
    options: ['⌘+0', '⌘+1', '⌘+F', 'Z'],
    correct: 0
  },
  {
    id: 63,
    software: 'Illustrator',
    question: 'Comment répartir l\'espacement horizontal ?',
    options: ['Align panel', '⌘+H', 'H', 'Space'],
    correct: 0
  },
  {
    id: 64,
    software: 'Illustrator',
    question: 'Raccourci pour l\'outil Main ?',
    options: ['H', 'M', 'Space', 'G'],
    correct: 0
  },
  {
    id: 65,
    software: 'Illustrator',
    question: 'Comment transformer à nouveau ?',
    options: ['⌘+D', '⌘+T', '⌘+R', 'D'],
    correct: 0
  },
  {
    id: 66,
    software: 'Illustrator',
    question: 'Raccourci pour masquer la sélection ?',
    options: ['⌘+H', 'H', '⌘+Shift+H', 'Hide'],
    correct: 0
  },

  // Midjourney Questions (34 questions)
  {
    id: 67,
    software: 'Midjourney',
    question: 'Quel paramètre contrôle le ratio d\'aspect ?',
    options: ['--ar', '--aspect', '--ratio', '--format'],
    correct: 0
  },
  {
    id: 68,
    software: 'Midjourney',
    question: 'Comment exclure un élément d\'une image ?',
    options: ['--no', '--exclude', '--remove', '--without'],
    correct: 0
  },
  {
    id: 69,
    software: 'Midjourney',
    question: 'Quel paramètre contrôle la variation créative ?',
    options: ['--chaos', '--creative', '--random', '--vary'],
    correct: 0
  },
  {
    id: 70,
    software: 'Midjourney',
    question: 'Comment spécifier la version de Midjourney ?',
    options: ['--v', '--version', '--model', '--ver'],
    correct: 0
  },
  {
    id: 71,
    software: 'Midjourney',
    question: 'Quel paramètre contrôle le niveau de stylisation ?',
    options: ['--stylize', '--style', '--artistic', '--creative'],
    correct: 0
  },
  {
    id: 72,
    software: 'Midjourney',
    question: 'Comment faire une variation d\'une image ?',
    options: ['Bouton V', 'Bouton R', 'Bouton U', '--vary'],
    correct: 0
  },
  {
    id: 73,
    software: 'Midjourney',
    question: 'Quel prompt donne un style photographique ?',
    options: ['photorealistic', 'realistic', 'photo', 'camera'],
    correct: 0
  },
  {
    id: 74,
    software: 'Midjourney',
    question: 'Comment augmenter la résolution d\'une image ?',
    options: ['Bouton U', 'Bouton R', '--hd', '--quality'],
    correct: 0
  },
  {
    id: 75,
    software: 'Midjourney',
    question: 'Quel paramètre pour un style raw ?',
    options: ['--style raw', '--raw', '--natural', '--basic'],
    correct: 0
  },
  {
    id: 76,
    software: 'Midjourney',
    question: 'Comment créer des variations subtiles ?',
    options: ['--chaos 10', '--chaos 50', '--chaos 100', '--subtle'],
    correct: 0
  },
  {
    id: 77,
    software: 'Midjourney',
    question: 'Quel prompt pour un éclairage dramatique ?',
    options: ['dramatic lighting', 'dark mood', 'contrast', 'shadow'],
    correct: 0
  },
  {
    id: 78,
    software: 'Midjourney',
    question: 'Comment faire un plan serré ?',
    options: ['close-up', 'macro', 'detail', 'tight'],
    correct: 0
  },
  {
    id: 79,
    software: 'Midjourney',
    question: 'Quel prompt pour la golden hour ?',
    options: ['golden hour', 'sunset', 'warm light', 'magic hour'],
    correct: 0
  },
  {
    id: 80,
    software: 'Midjourney',
    question: 'Comment spécifier un style anime ?',
    options: ['anime style', 'manga', 'japanese', 'cartoon'],
    correct: 0
  },
  {
    id: 81,
    software: 'Midjourney',
    question: 'Quel paramètre pour améliorer la qualité ?',
    options: ['--quality', '--hd', '--detailed', '--sharp'],
    correct: 0
  },
  {
    id: 82,
    software: 'Midjourney',
    question: 'Comment faire un portrait ?',
    options: ['portrait', 'headshot', 'face', 'person'],
    correct: 0
  },
  {
    id: 83,
    software: 'Midjourney',
    question: 'Quel prompt pour un style peinture à l\'huile ?',
    options: ['oil painting', 'painted', 'artistic', 'canvas'],
    correct: 0
  },
  {
    id: 84,
    software: 'Midjourney',
    question: 'Comment créer une image panoramique ?',
    options: ['--ar 16:9', '--ar 21:9', '--wide', '--panorama'],
    correct: 0
  },
  {
    id: 85,
    software: 'Midjourney',
    question: 'Quel prompt pour un effet HDR ?',
    options: ['HDR', 'high dynamic range', 'vivid', 'contrast'],
    correct: 0
  },
  {
    id: 86,
    software: 'Midjourney',
    question: 'Comment faire une image en noir et blanc ?',
    options: ['black and white', 'monochrome', 'grayscale', '--no color'],
    correct: 0
  },
  {
    id: 87,
    software: 'Midjourney',
    question: 'Quel prompt pour un style cyberpunk ?',
    options: ['cyberpunk', 'neon', 'futuristic', 'sci-fi'],
    correct: 0
  },
  {
    id: 88,
    software: 'Midjourney',
    question: 'Comment créer un effet de profondeur de champ ?',
    options: ['shallow depth of field', 'bokeh', 'blur', 'focus'],
    correct: 0
  },
  {
    id: 89,
    software: 'Midjourney',
    question: 'Quel prompt pour un style vintage ?',
    options: ['vintage', 'retro', 'old', 'classic'],
    correct: 0
  },
  {
    id: 90,
    software: 'Midjourney',
    question: 'Comment spécifier une vue d\'oiseau ?',
    options: ['bird\'s eye view', 'aerial', 'top view', 'overhead'],
    correct: 0
  },
  {
    id: 91,
    software: 'Midjourney',
    question: 'Quel prompt pour des couleurs vibrantes ?',
    options: ['vibrant colors', 'saturated', 'bright', 'colorful'],
    correct: 0
  },
  {
    id: 92,
    software: 'Midjourney',
    question: 'Comment créer un style minimaliste ?',
    options: ['minimalist', 'simple', 'clean', 'minimal'],
    correct: 0
  },
  {
    id: 93,
    software: 'Midjourney',
    question: 'Quel prompt pour un effet aquarelle ?',
    options: ['watercolor', 'painted', 'soft', 'flowing'],
    correct: 0
  },
  {
    id: 94,
    software: 'Midjourney',
    question: 'Comment faire un gros plan extrême ?',
    options: ['extreme close-up', 'macro', 'detail shot', 'tight crop'],
    correct: 0
  },
  {
    id: 95,
    software: 'Midjourney',
    question: 'Quel prompt pour un éclairage néon ?',
    options: ['neon lighting', 'neon', 'electric', 'glowing'],
    correct: 0
  },
  {
    id: 96,
    software: 'Midjourney',
    question: 'Comment créer un effet de mouvement ?',
    options: ['motion blur', 'dynamic', 'action', 'movement'],
    correct: 0
  },
  {
    id: 97,
    software: 'Midjourney',
    question: 'Quel prompt pour un style surréaliste ?',
    options: ['surreal', 'dreamlike', 'fantasy', 'impossible'],
    correct: 0
  },
  {
    id: 98,
    software: 'Midjourney',
    question: 'Comment spécifier une texture ?',
    options: ['texture, detailed', 'rough', 'smooth', 'material'],
    correct: 0
  },
  {
    id: 99,
    software: 'Midjourney',
    question: 'Quel prompt pour un style art déco ?',
    options: ['art deco', 'geometric', '1920s', 'decorative'],
    correct: 0
  },
  {
    id: 100,
    software: 'Midjourney',
    question: 'Comment créer une composition symétrique ?',
    options: ['symmetrical', 'balanced', 'centered', 'mirror'],
    correct: 0
  }
];

interface QuizPageProps {
  initialPage?: string;
}

export function QuizPage({ initialPage }: QuizPageProps) {
  // Protection d'authentification
  useAuthGuard();
  
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [password, setPassword] = useState('');
  const [passwordVerified, setPasswordVerified] = useState(false);
  const [participantName, setParticipantName] = useState('');
  const [quizStarted, setQuizStarted] = useState(false);
  const [showResultsAccess, setShowResultsAccess] = useState(initialPage === 'quiz-results');
  const [savedResults, setSavedResults] = useState<any[]>([]);
  const [showFeedback, setShowFeedback] = useState(false);
  const [canProceed, setCanProceed] = useState(false);
  const [showGoogleForm, setShowGoogleForm] = useState(false);

  useEffect(() => {
    loadResults();
  }, []);

  useEffect(() => {
    if (initialPage === 'quiz-results') {
      setShowResultsAccess(true);
    }
  }, [initialPage]);

  // Gérer l'état de feedback lors du changement de question
  useEffect(() => {
    const hasAnswered = selectedAnswers[currentQuestion] !== undefined;
    if (hasAnswered && quizStarted && !showResults) {
      setShowFeedback(true);
      setCanProceed(true);
    } else if (quizStarted && !showResults) {
      setShowFeedback(false);
      setCanProceed(false);
    }
  }, [currentQuestion, selectedAnswers, quizStarted, showResults]);

  const startQuiz = () => {
    if (participantName.trim()) {
      setQuizStarted(true);
      // Réinitialiser tous les états du quiz
      setCurrentQuestion(0);
      setSelectedAnswers([]);
      setShowFeedback(false);
      setCanProceed(false);
      setShowResults(false);
    }
  };

  const selectAnswer = (answerIndex: number) => {
    // Empêcher de changer la réponse si le feedback est déjà affiché
    if (showFeedback) return;
    
    const newAnswers = [...selectedAnswers];
    newAnswers[currentQuestion] = answerIndex;
    setSelectedAnswers(newAnswers);
    
    // Activer le feedback visuel immédiatement
    setShowFeedback(true);
    
    // Permettre de continuer après 1.5 secondes pour laisser le temps de voir le feedback
    setTimeout(() => {
      setCanProceed(true);
    }, 1500);
  };

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      // Réinitialiser les états de feedback pour la nouvelle question
      setShowFeedback(false);
      setCanProceed(false);
    } else {
      finishQuiz();
    }
  };

  const previousQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
      // Réinitialiser les états de feedback pour la question précédente
      // Si l'utilisateur a déjà répondu, afficher le feedback immédiatement
      const hasAnswered = selectedAnswers[currentQuestion - 1] !== undefined;
      setShowFeedback(hasAnswered);
      setCanProceed(hasAnswered);
    }
  };

  const finishQuiz = () => {
    setShowResults(true);
  };

  const calculateResults = () => {
    let totalScore = 0;
    const categoryScores = {
      Photoshop: { correct: 0, total: 0 },
      Illustrator: { correct: 0, total: 0 },
      Midjourney: { correct: 0, total: 0 }
    };

    questions.forEach((question, index) => {
      categoryScores[question.software].total++;
      if (selectedAnswers[index] === question.correct) {
        totalScore++;
        categoryScores[question.software].correct++;
      }
    });

    const percentage = Math.round((totalScore / questions.length) * 100);
    return { totalScore, percentage, categoryScores };
  };

  const saveResults = () => {
    const results = calculateResults();
    const newResult = {
      name: participantName,
      date: new Date().toLocaleDateString('fr-FR'),
      time: new Date().toLocaleTimeString('fr-FR'),
      ...results
    };
    
    const existingResults = JSON.parse(localStorage.getItem('quizResults') || '[]');
    existingResults.push(newResult);
    localStorage.setItem('quizResults', JSON.stringify(existingResults));
    setSavedResults(existingResults);
  };

  const loadResults = () => {
    const results = JSON.parse(localStorage.getItem('quizResults') || '[]');
    setSavedResults(results);
  };

  const clearResults = () => {
    localStorage.removeItem('quizResults');
    setSavedResults([]);
  };

  const verifyPassword = () => {
    if (password === 'yoyo') {
      setPasswordVerified(true);
      if (showResultsAccess) {
        loadResults();
      }
    } else {
      alert('Mot de passe incorrect');
      setPassword('');
    }
  };

  useEffect(() => {
    if (showResults && participantName && !showResultsAccess) {
      saveResults();
    }
  }, [showResults]);

  // Page d'accès aux résultats (non authentifiée)
  if (showResultsAccess && !passwordVerified) {
    return (
      <div className="min-h-screen pt-4 pb-20">
        <div className="max-w-4xl mx-auto px-6">
          <div className="bg-white/60 backdrop-blur-md rounded-2xl shadow-2xl border border-white/20 overflow-hidden">
            <div className="text-center py-12 px-8 bg-gradient-to-b from-white/30 to-orange-50/30">
              <div className="w-16 h-16 bg-gradient-to-br from-orange-100 to-orange-200 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                <Lock className="w-8 h-8 text-orange-600" />
              </div>
              <h1 className="text-3xl font-bold text-gray-900 mb-4">Accès aux Résultats</h1>
              <p className="text-gray-600 text-lg">
                Entrez le mot de passe pour consulter tous les résultats enregistrés
              </p>
            </div>
            
            <div className="p-8 space-y-6">
              <div className="space-y-4 max-w-md mx-auto">
                <Input
                  type="password"
                  placeholder="Mot de passe"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="text-center bg-white/80 backdrop-blur-sm border-gray-200 text-gray-900 placeholder-gray-500 focus:border-orange-500 focus:ring-orange-500/20 rounded-xl shadow-sm"
                  onKeyPress={(e) => e.key === 'Enter' && verifyPassword()}
                />
                <div className="flex space-x-3">
                  <Button 
                    onClick={verifyPassword} 
                    className="flex-1 bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white shadow-lg"
                    disabled={!password.trim()}
                  >
                    <Eye className="w-4 h-4 mr-2" />
                    Consulter les résultats
                  </Button>
                  <Button 
                    onClick={() => {
                      setShowResultsAccess(false);
                      setPassword('');
                    }} 
                    variant="outline" 
                    className="border-gray-200 text-gray-600 hover:bg-gray-50"
                  >
                    Retour au Quiz
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Page de démarrage du quiz
  if (!quizStarted) {
    // Afficher le Google Form si sélectionné
    if (showGoogleForm) {
      return <GoogleFormEvaluation onBack={() => setShowGoogleForm(false)} />;
    }
    
    return (
      <div className="min-h-screen pt-4 pb-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <div className="bg-white/60 backdrop-blur-md rounded-2xl shadow-2xl border border-white/20 overflow-hidden">
            <div className="text-center py-8 sm:py-12 px-6 sm:px-8 bg-gradient-to-b from-white/30 to-orange-50/30">
              <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-br from-orange-100 to-orange-200 rounded-2xl flex items-center justify-center mx-auto mb-4 sm:mb-6 shadow-lg">
                <Award className="w-6 h-6 sm:w-8 sm:h-8 text-orange-600" />
              </div>
              <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-3 sm:mb-4">Centre d'Évaluation Creative Tools</h1>
              <p className="text-gray-600 text-base sm:text-lg mb-4 sm:mb-6">
                Choisissez votre type d'évaluation pour découvrir vos compétences
              </p>
            </div>
            
            <div className="p-6 sm:p-8">
              {/* Sélection des tests */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                {/* Quiz Creative Tools */}
                <Card className="border-orange-200 hover:border-orange-300 transition-colors cursor-pointer group hover:shadow-lg">
                  <CardContent className="p-6 text-center">
                    <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:bg-orange-200 transition-colors">
                      <Award className="w-6 h-6 text-orange-600" />
                    </div>
                    <h3 className="text-lg font-bold text-gray-900 mb-3">Quiz Creative Tools</h3>
                    <p className="text-gray-600 text-sm mb-4">
                      Testez vos connaissances sur Photoshop, Illustrator et Midjourney
                    </p>
                    <div className="bg-orange-50 p-3 rounded-lg mb-4">
                      <p className="text-orange-700 text-xs font-medium">
                        📝 100 questions<br/>
                        ⏱️ Pas de limite<br/>
                        🏆 Par logiciel
                      </p>
                    </div>
                    <div className="space-y-3">
                      <Input
                        type="text"
                        placeholder="Votre nom complet"
                        value={participantName}
                        onChange={(e) => setParticipantName(e.target.value)}
                        className="text-center bg-white/80 backdrop-blur-sm border-gray-200 focus:border-orange-500 focus:ring-orange-500/20 rounded-lg text-sm"
                      />
                      <Button 
                        onClick={startQuiz} 
                        disabled={!participantName.trim()}
                        className="w-full bg-orange-600 hover:bg-orange-700 text-white disabled:opacity-50 text-sm py-2"
                      >
                        Commencer
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Évaluation Google Form */}
                <Card className="border-orange-200 hover:border-orange-300 transition-colors cursor-pointer group hover:shadow-lg">
                  <CardContent className="p-6 text-center">
                    <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:bg-orange-200 transition-colors">
                      <FormInput className="w-6 h-6 text-orange-600" />
                    </div>
                    <h3 className="text-lg font-bold text-gray-900 mb-3">Évaluation Personnalisée</h3>
                    <p className="text-gray-600 text-sm mb-4">
                      Formulaire d'évaluation approfondie avec analyse détaillée
                    </p>
                    <div className="bg-orange-50 p-3 rounded-lg mb-4">
                      <p className="text-orange-700 text-xs font-medium">
                        📋 Évaluation complète<br/>
                        ⏱️ 20-30 minutes<br/>
                        📊 Analyse détaillée
                      </p>
                    </div>
                    <Button 
                      onClick={() => setShowGoogleForm(true)}
                      className="w-full bg-orange-600 hover:bg-orange-700 text-white text-sm py-2"
                    >
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Commencer l'Évaluation
                    </Button>
                  </CardContent>
                </Card>

                {/* Test QI */}
                <Card className="border-purple-200 hover:border-purple-300 transition-colors cursor-pointer group hover:shadow-lg">
                  <CardContent className="p-6 text-center">
                    <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:bg-purple-200 transition-colors">
                      <HelpCircle className="w-6 h-6 text-purple-600" />
                    </div>
                    <h3 className="text-lg font-bold text-gray-900 mb-3">Test de QI</h3>
                    <p className="text-gray-600 text-sm mb-4">
                      Évaluez votre quotient intellectuel et vos capacités de raisonnement
                    </p>
                    <div className="bg-purple-50 p-3 rounded-lg mb-4">
                      <p className="text-purple-700 text-xs font-medium">
                        🧠 50 questions<br/>
                        ⏱️ 60 minutes<br/>
                        📊 5 domaines
                      </p>
                    </div>
                    <Button 
                      onClick={() => window.location.href = '#'} 
                      className="w-full bg-purple-600 hover:bg-purple-700 text-white text-sm py-2"
                      onClickCapture={(e) => {
                        e.preventDefault();
                        // Navigation vers IQ test
                        window.dispatchEvent(new CustomEvent('navigate-to-iq-test'));
                      }}
                    >
                      Passer le Test QI
                    </Button>
                  </CardContent>
                </Card>

                {/* Test QE */}
                <Card className="border-pink-200 hover:border-pink-300 transition-colors cursor-pointer group hover:shadow-lg">
                  <CardContent className="p-6 text-center">
                    <div className="w-12 h-12 bg-pink-100 rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:bg-pink-200 transition-colors">
                      <HelpCircle className="w-6 h-6 text-pink-600" />
                    </div>
                    <h3 className="text-lg font-bold text-gray-900 mb-3">Test de QE</h3>
                    <p className="text-gray-600 text-sm mb-4">
                      Évaluez votre intelligence émotionnelle et vos compétences sociales
                    </p>
                    <div className="bg-pink-50 p-3 rounded-lg mb-4">
                      <p className="text-pink-700 text-xs font-medium">
                        💕 50 questions<br/>
                        ⏱️ 45 minutes<br/>
                        🎯 5 compétences
                      </p>
                    </div>
                    <Button 
                      onClick={() => window.location.href = '#'} 
                      className="w-full bg-pink-600 hover:bg-pink-700 text-white text-sm py-2"
                      onClickCapture={(e) => {
                        e.preventDefault();
                        // Navigation vers EQ test
                        window.dispatchEvent(new CustomEvent('navigate-to-eq-test'));
                      }}
                    >
                      Passer le Test QE
                    </Button>
                  </CardContent>
                </Card>
              </div>

              {/* Section admin */}
              <div className="border-t border-gray-200 pt-6">
                <div className="text-center">
                  <Button 
                    onClick={() => setShowResultsAccess(true)} 
                    variant="outline" 
                    className="border-gray-300 text-gray-600 hover:bg-gray-50 px-6 py-2"
                  >
                    <Eye className="w-4 h-4 mr-2" />
                    Voir tous les résultats (Admin)
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Page de résultats
  if (showResults) {
    const results = calculateResults();
    
    // Affichage des résultats admin si connecté
    if (showResultsAccess && passwordVerified) {
      return (
        <div className="min-h-screen pt-4 pb-20">
          <div className="max-w-6xl mx-auto px-6">
            <div className="bg-white/60 backdrop-blur-md rounded-2xl shadow-2xl border border-white/20 overflow-hidden">
              {/* Header */}
              <div className="bg-gradient-to-r from-orange-50/50 to-orange-100/50 p-6 border-b border-gray-200/50">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-orange-100 to-orange-200 rounded-xl flex items-center justify-center shadow-lg">
                      <Award className="w-6 h-6 text-orange-600" />
                    </div>
                    <div>
                      <h1 className="text-2xl font-bold text-gray-900">Tous les Résultats</h1>
                      <p className="text-gray-600">Gestion des résultats d'évaluation</p>
                    </div>
                  </div>
                  <div className="flex space-x-3">
                    <Button 
                      onClick={clearResults} 
                      variant="outline" 
                      size="sm"
                      className="border-red-200 text-red-600 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Effacer tout
                    </Button>
                    <Button 
                      onClick={() => {
                        setShowResultsAccess(false);
                        setPasswordVerified(false);
                        setPassword('');
                      }} 
                      variant="outline" 
                      size="sm" 
                      className="border-gray-200 text-gray-600 hover:bg-gray-50"
                    >
                      Fermer
                    </Button>
                  </div>
                </div>
              </div>

              {/* Content */}
              <div className="p-8">
                {savedResults.length === 0 ? (
                  <div className="text-center py-16">
                    <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                      <HelpCircle className="w-10 h-10 text-gray-400" />
                    </div>
                    <h3 className="text-xl font-semibold text-gray-700 mb-2">Aucun résultat enregistré</h3>
                    <p className="text-gray-500">Les résultats des quiz apparaîtront ici une fois terminés</p>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="text-center bg-orange-50 p-4 rounded-xl border border-orange-200">
                      <p className="text-orange-700 font-medium">
                        {savedResults.length} participant{savedResults.length > 1 ? 's' : ''} enregistré{savedResults.length > 1 ? 's' : ''}
                      </p>
                    </div>
                    
                    <div className="space-y-6">
                      {savedResults.map((result, index) => (
                        <Card key={index} className="bg-white/80 backdrop-blur-sm border-gray-200 border-l-4 border-l-orange-500 shadow-lg hover:shadow-xl transition-shadow">
                          <CardContent className="p-6">
                            <div className="flex items-center justify-between mb-6">
                              <div>
                                <h4 className="text-xl font-bold text-gray-900 mb-1">{result.name}</h4>
                                <p className="text-gray-500">{result.date} à {result.time}</p>
                              </div>
                              <div className="text-right">
                                <div className="text-4xl font-bold text-orange-600 mb-1">{result.percentage}%</div>
                                <div className="text-gray-600">{result.totalScore}/100 bonnes réponses</div>
                              </div>
                            </div>
                            
                            <div className="grid grid-cols-3 gap-6">
                              {Object.entries(result.categoryScores).map(([software, score]: [string, any]) => {
                                const softwarePercentage = Math.round((score.correct / score.total) * 100);
                                let colorClass = 'text-green-600';
                                let bgClass = 'bg-green-500';
                                let lightBgClass = 'bg-green-50';
                                
                                if (softwarePercentage < 50) {
                                  colorClass = 'text-red-600';
                                  bgClass = 'bg-red-500';
                                  lightBgClass = 'bg-red-50';
                                } else if (softwarePercentage < 70) {
                                  colorClass = 'text-orange-600';
                                  bgClass = 'bg-orange-500';
                                  lightBgClass = 'bg-orange-50';
                                }
                                
                                return (
                                  <div key={software} className={`text-center p-4 rounded-xl ${lightBgClass} border border-gray-200`}>
                                    <div className="font-medium text-gray-700 mb-2">{software}</div>
                                    <div className={`text-2xl font-bold ${colorClass}`}>{softwarePercentage}%</div>
                                    <div className="text-sm text-gray-500 mb-3">{score.correct}/{score.total}</div>
                                    <div className="w-full bg-gray-200 rounded-full h-2">
                                      <div 
                                        className={`h-2 rounded-full ${bgClass}`}
                                        style={{ width: `${softwarePercentage}%` }}
                                      ></div>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      );
    }

    // Résultats individuels
    return (
      <div className="min-h-screen pt-4 pb-20">
        <div className="max-w-4xl mx-auto px-6">
          <div className="bg-white/60 backdrop-blur-md rounded-2xl shadow-2xl border border-white/20 overflow-hidden">
            <div className="text-center py-12 px-8 bg-gradient-to-b from-white/30 to-orange-50/30">
              <div className="w-20 h-20 bg-gradient-to-br from-orange-100 to-orange-200 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                <Award className="w-10 h-10 text-orange-600" />
              </div>
              <h1 className="text-3xl font-bold text-gray-900 mb-4">Résultats du Quiz</h1>
              <div className="text-6xl font-bold text-orange-600 mb-4">{results.percentage}%</div>
              <p className="text-xl text-gray-700 mb-2">Félicitations {participantName} !</p>
              <p className="text-gray-600">Vous avez obtenu {results.totalScore} bonnes réponses sur {questions.length}</p>
            </div>

            <div className="p-8">
              <div className="grid md:grid-cols-3 gap-6 mb-8">
                {Object.entries(results.categoryScores).map(([software, score]: [string, any]) => {
                  const percentage = Math.round((score.correct / score.total) * 100);
                  let colorClass = 'from-green-500 to-green-600';
                  let bgClass = 'from-green-50 to-green-100';
                  let textClass = 'text-green-700';
                  
                  if (percentage < 50) {
                    colorClass = 'from-red-500 to-red-600';
                    bgClass = 'from-red-50 to-red-100';
                    textClass = 'text-red-700';
                  } else if (percentage < 70) {
                    colorClass = 'from-orange-500 to-orange-600';
                    bgClass = 'from-orange-50 to-orange-100';
                    textClass = 'text-orange-700';
                  }
                  
                  return (
                    <Card key={software} className={`bg-gradient-to-br ${bgClass} border-gray-200 shadow-lg`}>
                      <CardContent className="p-6 text-center">
                        <h3 className="text-gray-800 font-semibold mb-3">{software}</h3>
                        <div className={`text-3xl font-bold ${textClass} mb-2`}>{percentage}%</div>
                        <p className="text-gray-600">{score.correct}/{score.total} correctes</p>
                        <div className="w-full bg-white/50 rounded-full h-2 mt-3">
                          <div 
                            className={`h-2 rounded-full bg-gradient-to-r ${colorClass}`}
                            style={{ width: `${percentage}%` }}
                          ></div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>

              <div className="text-center">
                <Button 
                  onClick={() => {
                    setQuizStarted(false);
                    setShowResults(false);
                    setCurrentQuestion(0);
                    setSelectedAnswers([]);
                    setParticipantName('');
                  }} 
                  className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white px-8 py-3 text-lg shadow-lg"
                >
                  Recommencer le Quiz
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Page de questions
  const question = questions[currentQuestion];
  const progress = ((currentQuestion + 1) / questions.length) * 100;

  return (
    <div className="min-h-screen pt-4 pb-20">
      <div className="max-w-4xl mx-auto px-6">
        <div className="bg-white/60 backdrop-blur-md rounded-2xl shadow-2xl border border-white/20 overflow-hidden">
          {/* Progress Header */}
          <div className="bg-gradient-to-r from-orange-50/50 to-orange-100/50 p-6 border-b border-gray-200/50">
            <div className="flex items-center justify-between mb-4">
              <Badge variant="outline" className="border-orange-500/30 text-orange-600 bg-orange-50 px-3 py-1 font-medium">
                {question.software}
              </Badge>
              <span className="text-gray-600 font-medium">
                Question {currentQuestion + 1} sur {questions.length}
              </span>
            </div>
            <Progress value={progress} className="h-3 bg-gray-200" />
            <div className="text-center mt-2">
              <span className="text-sm text-gray-500">{Math.round(progress)}% terminé</span>
            </div>
          </div>

          {/* Question Content */}
          <div className="p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">{question.question}</h2>
            
            {!showFeedback && (
              <div className="text-center mb-6">
                <p className="text-gray-600 text-sm">
                  💡 Après avoir sélectionné votre réponse, la correction s'affichera automatiquement
                </p>
              </div>
            )}
            
            {showFeedback && (
              <div className="text-center mb-6">
                <div className={`inline-flex items-center px-4 py-2 rounded-full text-sm font-medium ${
                  selectedAnswers[currentQuestion] === question.correct
                    ? 'bg-green-100 text-green-800 border border-green-200'
                    : 'bg-red-100 text-red-800 border border-red-200'
                }`}>
                  {selectedAnswers[currentQuestion] === question.correct ? (
                    <>
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Excellente réponse ! 🎉
                    </>
                  ) : (
                    <>
                      <XCircle className="w-4 h-4 mr-2" />
                      La bonne réponse était : {String.fromCharCode(65 + question.correct)}
                    </>
                  )}
                </div>
              </div>
            )}
            
            <div className="space-y-4 max-w-2xl mx-auto">
              {question.options.map((option, index) => {
                const isSelected = selectedAnswers[currentQuestion] === index;
                const isCorrect = index === question.correct;
                const isIncorrect = showFeedback && isSelected && !isCorrect;
                const shouldHighlightCorrect = showFeedback && isCorrect;
                
                let buttonClasses = '';
                let circleClasses = '';
                let icon = null;
                
                if (isIncorrect) {
                  // Réponse sélectionnée incorrecte - rouge
                  buttonClasses = 'border-red-500 bg-red-50 text-red-900 shadow-lg shadow-red-500/10';
                  circleClasses = 'bg-red-500 text-white';
                  icon = <XCircle className="w-4 h-4 ml-2 text-red-500" />;
                } else if (shouldHighlightCorrect) {
                  // Bonne réponse - vert
                  buttonClasses = 'border-green-500 bg-green-50 text-green-900 shadow-lg shadow-green-500/10';
                  circleClasses = 'bg-green-500 text-white';
                  icon = <CheckCircle className="w-4 h-4 ml-2 text-green-500" />;
                } else if (isSelected && !showFeedback) {
                  // Réponse sélectionnée mais pas encore de feedback - orange
                  buttonClasses = 'border-orange-500 bg-orange-50 text-orange-900 shadow-lg shadow-orange-500/10';
                  circleClasses = 'bg-orange-500 text-white';
                } else {
                  // État par défaut
                  buttonClasses = showFeedback 
                    ? 'border-gray-200 bg-gray-50 text-gray-500' // Désactivé après feedback
                    : 'border-gray-200 bg-white/80 backdrop-blur-sm text-gray-700 hover:border-orange-300 hover:bg-orange-50/50 shadow-sm hover:shadow-md';
                  circleClasses = showFeedback 
                    ? 'bg-gray-200 text-gray-500' 
                    : 'bg-gray-100 text-gray-600';
                }
                
                return (
                  <button
                    key={index}
                    onClick={() => selectAnswer(index)}
                    disabled={showFeedback}
                    className={`w-full p-5 rounded-xl border-2 text-left transition-all duration-300 ${buttonClasses} ${
                      showFeedback ? 'cursor-default' : 'cursor-pointer'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <span className={`mr-4 w-8 h-8 rounded-full flex items-center justify-center font-bold ${circleClasses}`}>
                          {String.fromCharCode(65 + index)}
                        </span>
                        <span className="font-medium">{option}</span>
                      </div>
                      {icon}
                    </div>
                  </button>
                );
              })}
            </div>

            <div className="flex justify-between pt-8 max-w-2xl mx-auto">
              <Button 
                onClick={previousQuestion}
                disabled={currentQuestion === 0}
                variant="outline"
                className="border-gray-200 text-gray-600 hover:bg-gray-50 disabled:opacity-50"
              >
                Précédent
              </Button>
              <Button 
                onClick={nextQuestion}
                disabled={selectedAnswers[currentQuestion] === undefined || !canProceed}
                className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white shadow-lg disabled:opacity-50"
              >
                {currentQuestion === questions.length - 1 ? 'Terminer' : 'Suivant'}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
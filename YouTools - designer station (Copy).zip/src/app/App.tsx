import React, { useState, useEffect, useCallback, useRef } from 'react';
import { LoginPage } from './components/LoginPage';
import { HomePage } from './components/HomePage';
import { PhotoshopPage } from './components/PhotoshopPage';
import { IllustratorPage } from './components/IllustratorPage';
import { MidjourneyPage } from './components/MidjourneyPage';
import { ProgrammePage } from './components/ProgrammePage';
import { AIAssistantPage } from './components/AIAssistantPage';
import { SEOComponent, homePageStructuredData, coursePageStructuredData } from './components/SEOComponent';
import { GoogleAnalytics, useGoogleAnalytics } from './components/GoogleAnalytics';
import { WebVitals } from './components/WebVitals';
import { useAdvancedSEOComplete } from './components/AdvancedSEO';
import { Menu, X, Home, Palette, PenTool, Bot, BookOpen, LogOut, MessageCircle } from 'lucide-react';

// Import images with fallbacks
let backgroundImage: string = '';
let logoImage: string = '';

try {
  backgroundImage = require('figma:asset/88a091f90336a442fa7c496978d9a0226b121b23.png');
} catch {
  backgroundImage = '/fallback-bg.jpg'; // Fallback si l'image Figma n'est pas disponible
}

// Force l'utilisation du logo fallback orange avec + au lieu de l'import Figma
try {
  // logoImage = require('figma:asset/d1ed5250e08685dd71de28a35f8fb06a9fda3ac4.png');
  logoImage = ''; // Forcer le fallback
} catch {
  logoImage = '/fallback-logo.png'; // Fallback si l'image Figma n'est pas disponible
}

type PageType = 'home' | 'photoshop' | 'illustrator' | 'midjourney' | 'programme' | 'ai-assistant';
type SubPageType = string;

// Clé de stockage pour l'authentification
const AUTH_KEY = 'demarquet_tools_auth';

// URLs des vidéos de fond
const VIDEO_SOURCES = {
  default: 'https://cdn.midjourney.com/video/db125344-7e46-4fea-81ce-5d1d8ddc0907/0.mp4',
  plus: 'https://cdn.midjourney.com/video/13a174c0-5382-4420-b708-16ceb3b56475/3.mp4',
  fish: 'https://cdn.midjourney.com/video/f8e82b38-de57-47b7-8b69-41ac51cd1b85/3.mp4'
};

// Index pour le cycle des vidéos
const VIDEO_CYCLE = ['default', 'plus', 'fish'] as const;
type VideoSourceKey = typeof VIDEO_CYCLE[number];

// Hook personnalisé pour la gestion intelligente des ressources
const useIntelligentResourceLoading = (currentPage: PageType, isAuthenticated: boolean) => {
  const [userEngagement, setUserEngagement] = useState({
    hasScrolled: false,
    timeOnPage: 0,
    isReading: false
  });
  const [preloadedResources, setPreloadedResources] = useState<Set<string>>(new Set());
  const [shouldLoadVideos, setShouldLoadVideos] = useState(false);

  // Détection de l'engagement utilisateur
  useEffect(() => {
    if (!isAuthenticated) return;

    let timeOnPageInterval: NodeJS.Timeout;
    let readingTimeout: NodeJS.Timeout;

    // Timer pour temps passé sur la page
    timeOnPageInterval = setInterval(() => {
      setUserEngagement(prev => ({
        ...prev,
        timeOnPage: prev.timeOnPage + 1
      }));
    }, 1000);

    // Détection du scroll
    const handleScroll = () => {
      setUserEngagement(prev => ({ ...prev, hasScrolled: true }));

      // L'utilisateur semble lire si il scroll lentement
      clearTimeout(readingTimeout);
      setUserEngagement(prev => ({ ...prev, isReading: true }));

      readingTimeout = setTimeout(() => {
        setUserEngagement(prev => ({ ...prev, isReading: false }));
      }, 2000);
    };

    // Détection de la visibilité de la page
    const handleVisibilityChange = () => {
      if (document.hidden) {
        setUserEngagement(prev => ({ ...prev, isReading: false }));
      }
    };

    document.addEventListener('scroll', handleScroll, { passive: true });
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      clearInterval(timeOnPageInterval);
      clearTimeout(readingTimeout);
      document.removeEventListener('scroll', handleScroll);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [isAuthenticated]);

  // Décision de chargement des vidéos basée sur l'engagement
  useEffect(() => {
    const shouldLoad =
      userEngagement.timeOnPage >= 3 || // 3 secondes sur la page
      userEngagement.hasScrolled ||
      userEngagement.isReading;

    if (shouldLoad && !shouldLoadVideos) {
      setShouldLoadVideos(true);
    }
  }, [userEngagement, shouldLoadVideos]);

  // Préchargement intelligent des ressources
  const preloadResource = useCallback((url: string, type: 'video' | 'image' = 'video') => {
    if (preloadedResources.has(url)) return;

    try {
      if (type === 'video') {
        const link = document.createElement('link');
        link.rel = 'preload';
        link.href = url;
        link.as = 'video';
        link.type = 'video/mp4';
        document.head.appendChild(link);
      } else {
        const link = document.createElement('link');
        link.rel = 'preload';
        link.href = url;
        link.as = 'image';
        document.head.appendChild(link);
      }

      setPreloadedResources(prev => new Set([...prev, url]));
    } catch (error) {
      console.debug('Erreur lors du préchargement:', error);
    }
  }, [preloadedResources]);

  // Préchargement adaptatif basé sur la page actuelle et l'engagement
  useEffect(() => {
    if (!shouldLoadVideos) return;

    // Précharger les vidéos du cycle après engagement
    const preloadVideosAfterDelay = () => {
      Object.values(VIDEO_SOURCES).forEach((url, index) => {
        setTimeout(() => {
          preloadResource(url, 'video');
        }, index * 1000); // Étaler le chargement
      });
    };

    // Préchargement basé sur la probabilité de navigation
    const preloadBasedOnPage = () => {
      const navigationProbability: Record<PageType, PageType[]> = {
        'home': ['programme', 'photoshop', 'midjourney'],
        'programme': ['photoshop', 'illustrator', 'midjourney'],
        'photoshop': ['illustrator', 'midjourney', 'ai-assistant'],
        'illustrator': ['photoshop', 'midjourney', 'ai-assistant'],
        'midjourney': ['ai-assistant', 'photoshop', 'illustrator'],
        'ai-assistant': ['midjourney', 'photoshop', 'programme']
      };

      const likelyPages = navigationProbability[currentPage] || [];
      
      // Précharger les ressources des pages probables après un délai
      setTimeout(() => {
        likelyPages.forEach(pageType => {
          // Ici on pourrait précharger des ressources spécifiques à chaque page
          console.log(`Préchargement des ressources pour: ${pageType}`);
        });
      }, 2000);
    };

    preloadVideosAfterDelay();
    preloadBasedOnPage();
  }, [shouldLoadVideos, currentPage, preloadResource]);

  return {
    userEngagement,
    shouldLoadVideos,
    preloadResource
  };
};

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentPage, setCurrentPage] = useState<PageType>('home');
  const [currentSubPage, setCurrentSubPage] = useState<SubPageType>('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [menuHovered, setMenuHovered] = useState(false);
  const [logoHovered, setLogoHovered] = useState(false);
  const [videoError, setVideoError] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [currentVideoSource, setCurrentVideoSource] = useState(VIDEO_SOURCES.default);
  const [isTransitioning, setIsTransitioning] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);

  // Hook de gestion intelligente des ressources
  const { userEngagement, shouldLoadVideos, preloadResource } = useIntelligentResourceLoading(currentPage, isAuthenticated);

  // Hook pour détecter la taille d'écran
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Détection spécifique iPhone SE
  const [isSmallScreen, setIsSmallScreen] = useState(false);
  
  useEffect(() => {
    const checkSmallScreen = () => {
      setIsSmallScreen(window.innerWidth <= 375);
    };
    
    checkSmallScreen();
    window.addEventListener('resize', checkSmallScreen);
    return () => window.removeEventListener('resize', checkSmallScreen);
  }, []);

  // Google Analytics tracking
  const { trackPageView, trackFormation, trackEvent } = useGoogleAnalytics();
  
  // SEO avancé avec données structurées et microdonnées
  useAdvancedSEOComplete(currentPage);

  // Tracking des changements de page avec préchargement intelligent
  useEffect(() => {
    if (isAuthenticated) {
      const pageCategories: Record<PageType, string> = {
        'home': 'landing',
        'photoshop': 'formation',
        'illustrator': 'formation',
        'midjourney': 'formation',
        'ai-assistant': 'ai-tools',
        'programme': 'curriculum'
      };
      
      trackPageView(currentPage, pageCategories[currentPage] || 'other');
      
      // Précharger les ressources des pages susceptibles d'être visitées ensuite
      if (shouldLoadVideos) {
        const nextLikelyResources: Record<PageType, string[]> = {
          'home': [VIDEO_SOURCES.plus, VIDEO_SOURCES.fish],
          'photoshop': [VIDEO_SOURCES.default],
          'illustrator': [VIDEO_SOURCES.default],
          'midjourney': [VIDEO_SOURCES.plus, VIDEO_SOURCES.fish],
          'ai-assistant': [VIDEO_SOURCES.default],
          'programme': [VIDEO_SOURCES.default, VIDEO_SOURCES.plus]
        };
        
        const resourcesToPreload = nextLikelyResources[currentPage] || [];
        resourcesToPreload.forEach((url, index) => {
          setTimeout(() => preloadResource(url, 'video'), (index + 1) * 2000);
        });
      }
    }
  }, [currentPage, isAuthenticated, trackPageView, shouldLoadVideos, preloadResource]);

  // Fonction pour jouer un son de clic - optimisée pour mobile
  const playClickSound = useCallback((variant: 'hover' | 'button' | 'logout' = 'hover', buttonName?: string) => {
    // Ne pas jouer de sons sur mobile pour éviter les problèmes d'autorisation
    if (isMobile) return;
    
    console.log(`Son joué: ${variant} pour ${buttonName || 'bouton inconnu'}`);
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      
      if (variant === 'hover') {
        // Son de clic de souris classique pour le survol
        const createMouseClickSound = () => {
          // Oscillateur principal pour le "tick"
          const clickOsc = audioContext.createOscillator();
          const clickGain = audioContext.createGain();
          
          // Filtre passe-haut pour un son plus clair et aigu
          const filter = audioContext.createBiquadFilter();
          filter.type = 'highpass';
          filter.frequency.setValueAtTime(2000, audioContext.currentTime);
          filter.Q.setValueAtTime(1, audioContext.currentTime);
          
          // Connexions audio
          clickOsc.connect(filter);
          filter.connect(clickGain);
          clickGain.connect(audioContext.destination);
          
          // Configuration pour un clic très bref et aigu
          clickOsc.type = 'square'; // Son plus net qu'une sine wave
          clickOsc.frequency.setValueAtTime(4000, audioContext.currentTime);
          clickOsc.frequency.exponentialRampToValueAtTime(2000, audioContext.currentTime + 0.005);
          
          // Enveloppe très rapide pour simuler un vrai clic de souris
          clickGain.gain.setValueAtTime(0, audioContext.currentTime);
          clickGain.gain.linearRampToValueAtTime(0.05, audioContext.currentTime + 0.001); // Attack ultra rapide
          clickGain.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.015); // Decay rapide
          
          // Démarrer et arrêter très rapidement
          clickOsc.start(audioContext.currentTime);
          clickOsc.stop(audioContext.currentTime + 0.015);
        };
        
        createMouseClickSound();
        
        // Nettoyer après utilisation
        setTimeout(() => {
          audioContext.close();
        }, 50);
        
      } else {
        // Sons originaux pour les autres variants
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        let frequency1 = 800;
        let frequency2 = 400;
        let duration = 0.08;
        let volume = 0.08;
        
        switch (variant) {
          case 'button':
            frequency1 = 1000;
            frequency2 = 500;
            duration = 0.06;
            volume = 0.1;
            break;
          case 'logout':
            frequency1 = 600;
            frequency2 = 300;
            duration = 0.12;
            volume = 0.06;
            break;
        }
        
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(frequency1, audioContext.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(frequency2, audioContext.currentTime + duration);
        
        gainNode.gain.setValueAtTime(volume, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + duration);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + duration);
        
        setTimeout(() => {
          audioContext.close();
        }, (duration * 1000) + 100);
      }
    } catch (error) {
      console.debug('Audio non supporté:', error);
    }
  }, [isMobile]);

  // Vérifier l'authentification au chargement - avec fallback localStorage
  useEffect(() => {
    const checkAuth = () => {
      try {
        // Essayer sessionStorage d'abord, puis localStorage en fallback
        let authStatus = null;
        try {
          authStatus = sessionStorage.getItem(AUTH_KEY);
        } catch {
          authStatus = localStorage.getItem(AUTH_KEY);
        }
        
        if (authStatus === 'authenticated') {
          setIsAuthenticated(true);
        }
      } catch (error) {
        console.warn('Erreur lors de la vérification de l\'authentification:', error);
      } finally {
        setIsLoading(false);
      }
    };

    checkAuth();
  }, []);

  const handleNavigate = useCallback((page: PageType) => {
    // Protection supplémentaire : vérifier l'authentification avant la navigation
    if (!isAuthenticated) {
      handleLogout(false); // Pas de son pour la déconnexion automatique
      return;
    }

    // Si on clique sur la même page, ne rien faire
    if (page === currentPage) {
      return;
    }

    // Tracking Google Analytics
    trackEvent('page_navigation', {
      from_page: currentPage,
      to_page: page,
      navigation_type: isMobile ? 'mobile' : 'desktop',
      label: `${currentPage}_to_${page}`
    });

    // Démarrer la transition avec effet de flou
    setIsTransitioning(true);

    // Attendre que le flou soit appliqué, puis changer la page
    setTimeout(() => {
      setCurrentPage(page);
      setMobileMenuOpen(false);

      // Sur mobile, scroll vers le haut après navigation
      if (isMobile) {
        window.scrollTo({ top: 0, behavior: 'auto' });
      }

      // Retirer le flou pour révéler la nouvelle page
      setTimeout(() => {
        setIsTransitioning(false);
      }, 50);
    }, 300);
  }, [isAuthenticated, isMobile, trackEvent, currentPage]);

  const handleSubPageNavigate = useCallback((subPage: string) => {
    // Si on clique sur la même sous-page, ne rien faire
    if (subPage === currentSubPage) {
      return;
    }

    // Démarrer la transition avec effet de flou
    setIsTransitioning(true);

    // Attendre que le flou soit appliqué, puis changer la sous-page
    setTimeout(() => {
      setCurrentSubPage(subPage);

      // Sur mobile, scroll vers le haut après navigation
      if (isMobile) {
        window.scrollTo({ top: 0, behavior: 'auto' });
      }

      // Retirer le flou pour révéler la nouvelle sous-page
      setTimeout(() => {
        setIsTransitioning(false);
      }, 50);
    }, 300);
  }, [currentSubPage, isMobile]);

  const handleLogin = useCallback(() => {
    try {
      // Essayer sessionStorage d'abord, puis localStorage en fallback
      try {
        sessionStorage.setItem(AUTH_KEY, 'authenticated');
      } catch {
        localStorage.setItem(AUTH_KEY, 'authenticated');
      }
      setIsAuthenticated(true);
    } catch (error) {
      console.warn('Erreur lors de la sauvegarde de l\'authentification:', error);
      setIsAuthenticated(true); // Continuer même en cas d'erreur de stockage
    }
  }, []);

  const handleLogout = useCallback((playSound = true) => {
    try {
      // Supprimer l'authentification des deux storages
      try {
        sessionStorage.removeItem(AUTH_KEY);
      } catch {
        // Fallback
      }
      try {
        localStorage.removeItem(AUTH_KEY);
      } catch {
        // Fallback
      }
    } catch (error) {
      console.warn('Erreur lors de la suppression de l\'authentification:', error);
    }
    
    // Jouer le son de clic (variant logout) seulement si demandé
    if (playSound) {
      playClickSound('logout', 'Auto Logout');
    }
    
    setIsAuthenticated(false);
    setCurrentPage('home');
    setMobileMenuOpen(false);
  }, [playClickSound]);

  // Gérer la fermeture du menu au redimensionnement
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 768) { // md breakpoint
        setMobileMenuOpen(false);
      }
    };
    
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const navigationItems = [
    { id: 'home', label: 'Accueil', icon: Home },
    { id: 'programme', label: 'Programme', icon: BookOpen },
    { id: 'photoshop', label: 'Photoshop', icon: Palette },
    { id: 'illustrator', label: 'Illustrator', icon: PenTool },
    { id: 'midjourney', label: 'Prompt design', icon: Bot },
    { id: 'ai-assistant', label: 'Agent IA', icon: null }
  ] as const;

  // Sous-menus pour chaque page
  const subMenus: Record<PageType, Array<{ id: string; label: string }>> = {
    'home': [],
    'photoshop': [
      { id: 'shortcuts', label: 'Raccourcis Mac' },
      { id: 'glossary', label: 'Glossaire' },
      { id: 'videos', label: 'Vidéos' }
    ],
    'illustrator': [
      { id: 'shortcuts', label: 'Raccourcis Mac' },
      { id: 'glossary', label: 'Glossaire' },
      { id: 'videos', label: 'Vidéos' }
    ],
    'midjourney': [
      { id: 'tips', label: 'Astuces' },
      { id: 'camera', label: 'Cadrages' },
      { id: 'lighting', label: 'Éclairages' },
      { id: 'styles', label: 'Styles' },
      { id: 'plancamera', label: 'Plan camera' },
      { id: 'prompts', label: 'Exemples' },
      { id: 'videos', label: 'Vidéos' }
    ],
    'programme': [
      { id: 'photoshop', label: 'Photoshop' },
      { id: 'illustrator', label: 'Illustrator' },
      { id: 'ia', label: 'IA' }
    ],
    'ai-assistant': []
  };

  // Initialiser la sous-page par défaut quand on change de page
  useEffect(() => {
    const subPages = subMenus[currentPage];
    if (subPages && subPages.length > 0) {
      setCurrentSubPage(subPages[0].id);
    } else {
      setCurrentSubPage('');
    }
  }, [currentPage]);

  // Gestion de la fermeture du menu mobile avec Escape
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && mobileMenuOpen) {
        setMobileMenuOpen(false);
      }
    };
    
    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [mobileMenuOpen]);

  // Fonction pour changer l'animation de fond
  const handleChangeVideoBackground = useCallback(() => {
    // Déterminer l'index actuel et passer au suivant dans le cycle
    const currentKey = Object.keys(VIDEO_SOURCES).find(key => VIDEO_SOURCES[key as VideoSourceKey] === currentVideoSource) as VideoSourceKey || 'default';
    const currentIndex = VIDEO_CYCLE.indexOf(currentKey);
    const nextIndex = (currentIndex + 1) % VIDEO_CYCLE.length;
    const nextKey = VIDEO_CYCLE[nextIndex];
    const newSource = VIDEO_SOURCES[nextKey];
    
    setCurrentVideoSource(newSource);
    
    // Forcer le rechargement de la vidéo
    const videoElement = document.querySelector('video');
    if (videoElement) {
      videoElement.load(); // Force le rechargement de la vidéo avec la nouvelle source
    }
    
    // Tracking de l'événement avec support du cycle à 3 vidéos
    trackEvent('video_background_change', {
      from_video: currentKey,
      to_video: nextKey,
      cycle_position: `${nextIndex + 1}/3`,
      user_action: 'plus_button_click'
    });
  }, [currentVideoSource, trackEvent]);

  // Afficher un écran de chargement pendant la vérification - responsive
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-orange-50/30 flex items-center justify-center px-4">
        <div className="text-center">
          <div className="w-12 h-12 sm:w-16 sm:h-16 mx-auto mb-3 sm:mb-4 bg-gradient-to-br from-orange-100 to-orange-200 rounded-2xl flex items-center justify-center shadow-lg">
            <div className="w-6 h-6 sm:w-8 sm:h-8 bg-orange-600 rounded-full" />
          </div>
          <div className="w-6 h-6 sm:w-8 sm:h-8 border-2 border-orange-600/30 border-t-orange-600 rounded-full animate-spin mx-auto mb-2"></div>
          <p className="text-orange-600 text-xs sm:text-sm font-medium">Chargement sécurisé...</p>
        </div>
      </div>
    );
  }

  // Afficher la page de connexion si pas authentifié
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen relative overflow-hidden">
        {/* Video Background - with error handling */}
        {!videoError ? (
          <video
            autoPlay
            muted
            loop
            playsInline
            preload="metadata"
            onError={() => setVideoError(true)}
            className="fixed inset-0 w-full h-full object-cover z-0"
            style={{
              filter: 'brightness(0.75) contrast(1.1) saturate(1.15)',
            }}
          >
            <source src="https://cdn.midjourney.com/video/db125344-7e46-4fea-81ce-5d1d8ddc0907/0.mp4" type="video/mp4" />
          </video>
        ) : (
          /* Fallback static background */
          <div 
            className="fixed inset-0 w-full h-full z-0"
            style={{
              backgroundImage: backgroundImage ? `url(${backgroundImage})` : 'linear-gradient(135deg, #f0fdfa, #ffffff, #f0fdfa)',
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              backgroundRepeat: 'no-repeat',
              filter: 'brightness(0.8) contrast(1.1) saturate(1.1)',
            }}
          />
        )}
        
        {/* Enhanced overlay for content readability */}
        <div className="fixed inset-0 pointer-events-none bg-white/16 backdrop-blur-[1.2px] z-10"></div>
        
        {/* Minimal floating elements for elegance */}
        <div className="fixed inset-0 overflow-hidden pointer-events-none z-20">
          {/* Subtle floating accents with orange palette - more subtle over video */}
          <div className="absolute top-1/4 right-1/4 w-64 h-64 bg-orange-400/3 rounded-full blur-3xl animate-float-diagonal"></div>
          <div className="absolute bottom-1/3 left-1/4 w-80 h-80 bg-orange-300/2 rounded-full blur-3xl animate-drift" style={{animationDelay: '3s'}}></div>
          
          {/* Discrete particles - slightly more visible over video */}
          <div className="absolute top-1/5 left-1/6 w-1 h-1 bg-orange-500/40 rounded-full animate-float"></div>
          <div className="absolute top-3/5 right-1/5 w-1 h-1 bg-orange-400/35 rounded-full animate-float" style={{animationDelay: '2s'}}></div>
          <div className="absolute bottom-1/4 left-2/3 w-1 h-1 bg-orange-600/40 rounded-full animate-float" style={{animationDelay: '1s'}}></div>
        </div>
        
        <div className="relative z-30">
          <LoginPage onLogin={handleLogin} />
        </div>
      </div>
    );
  }

  // Fonction pour obtenir les données SEO dynamiques selon la page
  const getSEOData = () => {
    const baseUrl = 'https://creative-tools.fr';
    
    switch (currentPage) {
      case 'home':
        return {
          title: "YouTools - Formation Professionnelle Design Graphique | Photoshop, Illustrator, Prompt design",
          description: "Maîtrisez les outils créatifs avec YouTools : formations Photoshop, Illustrator, Prompt design + IA et assistant IA. Plateforme 100% française.",
          canonical: baseUrl,
          structuredData: homePageStructuredData
        };
      case 'photoshop':
        return {
          title: "Formation Photoshop Mac - Raccourcis Professionnels | YouTools",
          description: "Maîtrisez tous les raccourcis Photoshop pour Mac. Formation complète avec techniques avancées de retouche, masques, calques. Guide professionnel exclusif.",
          canonical: `${baseUrl}/photoshop`,
          keywords: "formation photoshop mac, raccourcis photoshop, photoshop professionnel, retouche photo, masques photoshop, calques photoshop, cmd photoshop",
          structuredData: coursePageStructuredData(
            "Formation Photoshop Mac - Raccourcis Professionnels",
            "Formation complète aux raccourcis et techniques Photoshop pour Mac",
            `${baseUrl}/photoshop`
          )
        };
      case 'illustrator':
        return {
          title: "Formation Illustrator Mac - Design Vectoriel Professionnel | YouTools",
          description: "Techniques avancées d'Adobe Illustrator pour Mac. Maîtrisez l'outil Plume, les raccourcis, le design vectoriel. Formation professionnelle complète.",
          canonical: `${baseUrl}/illustrator`,
          keywords: "formation illustrator mac, design vectoriel, outil plume illustrator, raccourcis illustrator, logo vectoriel, typographie illustrator",
          structuredData: coursePageStructuredData(
            "Formation Illustrator Mac - Design Vectoriel",
            "Formation complète au design vectoriel avec Adobe Illustrator pour Mac",
            `${baseUrl}/illustrator`
          )
        };
      case 'midjourney':
        return {
          title: "Formation Prompt design - 230+ Astuces IA | YouTools",
          description: "Plus de 230 astuces Prompt design organisées en onglets spécialisés. Maîtrisez l'IA générative, prompts avancés, paramètres. Formation IA complète.",
          canonical: `${baseUrl}/midjourney`,
          keywords: "formation prompt design, astuces prompt design, prompts midjourney, IA generative, art intelligence artificielle, prompt design français",
          structuredData: coursePageStructuredData(
            "Formation Prompt design - 230+ Astuces IA",
            "Formation complète au Prompt design avec plus de 230 astuces spécialisées",
            `${baseUrl}/midjourney`
          )
        };
      case 'ai-assistant':
        return {
          title: "Agent IA YouTools - Expert Design Graphique | ChatGPT",
          description: "Agent IA spécialisé en design graphique. 200+ suggestions de prompts, conseils Photoshop/Illustrator, workflow créatif. Alimenté par ChatGPT.",
          canonical: `${baseUrl}/ai-assistant`,
          keywords: "agent ia design, chatgpt design, conseils photoshop ia, agent créatif, workflow design ia, suggestions créatives",
          structuredData: coursePageStructuredData(
            "Agent IA Creative Tools",
            "Agent intelligence artificielle spécialisé en design graphique",
            `${baseUrl}/ai-assistant`
          )
        };
      default:
        return {
          title: "Creative Tools - Formation Design Graphique",
          description: "Plateforme de formation professionnelle en design graphique",
          canonical: baseUrl,
          structuredData: homePageStructuredData
        };
    }
  };

  const seoData = getSEOData();

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* SEO Component */}
      <SEOComponent
        title={seoData.title}
        description={seoData.description}
        keywords={seoData.keywords}
        canonical={seoData.canonical}
        structuredData={seoData.structuredData}
      />
      
      {/* Google Analytics & Performance Tracking */}
      <GoogleAnalytics />
      <WebVitals />
      
      {/* Video Background - with error handling and intelligent loading */}
      {!videoError ? (
        <video
          ref={videoRef}
          autoPlay
          muted
          loop
          playsInline
          preload={shouldLoadVideos ? "metadata" : "none"}
          onError={() => setVideoError(true)}
          className="fixed inset-0 w-full h-full object-cover z-0"
          style={{
            filter: 'brightness(0.75) contrast(1.1) saturate(1.15)',
          }}
        >
          {shouldLoadVideos && <source src={currentVideoSource} type="video/mp4" />}
        </video>
      ) : (
        /* Fallback static background */
        <div 
          className="fixed inset-0 w-full h-full z-0"
          style={{
            backgroundImage: backgroundImage ? `url(${backgroundImage})` : 'linear-gradient(135deg, #f0fdfa, #ffffff, #f0fdfa)',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundRepeat: 'no-repeat',
            filter: 'brightness(0.8) contrast(1.1) saturate(1.1)',
          }}
        />
      )}
      
      {/* Loading indicator for video resources */}
      {!shouldLoadVideos && isAuthenticated && (
        <div className="fixed bottom-4 right-4 z-50 bg-orange-600/90 text-white px-3 py-2 rounded-lg text-xs backdrop-blur-sm">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
            <span>Optimisation en cours...</span>
          </div>
        </div>
      )}
      
      {/* Enhanced overlay for content readability */}
      <div className={`fixed inset-0 pointer-events-none z-10 ${isSmallScreen ? 'bg-white/24 backdrop-blur-[2px]' : 'bg-white/16 backdrop-blur-[1.2px]'}`}></div>
      
      {/* Minimal floating elements for elegance */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-20">
        {/* Subtle floating accents with orange palette - more subtle over video */}
        <div className="absolute top-1/4 right-1/4 w-64 h-64 bg-orange-400/3 rounded-full blur-3xl animate-float-diagonal"></div>
        <div className="absolute bottom-1/3 left-1/4 w-80 h-80 bg-orange-300/2 rounded-full blur-3xl animate-drift" style={{animationDelay: '3s'}}></div>
        
        {/* Discrete particles - slightly more visible over video */}
        <div className="absolute top-1/5 left-1/6 w-1 h-1 bg-orange-500/40 rounded-full animate-float"></div>
        <div className="absolute top-3/5 right-1/5 w-1 h-1 bg-orange-400/35 rounded-full animate-float" style={{animationDelay: '2s'}}></div>
        <div className="absolute bottom-1/4 left-2/3 w-1 h-1 bg-orange-600/40 rounded-full animate-float" style={{animationDelay: '1s'}}></div>
      </div>

      {/* Professional Header - optimisé responsive */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-white/95 sm:bg-white/90 backdrop-blur-md border-b border-gray-200/60 shadow-sm">
        <nav className="max-w-7xl mx-auto px-3 sm:px-4 md:px-6 lg:px-8">
          <div className="flex items-center justify-between h-12 sm:h-14">
            {/* Logo Section - optimisée responsive */}
            <div 
              className="flex items-center space-x-2 sm:space-x-3 cursor-pointer group touch-manipulation"
              onClick={() => handleNavigate('home')}
            >
              <div 
                className="relative"
                onMouseEnter={() => !isMobile && setLogoHovered(true)}
                onMouseLeave={() => !isMobile && setLogoHovered(false)}
              >
                {logoImage ? (
                  <img
                    src={logoImage}
                    alt="Creative Tools Logo"
                    loading="eager"
                    className={`w-7 h-7 sm:w-8 sm:h-8 transition-all duration-300 relative z-10 ${
                      logoHovered
                        ? 'logo-green-filter'
                        : ''
                    }`}
                    onError={(e) => {
                      // Fallback si l'image ne charge pas
                      const target = e.target as HTMLImageElement;
                      target.style.display = 'none';
                      target.nextElementSibling?.setAttribute('style', 'display: flex');
                    }}
                  />
                ) : null}
                {/* Fallback logo si image indisponible */}
                <div 
                  className="w-7 h-7 sm:w-8 sm:h-8 bg-orange-600 rounded-full flex items-center justify-center text-white text-xl font-bold leading-none"
                  style={{ display: logoImage ? 'none' : 'flex' }}
                >
                  +
                </div>
              </div>
              <div className="hidden xs:block sm:block">
                <h1 className={`font-condensed font-black tracking-tight text-sm sm:text-base transition-colors duration-300 text-orange-600`}>
                  YouTools
                </h1>
                <p className="text-[9px] sm:text-[10px] text-gray-500 -mt-0.5 hidden sm:block">Professional Training Platform</p>
              </div>
            </div>

            {/* Desktop Navigation - optimisée responsive */}
            <div 
              className="hidden md:flex lg:flex items-center space-x-0.5 xl:space-x-1"
              onMouseEnter={() => !isMobile && setMenuHovered(true)}
              onMouseLeave={() => !isMobile && setMenuHovered(false)}
            >
              {navigationItems.map((item) => {
                const IconComponent = item.icon;
                const isActive = currentPage === item.id;
                const isAI = item.id === 'ai-assistant';
                
                return (
                  <button
                    key={item.id}
                    onClick={() => handleNavigate(item.id as PageType)}
                    onMouseEnter={() => playClickSound('hover', item.label)}
                    onTouchStart={() => playClickSound('hover', item.label)}
                    className={`corporate-nav-link px-2 md:px-3 py-1.5 md:py-2 rounded-lg flex items-center space-x-1 md:space-x-1.5 transition-colors duration-200 touch-manipulation ${
                      isActive
                        ? (isAI ? 'text-orange-600 bg-orange-50' : 'text-orange-600 bg-orange-50')
                        : (isAI ? 'text-orange-500 hover:text-orange-600 hover:bg-orange-50' : 'text-gray-700 hover:text-gray-900 hover:bg-gray-50')
                    }`}
                  >
                    {IconComponent && <IconComponent className="w-3 h-3 md:w-3.5 md:h-3.5" />}
                    <span className={`text-[9px] md:text-[10px] font-medium hidden lg:inline ${isAI ? 'font-semibold' : ''}`}>{item.label}</span>
                    <span className={`text-[9px] md:text-[10px] font-medium lg:hidden ${isAI ? 'font-semibold' : ''}`}>{isAI ? item.label : item.label.slice(0, 4)}</span>
                  </button>
                );
              })}
            </div>

            {/* CTA Button & Logout - optimisés responsive */}
            <div
              className="hidden md:flex items-center space-x-2 lg:space-x-3"
              onMouseEnter={() => !isMobile && setMenuHovered(true)}
              onMouseLeave={() => !isMobile && setMenuHovered(false)}
            >
              <button
                onClick={() => handleLogout(true)}
                className="corporate-button bg-gray-500 hover:bg-gray-600 text-white px-2 md:px-3 py-1.5 rounded-lg text-[10px] md:text-xs font-medium flex items-center space-x-1 md:space-x-1.5 shadow-sm touch-manipulation"
                title="Se déconnecter"
              >
                <LogOut className="w-3 h-3 md:w-3.5 md:h-3.5" />
                <span className="hidden xl:inline">Déconnexion</span>
              </button>
            </div>

            {/* Mobile Menu Button - optimisé tactile */}
            <div className="md:hidden">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 rounded-lg text-gray-700 hover:text-gray-900 hover:bg-gray-100 transition-colors duration-200 touch-manipulation active:scale-95"
                aria-label={mobileMenuOpen ? "Fermer le menu" : "Ouvrir le menu"}
              >
                {mobileMenuOpen ? (
                  <X className="w-5 h-5" />
                ) : (
                  <Menu className="w-5 h-5" />
                )}
              </button>
            </div>
          </div>

          {/* Mobile Menu - amélioré responsive */}
          {mobileMenuOpen && (
            <div className="md:hidden border-t border-gray-200/50 bg-white/95 backdrop-blur-md">
              <div className="px-3 sm:px-4 py-3 space-y-1">
                {navigationItems.map((item) => {
                  const IconComponent = item.icon;
                  const isActive = currentPage === item.id;
                  const isAI = item.id === 'ai-assistant';
                  
                  return (
                    <button
                      key={item.id}
                      onClick={() => handleNavigate(item.id as PageType)}
                      onTouchStart={() => playClickSound('hover', item.label)}
                      className={`w-full corporate-nav-link px-3 py-3 rounded-lg flex items-center space-x-3 text-left transition-all duration-200 touch-manipulation active:scale-[0.98] ${
                        isActive
                          ? (isAI ? 'text-orange-600 bg-orange-50' : 'text-orange-600 bg-orange-50')
                          : (isAI ? 'text-orange-500 hover:text-orange-600 hover:bg-orange-50 active:bg-orange-100' : 'text-gray-700 hover:text-gray-900 hover:bg-gray-50 active:bg-gray-100')
                      }`}
                    >
                      {IconComponent && <IconComponent className="w-4 h-4 flex-shrink-0" />}
                      <span className={`text-sm font-medium ${isAI ? 'font-semibold ml-7' : ''}`}>{isAI ? 'Agent IA' : item.label}</span>
                    </button>
                  );
                })}
                
                {/* Mobile CTA & Logout - optimisés */}
                <div className="pt-3 border-t border-gray-200/50 space-y-2">
                  <button
                    onClick={() => handleLogout(true)}
                    className="w-full corporate-button bg-gray-500 hover:bg-gray-600 active:bg-gray-700 text-white px-3 py-3 rounded-lg flex items-center justify-center space-x-2 touch-manipulation active:scale-[0.98] transition-all duration-200"
                  >
                    <LogOut className="w-4 h-4" />
                    <span className="text-sm font-medium">Se déconnecter</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </nav>

        {/* Sub-Menu Navigation - shown when current page has sub-menus */}
        {subMenus[currentPage] && subMenus[currentPage].length > 0 && (
          <div className="border-t border-gray-200/50 bg-white/90 backdrop-blur-md">
            <div className="max-w-7xl mx-auto px-3 sm:px-4 md:px-6 lg:px-8">
              <div className="flex items-center justify-center space-x-1 overflow-x-auto py-2 scrollbar-hide">
                {subMenus[currentPage].map((subItem) => {
                  const isActive = currentSubPage === subItem.id;

                  return (
                    <button
                      key={subItem.id}
                      onClick={() => handleSubPageNavigate(subItem.id)}
                      onMouseEnter={() => !isMobile && playClickSound('hover', subItem.label)}
                      onTouchStart={() => playClickSound('hover', subItem.label)}
                      className={`flex-shrink-0 px-3 md:px-4 py-1.5 md:py-2 rounded-lg text-[10px] md:text-xs font-medium transition-all duration-200 touch-manipulation ${
                        isActive
                          ? 'text-white bg-orange-600 shadow-sm'
                          : 'text-gray-700 hover:text-orange-600 hover:bg-orange-50'
                      }`}
                    >
                      {subItem.label}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Page Transition Blur Overlay - z-40 pour être sous le header (z-50) mais au-dessus du contenu (z-30) */}
      <div
        className={`fixed inset-0 z-40 pointer-events-none transition-all duration-300 ${
          isTransitioning ? 'backdrop-blur-xl opacity-100' : 'backdrop-blur-none opacity-0'
        }`}
        style={{
          backgroundColor: isTransitioning ? 'rgba(255, 255, 255, 0.3)' : 'transparent'
        }}
      />

      {/* Main Content */}
      <main className={`relative z-30 transition-opacity duration-300 ${isTransitioning ? 'opacity-0' : 'opacity-100'} ${subMenus[currentPage] && subMenus[currentPage].length > 0 ? 'pt-[88px] sm:pt-[100px]' : 'pt-12 sm:pt-14'}`}>
        {currentPage === 'home' && <HomePage onNavigate={handleNavigate} onChangeVideoBackground={handleChangeVideoBackground} />}
        {currentPage === 'programme' && <ProgrammePage currentSubPage={currentSubPage} />}
        {currentPage === 'photoshop' && <PhotoshopPage currentSubPage={currentSubPage} />}
        {currentPage === 'illustrator' && <IllustratorPage currentSubPage={currentSubPage} />}
        {currentPage === 'midjourney' && <MidjourneyPage currentSubPage={currentSubPage} />}
        {currentPage === 'ai-assistant' && <AIAssistantPage />}
      </main>

      {/* Mobile Menu Backdrop - amélioré */}
      {mobileMenuOpen && (
        <div
          className="fixed inset-0 bg-black/20 z-40 md:hidden transition-opacity duration-200"
          onClick={() => setMobileMenuOpen(false)}
          onTouchStart={() => setMobileMenuOpen(false)}
        />
      )}

      {/* Footer */}
      <footer className="relative z-30 py-4 text-center">
        <p className="text-xs text-gray-500">Youtools © Demarquet</p>
      </footer>
    </div>
  );
}